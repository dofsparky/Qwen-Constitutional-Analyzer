# QCAv16-3 lamerized

QCAv16-3 adds an ingestion filter so front matter, tables of contents, indexes, and other non-statutory material are skipped before analysis.

## What changed

- `--prepare` / `--index-only` still build and cache the documents
- non-statutory material is skipped during chunking
- top matches remain compact excerpts
- the prompt budget is conservative by default
- analysis mode still works when `--questions` is omitted
- question mode still works when `--questions` is provided

## Why this is better

Earlier builds still spent time on publisher metadata and other non-law text. QCAv16-3 fixes that by:
1. caching the source documents,
2. rejecting front matter and TOC/index material,
3. selecting only statutory-looking chunks,
4. limiting top-match excerpts,
5. trimming the prompt to fit the budget.

## Example

```bash
./QCAv16-3   --profile ultra   --prompt-budget 5000   --workers auto   --input "/home/delta/iowa/2026/iowa_code_2026.txt"   --reference "/home/delta/references/bill_of_rights.txt"   --outdir "/home/delta/iowa/iowa-qcav16-3"   --runner-template 'llama-cli -m /home/delta/models/Qwen3-4B-Q4_K_M.gguf --jinja --reasoning on --reasoning-budget -1 -c {CTX_SIZE} -n 2048 --temp 0.6 --top-k 40 --top-p 0.95 --min-p 0.05 --repeat-penalty 1.05 -f {PROMPT_FILE}'
```

## Notes

- `--prepare` and `--index-only` do not require `--runner-template`
- if a cache already exists, later runs can reuse it
- analysis mode automatically activates when `--questions` is omitted
- `--prompt-budget` defaults to about 33% of the remaining context if omitted
