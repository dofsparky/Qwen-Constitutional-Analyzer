# QCAv12 lamerized

QCAv12 is a portable offline constitutional analyzer for `llama.cpp`.

## What it does

- Extracts PDFs locally with `pdftotext`
- Loads a Bill of Rights reference PDF as the controlling authority
- Splits the Iowa Code into sections
- Sends one section at a time to Qwen via a prompt file
- Saves checkpoint files so jobs can resume after interruption
- Supports four runtime memory profiles so you do not need separate builds

## Memory profiles

- `ultra-low` — 512 context, 128 tokens
- `low` — 1024 context, 192 tokens
- `medium` — 2048 context, 256 tokens
- `high` — 4096 context, 384 tokens

List them with:

```bash
./QCAv12 --list-profiles
```

## Build

```bash
make
```

## Example

```bash
./QCAv12   --profile low   --input "/home/delta/iowa/2022-iowa-code.pdf"   --reference "/home/delta/references/bill-of-rights.pdf"   --outdir "iowa-2022"   --runner-template 'llama-cli -m /home/delta/models/Qwen3-4B-Q4_K_M.gguf --jinja --reasoning on --reasoning-budget -1 -c {CTX_SIZE} -p {PROMPT}'
```

## Resume

If the job is stopped, rerun the same command and it resumes from:

```text
iowa-2022/.qca_state/
```

Use `--reset` to start over.

## Watch mode

```bash
./QCAv12   --profile low   --input "/home/delta/iowa/2022-iowa-code.pdf"   --reference "/home/delta/references/bill-of-rights.pdf"   --outdir "iowa-2022"   --runner-template 'llama-cli -m /home/delta/models/Qwen3-4B-Q4_K_M.gguf --jinja --reasoning on --reasoning-budget -1 -c {CTX_SIZE} -p {PROMPT}'   --interactive   --show-prompts
```

## Output

- `report.md`
- `index.csv`
- `index.json`
- `work/section_XXXX.prompt.txt`
- `work/section_XXXX.raw.txt`
- `work/section_XXXX.json`

## Notes

This source is written to be 32-bit friendly at the C level: it avoids pointer-width assumptions and uses standard C/POSIX facilities only. Actual 32-bit linking still depends on whether the target machine has 32-bit versions of `gcc`, libc, and `llama.cpp` available.


This v12 build fixes recursive outdir creation so nested output paths are created automatically.
