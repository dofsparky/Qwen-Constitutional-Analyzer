
#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#define APP "QCAv11"

typedef struct {
    char *title;
    char *text;
} Section;

typedef struct {
    Section *items;
    size_t len, cap;
} SectionVec;

typedef struct {
    char *buf;
    size_t len, cap;
} StrBuf;

static void sb_init(StrBuf *b) { b->buf = NULL; b->len = b->cap = 0; }
static void sb_free(StrBuf *b) { free(b->buf); b->buf = NULL; b->len = b->cap = 0; }

static void sb_reserve(StrBuf *b, size_t add) {
    size_t need = b->len + add + 1;
    if (need <= b->cap) return;
    size_t nc = b->cap ? b->cap : 1024;
    while (nc < need) nc *= 2;
    char *p = realloc(b->buf, nc);
    if (!p) { perror("realloc"); exit(1); }
    b->buf = p;
    b->cap = nc;
}
static void sb_append_n(StrBuf *b, const char *s, size_t n) {
    if (!s || !n) return;
    sb_reserve(b, n);
    memcpy(b->buf + b->len, s, n);
    b->len += n;
    b->buf[b->len] = '\0';
}
static void sb_append(StrBuf *b, const char *s) { if (s) sb_append_n(b, s, strlen(s)); }
static void sb_appendf(StrBuf *b, const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    va_list ap2;
    va_copy(ap2, ap);
    int n = vsnprintf(NULL, 0, fmt, ap);
    va_end(ap);
    if (n < 0) { va_end(ap2); return; }
    sb_reserve(b, (size_t)n);
    vsnprintf(b->buf + b->len, b->cap - b->len, fmt, ap2);
    va_end(ap2);
    b->len += (size_t)n;
}

static char *xstrdup(const char *s) {
    if (!s) s = "";
    size_t n = strlen(s);
    char *p = malloc(n + 1);
    if (!p) { perror("malloc"); exit(1); }
    memcpy(p, s, n + 1);
    return p;
}
static char *trim_inplace(char *s) {
    if (!s) return s;
    char *start = s;
    while (*start && isspace((unsigned char)*start)) start++;
    char *end = start + strlen(start);
    while (end > start && isspace((unsigned char)end[-1])) end--;
    size_t n = (size_t)(end - start);
    if (start != s) memmove(s, start, n);
    s[n] = '\0';
    return s;
}
static char *dup_trim(const char *s) { return trim_inplace(xstrdup(s)); }

static char *to_upper_dup(const char *s) {
    size_t n = strlen(s);
    char *p = malloc(n + 1);
    if (!p) { perror("malloc"); exit(1); }
    for (size_t i = 0; i < n; i++) p[i] = (char)toupper((unsigned char)s[i]);
    p[n] = '\0';
    return p;
}
static bool contains_ci(const char *hay, const char *needle) {
    char *u1 = to_upper_dup(hay ? hay : "");
    char *u2 = to_upper_dup(needle ? needle : "");
    bool ok = strstr(u1, u2) != NULL;
    free(u1); free(u2);
    return ok;
}
static bool mostly_upper(const char *s) {
    int alpha = 0, upper = 0;
    for (; *s; s++) {
        if (isalpha((unsigned char)*s)) { alpha++; if (isupper((unsigned char)*s)) upper++; }
    }
    return alpha > 0 && upper * 2 >= alpha;
}
static bool looks_like_heading(const char *line) {
    char *t = dup_trim(line);
    if (!t || !*t) { free(t); return false; }
    size_t n = strlen(t);
    if (n > 140) { free(t); return false; }
    bool key = contains_ci(t, "CHAPTER") || contains_ci(t, "ARTICLE") || contains_ci(t, "SECTION")
               || contains_ci(t, "CODE OF IOWA") || contains_ci(t, "VOLUME ") || contains_ci(t, "TITLE ");
    bool num = isdigit((unsigned char)t[0]) || strncmp(t, "§", 2) == 0 || strncmp(t, "Sec.", 4) == 0 || strncmp(t, "SEC.", 4) == 0;
    bool upperish = mostly_upper(t) && n < 90 && !strchr(t, '.');
    free(t);
    return key || num || upperish;
}

static void vec_push(SectionVec *v, Section s) {
    if (v->len == v->cap) {
        size_t nc = v->cap ? v->cap * 2 : 64;
        Section *p = realloc(v->items, nc * sizeof(*p));
        if (!p) { perror("realloc"); exit(1); }
        v->items = p; v->cap = nc;
    }
    v->items[v->len++] = s;
}

static bool mkdir_p(const char *path) {
    if (!path || !*path) return false;
    char tmp[PATH_MAX];
    if (snprintf(tmp, sizeof(tmp), "%s", path) >= (int)sizeof(tmp)) return false;

    size_t len = strlen(tmp);
    if (len == 0) return false;

    if (tmp[len - 1] == '/') tmp[len - 1] = '\0';

    for (char *p = tmp + 1; *p; p++) {
        if (*p == '/') {
            *p = '\0';
            if (mkdir(tmp, 0755) != 0 && errno != EEXIST) return false;
            *p = '/';
        }
    }
    if (mkdir(tmp, 0755) != 0 && errno != EEXIST) return false;
    return true;
}
static bool ensure_dir(const char *path) {
    struct stat st;
    if (stat(path, &st) == 0) return S_ISDIR(st.st_mode);
    return mkdir_p(path);
}
static bool ensure_parent_dirs(const char *path) {
    char tmp[PATH_MAX];
    if (snprintf(tmp, sizeof(tmp), "%s", path) >= (int)sizeof(tmp)) return false;
    char *slash = strrchr(tmp, '/');
    if (!slash) return true;
    *slash = '\0';
    if (!*tmp) return true;
    return mkdir_p(tmp);
}
static int write_file(const char *path, const char *data) {
    if (!ensure_parent_dirs(path)) return -1;
    FILE *f = fopen(path, "wb");
    if (!f) return -1;
    size_t n = data ? strlen(data) : 0;
    if (n && fwrite(data, 1, n, f) != n) { fclose(f); return -1; }
    fclose(f);
    return 0;
}
static char *read_file(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    if (fseek(f, 0, SEEK_END) != 0) { fclose(f); return NULL; }
    long sz = ftell(f);
    if (sz < 0) { fclose(f); return NULL; }
    rewind(f);
    char *buf = malloc((size_t)sz + 1);
    if (!buf) { fclose(f); return NULL; }
    size_t got = fread(buf, 1, (size_t)sz, f);
    fclose(f);
    buf[got] = '\0';
    return buf;
}
static char *shell_quote(const char *s) {
    StrBuf b; sb_init(&b);
    sb_append(&b, "'");
    for (const char *p = s; *p; p++) {
        if (*p == '\'') sb_append(&b, "'\\''");
        else sb_append_n(&b, p, 1);
    }
    sb_append(&b, "'");
    return b.buf;
}
static char *replace_all(const char *src, const char *needle, const char *repl) {
    if (!src) return xstrdup("");
    if (!needle || !*needle) return xstrdup(src);
    size_t src_len = strlen(src), nlen = strlen(needle), rlen = strlen(repl);
    size_t count = 0;
    const char *p = src;
    while ((p = strstr(p, needle))) { count++; p += nlen; }
    char *out = malloc(src_len + count * (rlen - nlen) + 1);
    if (!out) { perror("malloc"); exit(1); }
    char *d = out;
    p = src;
    const char *h;
    while ((h = strstr(p, needle))) {
        size_t n = (size_t)(h - p);
        memcpy(d, p, n); d += n;
        memcpy(d, repl, rlen); d += rlen;
        p = h + nlen;
    }
    strcpy(d, p);
    return out;
}
static char *run_capture(const char *cmd) {
    StrBuf out; sb_init(&out);
    char *full = malloc(strlen(cmd) + 8);
    if (!full) { perror("malloc"); exit(1); }
    sprintf(full, "%s 2>&1", cmd);
    FILE *fp = popen(full, "r");
    free(full);
    if (!fp) return NULL;
    char buf[4096];
    while (fgets(buf, sizeof(buf), fp)) sb_append(&out, buf);
    pclose(fp);
    return out.buf;
}
static unsigned long long fnv1a64(const char *s) {
    unsigned long long h = 1469598103934665603ULL;
    for (; s && *s; s++) {
        h ^= (unsigned char)*s;
        h *= 1099511628211ULL;
    }
    return h;
}
static char *extract_text_from_source(const char *path, const char *tmpdir) {
    const char *ext = strrchr(path, '.');
    if (ext && (strcasecmp(ext, ".txt") == 0 || strcasecmp(ext, ".md") == 0 || strcasecmp(ext, ".text") == 0))
        return read_file(path);

    if (ext && strcasecmp(ext, ".pdf") == 0) {
        char outpath[PATH_MAX];
        snprintf(outpath, sizeof(outpath), "%s/extract_%ld.txt", tmpdir, (long)getpid());
        char *qin = shell_quote(path);
        char *qout = shell_quote(outpath);
        StrBuf cmd; sb_init(&cmd);
        sb_appendf(&cmd, "pdftotext -layout -nopgbrk %s %s >/dev/null 2>&1", qin, qout);
        int rc = system(cmd.buf);
        sb_free(&cmd);
        free(qin); free(qout);
        if (rc != 0) return NULL;
        char *txt = read_file(outpath);
        unlink(outpath);
        return txt;
    }
    return read_file(path);
}
static char *load_references(char **refs, size_t nrefs, const char *tmpdir) {
    if (nrefs == 0) return xstrdup("");
    StrBuf out; sb_init(&out);
    for (size_t i = 0; i < nrefs; i++) {
        char *txt = extract_text_from_source(refs[i], tmpdir);
        if (!txt) {
            fprintf(stderr, "%s: warning: could not read reference %s\n", APP, refs[i]);
            continue;
        }
        sb_appendf(&out, "\n====================\nREFERENCE %zu\nSOURCE: %s\n--------------------\n", i + 1, refs[i]);
        sb_append(&out, txt);
        sb_append(&out, "\n");
        free(txt);
    }
    return out.buf ? out.buf : xstrdup("");
}
static void split_sections(const char *text, SectionVec *out, size_t max_chars) {
    char *copy = xstrdup(text ? text : "");
    char *save = NULL;
    char *line = strtok_r(copy, "\n", &save);
    char *title = xstrdup("(untitled section)");
    StrBuf buf; sb_init(&buf);
    size_t part = 1;
    while (line) {
        char *t = dup_trim(line);
        bool heading = looks_like_heading(t);
        if (heading && buf.len > 0) {
            vec_push(out, (Section){ .title = title, .text = buf.buf });
            title = xstrdup(t);
            sb_init(&buf);
            part = 1;
        } else if (heading && buf.len == 0 && strcmp(title, "(untitled section)") == 0) {
            free(title);
            title = xstrdup(t);
        } else {
            sb_append(&buf, line);
            sb_append(&buf, "\n");
            if (buf.len >= max_chars) {
                char titled[512];
                snprintf(titled, sizeof(titled), "%s%s", title, part == 1 ? "" : " (cont.)");
                vec_push(out, (Section){ .title = xstrdup(titled), .text = buf.buf });
                sb_init(&buf);
                part++;
            }
        }
        free(t);
        line = strtok_r(NULL, "\n", &save);
    }
    if (buf.len > 0) {
        char titled[512];
        snprintf(titled, sizeof(titled), "%s%s", title, part == 1 ? "" : " (cont.)");
        vec_push(out, (Section){ .title = xstrdup(titled), .text = buf.buf });
    } else {
        free(buf.buf);
    }
    free(title);
    free(copy);
    if (out->len == 0) vec_push(out, (Section){ .title = xstrdup("(untitled section)"), .text = xstrdup("") });
}

static char *build_prompt(const char *refs, const char *rolling, const Section *sec) {
    StrBuf b; sb_init(&b);
    sb_append(&b,
        "You are QCAv11, an offline constitutional review engine.\n"
        "Task hierarchy:\n"
        "1. Bill of Rights PDF is the controlling authority.\n"
        "2. Iowa Code PDF is subordinate text to be compared against it.\n"
        "3. Flag only plausible conflicts, burdens, chilling effects, compelled acts, or unauthorized intrusions.\n"
        "4. Do not claim a legal violation as fact; identify potential constitutional issues and explain why.\n"
        "5. If text is ambiguous or ordinary, say so and keep the analysis conservative.\n\n"
        "Return JSON only with keys:\n"
        "section_title, possible_amendments, hierarchy_result, explanation, supporting_arguments, challenging_arguments, section_summary.\n\n");
    sb_append(&b, "CONTROLLING REFERENCE: BILL OF RIGHTS\n");
    sb_append(&b, refs && *refs ? refs : "(none loaded)\n");
    sb_append(&b, "\nROLLING SUMMARY:\n");
    sb_append(&b, rolling && *rolling ? rolling : "(none)\n");
    sb_append(&b, "\nCURRENT IOWA CODE SECTION TITLE:\n");
    sb_append(&b, sec->title ? sec->title : "(untitled section)");
    sb_append(&b, "\n\nCURRENT IOWA CODE SECTION TEXT:\n");
    sb_append(&b, sec->text ? sec->text : "");
    sb_append(&b, "\n");
    return b.buf;
}

static char *extract_summary(const char *out, size_t limit) {
    if (!out) return xstrdup("");
    const char *key = "\"section_summary\"";
    const char *p = strstr(out, key);
    if (p) {
        const char *colon = strchr(p, ':');
        if (colon) {
            const char *s = colon + 1;
            while (*s && isspace((unsigned char)*s)) s++;
            if (*s == '"') {
                s++;
                StrBuf b; sb_init(&b);
                for (; *s && b.len < limit; s++) {
                    if (*s == '\\' && s[1]) { s++; sb_append_n(&b, s, 1); }
                    else if (*s == '"') break;
                    else sb_append_n(&b, s, 1);
                }
                return b.buf ? b.buf : xstrdup("");
            }
        }
    }
    StrBuf b; sb_init(&b);
    const char *s = out;
    while (*s && isspace((unsigned char)*s)) s++;
    for (; *s && b.len < limit; s++) sb_append_n(&b, s, 1);
    return b.buf ? b.buf : xstrdup("");
}

typedef enum {
    PROF_ULTRA_LOW,
    PROF_LOW,
    PROF_MEDIUM,
    PROF_HIGH
} Profile;

static const char *profile_name(Profile p) {
    switch (p) {
        case PROF_ULTRA_LOW: return "ultra-low";
        case PROF_LOW: return "low";
        case PROF_MEDIUM: return "medium";
        case PROF_HIGH: return "high";
    }
    return "low";
}

static void profile_defaults(Profile p, size_t *ctx_size, size_t *max_tokens, size_t *section_chars, size_t *summary_chars) {
    switch (p) {
        case PROF_ULTRA_LOW: *ctx_size = 512;  *max_tokens = 128; *section_chars = 900;  *summary_chars = 220; break;
        case PROF_LOW:       *ctx_size = 1024; *max_tokens = 192; *section_chars = 1400; *summary_chars = 320; break;
        case PROF_MEDIUM:    *ctx_size = 2048; *max_tokens = 256; *section_chars = 2200; *summary_chars = 450; break;
        case PROF_HIGH:      *ctx_size = 4096; *max_tokens = 384; *section_chars = 3200; *summary_chars = 700; break;
    }
}

static char *runner_cmd_from_template(const char *tmpl, const char *prompt_file, const char *prompt_text, size_t max_tokens, size_t ctx_size) {
    char max_buf[32], ctx_buf[32];
    snprintf(max_buf, sizeof(max_buf), "%zu", max_tokens);
    snprintf(ctx_buf, sizeof(ctx_buf), "%zu", ctx_size);

    char *qf = shell_quote(prompt_file);
    char *qp = shell_quote(prompt_text ? prompt_text : "");

    char *a = replace_all(tmpl, "{PROMPT_FILE}", qf);
    char *b = replace_all(a, "{PROMPT}", qp);
    char *c = replace_all(b, "{MAX_TOKENS}", max_buf);
    char *d = replace_all(c, "{CTX_SIZE}", ctx_buf);

    free(qf); free(qp); free(a); free(b); free(c);

    StrBuf out; sb_init(&out);
    sb_append(&out, d);
    if (!strstr(d, "-n ") && !strstr(d, "--n-predict ")) sb_appendf(&out, " -n %zu", max_tokens);
    if (!strstr(d, "--simple-io")) sb_append(&out, " --simple-io");
    if (!strstr(d, "--no-display-prompt")) sb_append(&out, " --no-display-prompt");
    if (!strstr(d, "--skip-chat-parsing")) sb_append(&out, " --skip-chat-parsing");
    if (!strstr(d, "--single-turn")) sb_append(&out, " --single-turn");
    free(d);
    return out.buf;
}

static void csv_escape(FILE *f, const char *s) {
    fputc('"', f);
    for (; s && *s; s++) {
        if (*s == '"') fputc('"', f);
        fputc(*s, f);
    }
    fputc('"', f);
}

static void usage(void) {
    fprintf(stderr,
        "Usage: %s --input FILE --reference FILE --outdir DIR [options]\n\n"
        "Options:\n"
        "  --runner-template CMD   llama.cpp template using {PROMPT} or {PROMPT_FILE}\n"
        "  --profile NAME          ultra-low | low | medium | high (default: low)\n"
        "  --ctx-size N            Override context size\n"
        "  --max-tokens N          Override generation cap per section\n"
        "  --max-section-chars N   Override chunk size before forced split\n"
        "  --summary-chars N       Override rolling summary limit\n"
        "  --interactive           Pause between sections so users can watch the process\n"
        "  --show-prompts          Print prompts before each llama.cpp call\n"
        "  --resume                Resume from checkpoint files in the output directory\n"
        "  --reset                 Ignore any existing checkpoint and start over\n"
        "  --pdf                   Try to write report.pdf with pandoc if available\n"
        "  --list-profiles         Print the built-in memory profiles and exit\n\n"
        "Example:\n"
        "  %s --profile low --input \"iowa.pdf\" --reference \"bill-of-rights.pdf\" --outdir out \\\n"
        "     --runner-template 'llama-cli -m model.gguf --jinja --reasoning on --reasoning-budget -1 -c {CTX_SIZE} -p {PROMPT}'\n",
        APP, APP);
}

static void list_profiles(void) {
    puts("ultra-low  ctx=512  tokens=128  section=900  summary=220");
    puts("low        ctx=1024 tokens=192  section=1400 summary=320");
    puts("medium     ctx=2048 tokens=256  section=2200 summary=450");
    puts("high       ctx=4096 tokens=384  section=3200 summary=700");
}

int main(int argc, char **argv) {
    const char *input = NULL;
    const char *outdir = NULL;
    const char *runner_template = NULL;
    bool want_pdf = false, interactive = false, show_prompts = false, resume = true, reset = false, list_profiles_flag = false;

    Profile profile = PROF_LOW;
    size_t ctx_size = 0, max_tokens = 0, max_section_chars = 0, summary_chars = 0;

    char **refs = NULL;
    size_t nrefs = 0, refs_cap = 0;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--input") == 0 && i + 1 < argc) input = argv[++i];
        else if (strcmp(argv[i], "--reference") == 0 && i + 1 < argc) {
            if (nrefs == refs_cap) {
                size_t nc = refs_cap ? refs_cap * 2 : 8;
                char **p = realloc(refs, nc * sizeof(*p));
                if (!p) { perror("realloc"); return 1; }
                refs = p; refs_cap = nc;
            }
            refs[nrefs++] = argv[++i];
        } else if (strcmp(argv[i], "--outdir") == 0 && i + 1 < argc) outdir = argv[++i];
        else if (strcmp(argv[i], "--runner-template") == 0 && i + 1 < argc) runner_template = argv[++i];
        else if (strcmp(argv[i], "--profile") == 0 && i + 1 < argc) {
            const char *p = argv[++i];
            if (strcmp(p, "ultra-low") == 0) profile = PROF_ULTRA_LOW;
            else if (strcmp(p, "low") == 0) profile = PROF_LOW;
            else if (strcmp(p, "medium") == 0) profile = PROF_MEDIUM;
            else if (strcmp(p, "high") == 0) profile = PROF_HIGH;
            else { fprintf(stderr, "%s: unknown profile %s\n", APP, p); return 1; }
        } else if (strcmp(argv[i], "--ctx-size") == 0 && i + 1 < argc) ctx_size = (size_t)strtoul(argv[++i], NULL, 10);
        else if (strcmp(argv[i], "--max-tokens") == 0 && i + 1 < argc) max_tokens = (size_t)strtoul(argv[++i], NULL, 10);
        else if (strcmp(argv[i], "--max-section-chars") == 0 && i + 1 < argc) max_section_chars = (size_t)strtoul(argv[++i], NULL, 10);
        else if (strcmp(argv[i], "--summary-chars") == 0 && i + 1 < argc) summary_chars = (size_t)strtoul(argv[++i], NULL, 10);
        else if (strcmp(argv[i], "--pdf") == 0) want_pdf = true;
        else if (strcmp(argv[i], "--interactive") == 0) interactive = true;
        else if (strcmp(argv[i], "--show-prompts") == 0) show_prompts = true;
        else if (strcmp(argv[i], "--resume") == 0) resume = true;
        else if (strcmp(argv[i], "--reset") == 0) reset = true;
        else if (strcmp(argv[i], "--list-profiles") == 0) list_profiles_flag = true;
        else { usage(); return 1; }
    }

    if (list_profiles_flag) { list_profiles(); return 0; }
    if (!input || !outdir || nrefs == 0) { usage(); return 1; }

    profile_defaults(profile, &ctx_size, &max_tokens, &max_section_chars, &summary_chars);
    if (ctx_size == 0) ctx_size = 1024;
    if (max_tokens == 0) max_tokens = 192;
    if (max_section_chars == 0) max_section_chars = 1400;
    if (summary_chars == 0) summary_chars = 320;

    if (!ensure_dir(outdir)) { fprintf(stderr, "%s: cannot create outdir %s\n", APP, outdir); return 1; }

    char workdir[PATH_MAX];
    snprintf(workdir, sizeof(workdir), "%s/work", outdir);
    if (!ensure_dir(workdir)) { fprintf(stderr, "%s: cannot create workdir %s\n", APP, workdir); return 1; }

    char state_dir[PATH_MAX];
    snprintf(state_dir, sizeof(state_dir), "%s/.qca_state", outdir);
    if (!ensure_dir(state_dir)) { fprintf(stderr, "%s: cannot create state dir %s\n", APP, state_dir); return 1; }

    char *input_text = extract_text_from_source(input, workdir);
    if (!input_text) { fprintf(stderr, "%s: could not read input %s\n", APP, input); return 1; }

    char *refs_text = load_references(refs, nrefs, workdir);

    char report_md[PATH_MAX], report_csv[PATH_MAX], report_json[PATH_MAX];
    snprintf(report_md, sizeof(report_md), "%s/report.md", outdir);
    snprintf(report_csv, sizeof(report_csv), "%s/index.csv", outdir);
    snprintf(report_json, sizeof(report_json), "%s/index.json", outdir);

    char state_next[PATH_MAX], state_sum[PATH_MAX], state_hash[PATH_MAX];
    snprintf(state_next, sizeof(state_next), "%s/next_section.txt", state_dir);
    snprintf(state_sum, sizeof(state_sum), "%s/rolling_summary.txt", state_dir);
    snprintf(state_hash, sizeof(state_hash), "%s/input_hash.txt", state_dir);

    unsigned long long input_hash = fnv1a64(input_text);
    char input_hash_buf[64];
    snprintf(input_hash_buf, sizeof(input_hash_buf), "%llu", input_hash);

    size_t start_index = 1;
    if (resume && !reset) {
        char *existing_hash = read_file(state_hash);
        if (existing_hash) {
            trim_inplace(existing_hash);
            if (strcmp(existing_hash, input_hash_buf) == 0) {
                char *n = read_file(state_next);
                if (n) {
                    trim_inplace(n);
                    size_t v = (size_t)strtoull(n, NULL, 10);
                    if (v > 0) start_index = v;
                    free(n);
                }
            }
            free(existing_hash);
        }
    }
    if (!resume || reset) {
        write_file(state_hash, input_hash_buf);
        write_file(state_next, "1");
        write_file(state_sum, "");
    }

    char *rolling_loaded = read_file(state_sum);
    char rolling[8192];
    rolling[0] = '\0';
    if (rolling_loaded && *rolling_loaded) snprintf(rolling, sizeof(rolling), "%s", rolling_loaded);
    free(rolling_loaded);

    SectionVec sections = {0};
    split_sections(input_text, &sections, max_section_chars);

    FILE *md = fopen(report_md, (resume && !reset && start_index > 1) ? "ab" : "wb");
    FILE *csv = fopen(report_csv, (resume && !reset && start_index > 1) ? "ab" : "wb");
    FILE *js = fopen(report_json, (resume && !reset && start_index > 1) ? "ab" : "wb");
    if (!md || !csv || !js) { perror("open report"); return 1; }

    if (!(resume && !reset && start_index > 1)) {
        fputs("# QCAv11 Report\n\n", md);
        fprintf(md, "- Input: `%s`\n", input);
        fprintf(md, "- Reference count: %zu\n", nrefs);
        fprintf(md, "- Profile: %s\n\n", profile_name(profile));

        fputs("section_index,section_title,raw_output_file,summary\n", csv);
        fputs("{\n  \"sections\": [\n", js);
    }

    size_t json_count = (resume && !reset && start_index > 1) ? (start_index - 1) : 0;

    for (size_t i = start_index - 1; i < sections.len; i++) {
        Section *sec = &sections.items[i];
        char prompt_path[PATH_MAX], raw_path[PATH_MAX], section_json[PATH_MAX];
        snprintf(prompt_path, sizeof(prompt_path), "%s/section_%04zu.prompt.txt", workdir, i + 1);
        snprintf(raw_path, sizeof(raw_path), "%s/section_%04zu.raw.txt", workdir, i + 1);
        snprintf(section_json, sizeof(section_json), "%s/section_%04zu.json", outdir, i + 1);

        char *prompt = build_prompt(refs_text, rolling, sec);
        write_file(prompt_path, prompt);

        if (!runner_template || !*runner_template) {
            fprintf(stderr, "%s: missing --runner-template\n", APP);
            return 1;
        }

        char *cmd = runner_cmd_from_template(runner_template, prompt_path, prompt, max_tokens, ctx_size);
        if (show_prompts) {
            printf("\n===== PROMPT %zu / %zu =====\n%s\n===========================\n", i + 1, sections.len, prompt);
        }
        printf("[%zu/%zu] %s\n", i + 1, sections.len, sec->title ? sec->title : "(untitled section)");
        fflush(stdout);

        char *raw = run_capture(cmd);
        if (!raw) { fprintf(stderr, "%s: runner failed\n", APP); return 1; }

        write_file(raw_path, raw);
        write_file(section_json, raw);

        char *summary = extract_summary(raw, summary_chars);
        snprintf(rolling, sizeof(rolling), "%s", summary);
        free(summary);

        write_file(state_next, "");
        {
            char buf[64];
            snprintf(buf, sizeof(buf), "%zu", i + 2);
            write_file(state_next, buf);
        }
        write_file(state_sum, rolling);
        write_file(state_hash, input_hash_buf);

        fprintf(md, "## %s\n\n", sec->title ? sec->title : "(untitled section)");
        fputs("### Raw output\n\n```text\n", md);
        fputs(raw, md);
        fputs("\n```\n\n", md);

        fprintf(csv, "%zu,", i + 1);
        csv_escape(csv, sec->title ? sec->title : "(untitled section)");
        fputc(',', csv);
        csv_escape(csv, raw_path);
        fputc(',', csv);
        csv_escape(csv, rolling);
        fputc('\n', csv);

        if (json_count++) fputs(",\n", js);
        fputs("    {\n", js);
        fprintf(js, "      \"index\": %zu,\n", i + 1);
        fputs("      \"section_title\": ", js); csv_escape(js, sec->title ? sec->title : "(untitled section)"); fputs(",\n", js);
        fputs("      \"raw_output_file\": ", js); csv_escape(js, raw_path); fputs(",\n", js);
        fputs("      \"summary\": ", js); csv_escape(js, rolling); fputc('\n', js);
        fputs("    }", js);

        free(prompt);
        free(cmd);
        free(raw);

        if (interactive) {
            printf("\n--- press ENTER for next section, or q then ENTER to stop ---\n");
            char line[16];
            if (!fgets(line, sizeof(line), stdin)) break;
            if (line[0] == 'q' || line[0] == 'Q') break;
        }
    }

    fputs("\n  ]\n}\n", js);
    fclose(md); fclose(csv); fclose(js);

    if (want_pdf) {
        char pdf_cmd[PATH_MAX * 2];
        snprintf(pdf_cmd, sizeof(pdf_cmd), "pandoc %s -o %s/report.pdf >/dev/null 2>&1", report_md, outdir);
        system(pdf_cmd);
    }

    printf("Done. Reports written to %s\n", outdir);
    printf("Resume files in %s/.qca_state/\n", outdir);
    printf("Profiles: use --list-profiles\n");

    for (size_t i = 0; i < sections.len; i++) {
        free(sections.items[i].title);
        free(sections.items[i].text);
    }
    free(sections.items);
    free(input_text);
    free(refs_text);
    free(refs);
    return 0;
}
