# QCAv18-4

Working bundle assembled from the patched QCAv18-3 release.

Contents:
- QCAv18-4 executable
- Python runner
- Mock runner

Configure your production runner by editing qca_runner.py or replacing the mock wrapper with your llama/Qwen invocation.
