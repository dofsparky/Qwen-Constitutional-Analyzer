/* QCAv18-4
 * Placeholder source manifest.
 * Replace this file with the final patched source before release.
 */
int main(void){return 0;}
