# Linux

1. Install build-essential and Python 3.
2. Extract the bundle.
3. Build with make or use the supplied binary.
4. Configure runner/qca_runner.py.
