# Windows (WSL)

1. Install WSL2 and Ubuntu.
2. Install Python 3 and your inference backend.
3. Extract the QCAv18-4 bundle.
4. Run make (or use the supplied binary).
5. Configure runner/qca_runner.py.
