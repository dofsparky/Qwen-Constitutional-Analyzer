#!/usr/bin/env bash
echo "Benchmark placeholder"
time ./QCAv18-4 "$@"
