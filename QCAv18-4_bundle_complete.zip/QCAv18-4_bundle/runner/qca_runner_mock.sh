#!/bin/sh
DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
exec python3 -u "$DIR/qca_runner.py" "$@"
