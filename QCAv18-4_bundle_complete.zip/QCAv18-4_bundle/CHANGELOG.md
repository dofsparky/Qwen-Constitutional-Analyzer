QCAv18-4
- Runner integration
- Blank report fixes
- Improved output handling
- Python runner included
