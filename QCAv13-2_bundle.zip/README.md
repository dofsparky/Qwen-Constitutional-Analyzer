# QCAv13-2 lamerized

QCAv13-2 keeps the cached-index workflow and adds two optional memory controls.

## New options

- `--thinking-scale N` increases the effective context window, generation budget, and reference retrieval depth.
- `--lookback N` includes up to N previous input sections in the prompt.

Defaults are unchanged when you do not pass these options.

## Build

```bash
make
```

## Example

```bash
./QCAv13-2   --profile ultra   --thinking-scale 2   --lookback 1   --input "/home/delta/iowa/2022-iowa-code.pdf"   --reference "/home/delta/references/bill-of-rights.pdf"   --outdir "iowa-2022"   --runner-template 'llama-cli -m /home/delta/models/Qwen3-4B-Q4_K_M.gguf --jinja --reasoning on --reasoning-budget -1 -c {CTX_SIZE} -p {PROMPT}'
```

## Cache and resume

- Cached indexes are stored under `--outdir/.qca_cache/`
- Resume state is stored under `--outdir/.qca_state/`
- Use `--reindex` to rebuild caches
- Use `--reset` to restart the run from the beginning
