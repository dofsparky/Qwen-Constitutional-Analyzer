#!/usr/bin/env python3 -u
import os, sys, subprocess, time, socket, json, re, pathlib, signal

SOCK = os.environ.get("QCA_BACKEND_SOCKET", "/tmp/qca17_backend.sock")
BACKEND_MODE = os.environ.get("QCA_BACKEND_MODE", "mock")
BACKEND_CMD = os.environ.get("QCA_BACKEND_CMD", "")
ROOT = pathlib.Path(__file__).resolve().parent
DAEMON = ROOT / "qca_backend_daemon.py"

def parse_prompt_file(argv):
    prompt_file = None
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-f", "--file", "--prompt-file") and i + 1 < len(argv):
            prompt_file = argv[i + 1]
            i += 2
            continue
        if a.startswith("-f") and len(a) > 2:
            prompt_file = a[2:]
        i += 1
    return prompt_file

def ensure_backend():
    if os.path.exists(SOCK):
        try:
            s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            s.settimeout(0.2)
            s.connect(SOCK)
            s.close()
            return
        except Exception:
            try:
                os.unlink(SOCK)
            except Exception:
                pass
    env = os.environ.copy()
    env["QCA_BACKEND_SOCKET"] = SOCK
    env["QCA_BACKEND_MODE"] = BACKEND_MODE
    if BACKEND_CMD:
        env["QCA_BACKEND_CMD"] = BACKEND_CMD
    subprocess.Popen([sys.executable, "-u", str(DAEMON)], env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

def sanitize(text: str) -> str:
    lines = []
    in_think = False
    for raw_line in text.splitlines():
        line = raw_line.rstrip("\r")
        if "<think>" in line:
            in_think = True
            continue
        if "</think>" in line:
            in_think = False
            continue
        if in_think:
            continue
        if any(line.startswith(p) for p in (
            "load_backend:", "Loading model", "build      :", "model      :", "modalities :",
            "available commands:", "llama_memory_breakdown_print:", "[ Prompt:", "Prompt: ", "Generation: ",
            "Exiting..."
        )):
            continue
        if "<<<QCA_RESPONSE_END>>>" in line:
            continue
        if not line.strip():
            continue
        lines.append(line)
    return "\n".join(lines).strip()

def request(prompt: str) -> str:
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.connect(SOCK)
    s.sendall(prompt.encode("utf-8") + b"\n<<<QCA_PROMPT_END>>>\n")
    chunks = []
    while True:
        data = s.recv(4096)
        if not data:
            break
        chunks.append(data)
        if b"<<<QCA_RESPONSE_END>>>" in data:
            break
    s.close()
    return b"".join(chunks).decode("utf-8", errors="ignore")

def main():
    ensure_backend()
    prompt_file = parse_prompt_file(sys.argv[1:])
    prompt = ""
    if prompt_file and os.path.exists(prompt_file):
        with open(prompt_file, "r", encoding="utf-8", errors="ignore") as f:
            prompt = f.read()
    else:
        # fallback: read stdin if runner feeds content directly
        prompt = sys.stdin.read()

    raw = request(prompt)
    clean = sanitize(raw)
    print(clean)

if __name__ == "__main__":
    main()
