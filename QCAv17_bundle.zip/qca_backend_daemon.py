#!/usr/bin/env python3 -u
import os, sys, socket, threading, json, time, re, hashlib

SOCK = os.environ.get("QCA_BACKEND_SOCKET", "/tmp/qca17_backend.sock")
MODE = os.environ.get("QCA_BACKEND_MODE", "mock")  # mock or simple
RUN_TAG = os.environ.get("QCA_BACKEND_TAG", "QCAv17")

def classify(prompt: str) -> str:
    p = prompt.lower()
    if "search" in p or "warrant" in p:
        obj = {
            "section_title": "Chapter 456",
            "answer": "Possible Fourth Amendment issue because the section authorizes searches and may allow exceptions that need close scrutiny.",
            "possible_amendments": ["Fourth Amendment"],
            "evidence": ["search authority", "warrant exception"],
            "confidence": 0.91,
            "model_tps": 34.8,
        }
    elif "petition" in p or "fee" in p:
        obj = {
            "section_title": "Chapter 789",
            "answer": "Possible First Amendment burden because fees or restrictions may chill petitioning and related speech.",
            "possible_amendments": ["First Amendment"],
            "evidence": ["petition restriction", "publication fee"],
            "confidence": 0.89,
            "model_tps": 34.8,
        }
    else:
        obj = {
            "section_title": "Chapter 123",
            "answer": "Possible First Amendment and due-process concerns because the section requires a license and imposes a penalty.",
            "possible_amendments": ["First Amendment", "Fifth Amendment"],
            "evidence": ["license required", "penalty for violation"],
            "confidence": 0.93,
            "model_tps": 34.8,
        }
    return json.dumps(obj)

def handle(conn):
    with conn:
        data = b""
        while True:
            chunk = conn.recv(4096)
            if not chunk:
                return
            data += chunk
            if b"\n<<<QCA_PROMPT_END>>>\n" in data or data.endswith(b"<<<QCA_PROMPT_END>>>"):
                break
        prompt = data.decode("utf-8", errors="ignore").replace("<<<QCA_PROMPT_END>>>", "")
        # Simulate noisy model output, then provide clean final JSON.
        # The wrapper sanitizes this to keep only the JSON.
        tps = 34.8 if len(prompt) > 1000 else 41.2
        out = []
        out.append("load_backend: loaded CPU backend from /usr/lib/x86_64-linux-gnu/ggml/backends0/libggml-cpu-icelake.so")
        out.append("Loading model...")
        out.append("<think>")
        out.append("internal reasoning")
        out.append("</think>")
        out.append(f"[ Prompt: 20.1 t/s | Generation: {tps:.1f} t/s ]")
        out.append(classify(prompt))
        out.append("<<<QCA_RESPONSE_END>>>")
        resp = "\n".join(out) + "\n"
        conn.sendall(resp.encode("utf-8"))

def main():
    try:
        os.unlink(SOCK)
    except FileNotFoundError:
        pass
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.bind(SOCK)
    s.listen(8)
    print(f"{RUN_TAG} backend listening on {SOCK}", file=sys.stderr, flush=True)
    while True:
        conn, _ = s.accept()
        threading.Thread(target=handle, args=(conn,), daemon=True).start()

if __name__ == "__main__":
    main()
