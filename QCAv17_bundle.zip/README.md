# QCAv17 lamerized

QCAv17 packages the same offline constitutional analyzer with a wrapper-based persistent inference path.

## Architectural focus

- persistent inference through a long-lived local backend
- output sanitization before results are saved or continued
- minimal continuation prompts
- pipeline-friendly prompt generation
- structured terminal progress with ETA and chunk rate

## How the persistent path works

QCA still launches a runner command, but the runner is now a thin client wrapper.

The wrapper:

1. starts a long-lived local backend if needed,
2. sends the prompt to that backend,
3. strips banners, timing lines, memory diagnostics, and `<think>` content,
4. prints only the final assistant response back to QCA.

That keeps the model resident across the run while QCA remains unchanged.

## Backend protocol

The wrapper and backend communicate over a Unix socket.

The backend reads until:

```text
<<<QCA_PROMPT_END>>>
```

and ends each response with:

```text
<<<QCA_RESPONSE_END>>>
```

## Example usage

```bash
export QCA_BACKEND_MODE=mock
./QCAv17   --profile ultra   --throughput max   --workers auto   --prompt-budget 3000   --input "/home/delta/C/iowa_code_2026.txt"   --reference "/home/delta/references/bill_of_rights.txt"   --outdir "/home/delta/iowa/iowa-qcav17"   --runner-template 'python3 -u /home/delta/QCAv17/qca_persistent_wrapper.py -f {PROMPT_FILE}'
```

For a real model backend, replace the mock daemon behavior with a wrapper around your local llama.cpp server process.

## Notes

- `QCAv17` keeps the prefetching pipeline from the previous release
- continuation prompts are shorter and do not replay the full base prompt
- the wrapper emits cleaned output so the report files stay readable
- `QCA_BACKEND_MODE=mock` is intended for smoke tests and offline validation
