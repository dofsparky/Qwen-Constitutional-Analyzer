# QCAv14-1 lamerized

QCAv14-1 keeps the cached document-pack workflow but trims the prompt so Qwen only sees the most relevant matches.

## What changed

- `--prepare` / `--index-only` still build and cache the documents
- The prompt now uses compact cross-reference context instead of dumping the whole atlas
- Analysis mode still works when `--questions` is omitted
- Question mode still works when `--questions` is provided

## Why this is faster

The previous release pushed far too much atlas data into one prompt. QCAv14-1 keeps the cache, but only sends:
- task instructions
- top matches
- short cross-reference context

That keeps the prompt inside the context window and leaves room for Qwen’s answer.

## Example

```bash
./QCAv14-1   --profile ultra   --workers auto   --input "/home/delta/iowa/2022-iowa-code.pdf"   --reference "/home/delta/references/bill-of-rights.pdf"   --outdir "iowa-2022"   --runner-template 'llama-cli -m /home/delta/models/Qwen3-4B-Q4_K_M.gguf --jinja --reasoning on --reasoning-budget -1 -c {CTX_SIZE} -n 2048 --temp 0.6 --top-k 40 --top-p 0.95 --min-p 0.05 --repeat-penalty 1.05 -f {PROMPT_FILE}'
```

## Notes

- `--prepare` and `--index-only` do not require `--runner-template`
- If a cache already exists, later runs can reuse it
- Analysis mode automatically activates when `--questions` is omitted
