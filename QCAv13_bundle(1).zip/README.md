# QCAv13 lamerized

QCAv13 adds cached document indexes, resume support, and multiple runtime memory profiles.

## What it does

- Loads PDF or text input with `--input`
- Loads PDF or text references with `--reference`
- Builds a cached index for each document under `--outdir/.qca_cache/`
- Reuses the cache on later runs if the source has not changed
- Resumes from `--outdir/.qca_state/`
- Supports `--profile ultra` for `-c 8192`
- Keeps the Bill of Rights as the controlling reference over the Iowa Code

## Build

```bash
make
```

## Profiles

- `ultra-low`  512 ctx
- `low`        1024 ctx
- `medium`     2048 ctx
- `high`       4096 ctx
- `ultra`      8192 ctx

List them with:

```bash
./QCAv13 --list-profiles
```

## Example

```bash
./QCAv13   --profile ultra   --input "/home/delta/iowa/2022-iowa-code.pdf"   --reference "/home/delta/references/bill-of-rights.pdf"   --outdir "iowa-2022"   --runner-template 'llama-cli -m /home/delta/models/Qwen3-4B-Q4_K_M.gguf --jinja --reasoning on --reasoning-budget -1 -c {CTX_SIZE} -p {PROMPT}'
```

## Resume

If stopped, rerun the same command and it continues from the next unfinished section.

Use `--reset` to start over and `--reindex` to rebuild cached document indexes.

## Output

- `report.md`
- `index.csv`
- `index.json`
- `.qca_cache/`
- `.qca_state/`
- `work/section_XXXX.prompt.txt`
- `work/section_XXXX.raw.txt`
- `work/section_XXXX.json`
