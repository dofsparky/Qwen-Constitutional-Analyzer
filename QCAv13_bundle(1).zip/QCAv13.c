
#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#define APP "QCAv13"

typedef struct {
    char *title;
    char *text;
} Section;

typedef struct {
    Section *items;
    size_t len, cap;
} SectionVec;

typedef struct {
    char *buf;
    size_t len, cap;
} StrBuf;

typedef struct {
    char *source_path;
    char *source_kind;   // pdf, text
    char *source_hash;   // hex string
    SectionVec sections;
} DocIndex;

typedef enum {
    PROF_ULTRA_LOW,
    PROF_LOW,
    PROF_MEDIUM,
    PROF_HIGH,
    PROF_ULTRA
} Profile;

/* -------------------- utilities -------------------- */

static void sb_init(StrBuf *b) { b->buf = NULL; b->len = b->cap = 0; }
static void sb_free(StrBuf *b) { free(b->buf); b->buf = NULL; b->len = b->cap = 0; }

static void sb_reserve(StrBuf *b, size_t add) {
    size_t need = b->len + add + 1;
    if (need <= b->cap) return;
    size_t nc = b->cap ? b->cap : 1024;
    while (nc < need) nc *= 2;
    char *p = realloc(b->buf, nc);
    if (!p) { perror("realloc"); exit(1); }
    b->buf = p;
    b->cap = nc;
}

static void sb_append_n(StrBuf *b, const char *s, size_t n) {
    if (!s || !n) return;
    sb_reserve(b, n);
    memcpy(b->buf + b->len, s, n);
    b->len += n;
    b->buf[b->len] = '\0';
}
static void sb_append(StrBuf *b, const char *s) { if (s) sb_append_n(b, s, strlen(s)); }
static void sb_appendf(StrBuf *b, const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    va_list ap2;
    va_copy(ap2, ap);
    int n = vsnprintf(NULL, 0, fmt, ap);
    va_end(ap);
    if (n < 0) { va_end(ap2); return; }
    sb_reserve(b, (size_t)n);
    vsnprintf(b->buf + b->len, b->cap - b->len, fmt, ap2);
    va_end(ap2);
    b->len += (size_t)n;
}

static char *xstrdup(const char *s) {
    if (!s) s = "";
    size_t n = strlen(s);
    char *p = malloc(n + 1);
    if (!p) { perror("malloc"); exit(1); }
    memcpy(p, s, n + 1);
    return p;
}

static char *trim_inplace(char *s) {
    if (!s) return s;
    char *start = s;
    while (*start && isspace((unsigned char)*start)) start++;
    char *end = start + strlen(start);
    while (end > start && isspace((unsigned char)end[-1])) end--;
    size_t n = (size_t)(end - start);
    if (start != s) memmove(s, start, n);
    s[n] = '\0';
    return s;
}

static char *dup_trim(const char *s) {
    return trim_inplace(xstrdup(s));
}

static char *to_upper_dup(const char *s) {
    size_t n = strlen(s ? s : "");
    char *p = malloc(n + 1);
    if (!p) { perror("malloc"); exit(1); }
    for (size_t i = 0; i < n; i++) p[i] = (char)toupper((unsigned char)s[i]);
    p[n] = '\0';
    return p;
}

static bool contains_ci(const char *hay, const char *needle) {
    char *u1 = to_upper_dup(hay ? hay : "");
    char *u2 = to_upper_dup(needle ? needle : "");
    bool ok = strstr(u1, u2) != NULL;
    free(u1); free(u2);
    return ok;
}

static bool mostly_upper(const char *s) {
    int alpha = 0, upper = 0;
    for (; *s; s++) {
        if (isalpha((unsigned char)*s)) {
            alpha++;
            if (isupper((unsigned char)*s)) upper++;
        }
    }
    return alpha > 0 && upper * 2 >= alpha;
}

static bool looks_like_heading(const char *line) {
    char *t = dup_trim(line);
    if (!t || !*t) { free(t); return false; }
    size_t n = strlen(t);
    if (n > 140) { free(t); return false; }
    bool key = contains_ci(t, "CHAPTER") || contains_ci(t, "ARTICLE") || contains_ci(t, "SECTION")
               || contains_ci(t, "CODE OF IOWA") || contains_ci(t, "VOLUME ") || contains_ci(t, "TITLE ");
    bool num = isdigit((unsigned char)t[0]) || strncmp(t, "§", 2) == 0 || strncmp(t, "Sec.", 4) == 0 || strncmp(t, "SEC.", 4) == 0;
    bool upperish = mostly_upper(t) && n < 90 && !strchr(t, '.');
    free(t);
    return key || num || upperish;
}

static bool ensure_dir(const char *path) {
    struct stat st;
    if (stat(path, &st) == 0) return S_ISDIR(st.st_mode);
    return mkdir(path, 0755) == 0;
}

static bool ensure_parent_dirs(const char *path) {
    char tmp[PATH_MAX];
    snprintf(tmp, sizeof(tmp), "%s", path);
    for (char *p = tmp + 1; *p; p++) {
        if (*p == '/') {
            *p = '\0';
            if (mkdir(tmp, 0755) != 0 && errno != EEXIST) return false;
            *p = '/';
        }
    }
    return true;
}

static int write_file(const char *path, const char *data) {
    if (!ensure_parent_dirs(path)) return -1;
    FILE *f = fopen(path, "wb");
    if (!f) return -1;
    size_t n = data ? strlen(data) : 0;
    if (n && fwrite(data, 1, n, f) != n) { fclose(f); return -1; }
    fclose(f);
    return 0;
}

static char *read_file(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    if (fseek(f, 0, SEEK_END) != 0) { fclose(f); return NULL; }
    long sz = ftell(f);
    if (sz < 0) { fclose(f); return NULL; }
    rewind(f);
    char *buf = malloc((size_t)sz + 1);
    if (!buf) { fclose(f); return NULL; }
    size_t got = fread(buf, 1, (size_t)sz, f);
    fclose(f);
    buf[got] = '\0';
    return buf;
}

static char *shell_quote(const char *s) {
    StrBuf b; sb_init(&b);
    sb_append(&b, "'");
    for (const char *p = s; p && *p; p++) {
        if (*p == '\'') sb_append(&b, "'\\''");
        else sb_append_n(&b, p, 1);
    }
    sb_append(&b, "'");
    return b.buf;
}

static char *replace_all(const char *src, const char *needle, const char *repl) {
    if (!src) return xstrdup("");
    if (!needle || !*needle) return xstrdup(src);
    size_t src_len = strlen(src), nlen = strlen(needle), rlen = strlen(repl);
    size_t count = 0;
    const char *p = src;
    while ((p = strstr(p, needle))) { count++; p += nlen; }
    char *out = malloc(src_len + count * (rlen - nlen) + 1);
    if (!out) { perror("malloc"); exit(1); }
    char *d = out;
    p = src;
    const char *h;
    while ((h = strstr(p, needle))) {
        size_t n = (size_t)(h - p);
        memcpy(d, p, n); d += n;
        memcpy(d, repl, rlen); d += rlen;
        p = h + nlen;
    }
    strcpy(d, p);
    return out;
}

static char *run_capture(const char *cmd) {
    StrBuf out; sb_init(&out);
    char *full = malloc(strlen(cmd) + 8);
    if (!full) { perror("malloc"); exit(1); }
    sprintf(full, "%s 2>&1", cmd);
    FILE *fp = popen(full, "r");
    free(full);
    if (!fp) return NULL;
    char buf[4096];
    while (fgets(buf, sizeof(buf), fp)) sb_append(&out, buf);
    pclose(fp);
    return out.buf;
}

static uint64_t fnv1a64_bytes(const unsigned char *buf, size_t len) {
    uint64_t h = 1469598103934665603ULL;
    for (size_t i = 0; i < len; i++) {
        h ^= buf[i];
        h *= 1099511628211ULL;
    }
    return h;
}

static uint64_t fnv1a64_str(const char *s) {
    return fnv1a64_bytes((const unsigned char *)(s ? s : ""), strlen(s ? s : ""));
}

/* -------------------- doc loading -------------------- */

static char *extract_text_from_source(const char *path, const char *tmpdir, char **kind_out) {
    const char *ext = strrchr(path, '.');
    if (ext && (strcasecmp(ext, ".txt") == 0 || strcasecmp(ext, ".md") == 0 || strcasecmp(ext, ".text") == 0)) {
        if (kind_out) *kind_out = xstrdup("text");
        return read_file(path);
    }

    if (ext && strcasecmp(ext, ".pdf") == 0) {
        if (kind_out) *kind_out = xstrdup("pdf");
        char outpath[PATH_MAX];
        snprintf(outpath, sizeof(outpath), "%s/extract_%ld.txt", tmpdir, (long)getpid());
        char *qin = shell_quote(path);
        char *qout = shell_quote(outpath);
        StrBuf cmd; sb_init(&cmd);
        sb_appendf(&cmd, "pdftotext -layout -nopgbrk %s %s >/dev/null 2>&1", qin, qout);
        int rc = system(cmd.buf);
        sb_free(&cmd);
        free(qin); free(qout);
        if (rc != 0) return NULL;
        char *txt = read_file(outpath);
        unlink(outpath);
        return txt;
    }

    if (kind_out) *kind_out = xstrdup("text");
    return read_file(path);
}

static bool is_doc_source(const char *path) {
    const char *ext = strrchr(path, '.');
    if (!ext) return true;
    return strcasecmp(ext, ".pdf") == 0 || strcasecmp(ext, ".txt") == 0 || strcasecmp(ext, ".md") == 0 || strcasecmp(ext, ".text") == 0;
}

/* -------------------- indexing -------------------- */

static void section_vec_push(SectionVec *v, Section s) {
    if (v->len == v->cap) {
        size_t nc = v->cap ? v->cap * 2 : 64;
        Section *p = realloc(v->items, nc * sizeof(*p));
        if (!p) { perror("realloc"); exit(1); }
        v->items = p;
        v->cap = nc;
    }
    v->items[v->len++] = s;
}

static void split_sections(const char *text, SectionVec *out, size_t max_chars) {
    char *copy = xstrdup(text ? text : "");
    char *save = NULL;
    char *line = strtok_r(copy, "\n", &save);
    char *title = xstrdup("(untitled section)");
    StrBuf buf; sb_init(&buf);
    size_t part = 1;
    while (line) {
        char *t = dup_trim(line);
        bool heading = looks_like_heading(t);
        if (heading && buf.len > 0) {
            section_vec_push(out, (Section){ .title = title, .text = buf.buf });
            title = xstrdup(t);
            sb_init(&buf);
            part = 1;
        } else if (heading && buf.len == 0 && strcmp(title, "(untitled section)") == 0) {
            free(title);
            title = xstrdup(t);
        } else {
            sb_append(&buf, line);
            sb_append(&buf, "\n");
            if (buf.len >= max_chars) {
                char titled[512];
                snprintf(titled, sizeof(titled), "%s%s", title, part == 1 ? "" : " (cont.)");
                section_vec_push(out, (Section){ .title = xstrdup(titled), .text = buf.buf });
                sb_init(&buf);
                part++;
            }
        }
        free(t);
        line = strtok_r(NULL, "\n", &save);
    }
    if (buf.len > 0) {
        char titled[512];
        snprintf(titled, sizeof(titled), "%s%s", title, part == 1 ? "" : " (cont.)");
        section_vec_push(out, (Section){ .title = xstrdup(titled), .text = buf.buf });
    } else {
        free(buf.buf);
    }
    free(title);
    free(copy);
    if (out->len == 0) section_vec_push(out, (Section){ .title = xstrdup("(untitled section)"), .text = xstrdup("") });
}

static void doc_free(DocIndex *doc) {
    if (!doc) return;
    free(doc->source_path);
    free(doc->source_kind);
    free(doc->source_hash);
    for (size_t i = 0; i < doc->sections.len; i++) {
        free(doc->sections.items[i].title);
        free(doc->sections.items[i].text);
    }
    free(doc->sections.items);
    memset(doc, 0, sizeof(*doc));
}

static char *cache_path_for(const char *cache_dir, const char *source_path, const char *hash) {
    const char *base = strrchr(source_path, '/');
    base = base ? base + 1 : source_path;
    StrBuf b; sb_init(&b);
    sb_appendf(&b, "%s/%s-%s.qci", cache_dir, base, hash);
    return b.buf;
}

static bool save_index_cache(const char *cache_file, const DocIndex *doc, const char *source_text) {
    if (!ensure_parent_dirs(cache_file)) return false;
    FILE *f = fopen(cache_file, "wb");
    if (!f) return false;
    fprintf(f, "QCAIDX1\n");
    fprintf(f, "SOURCE_PATH_LEN %zu\n", strlen(doc->source_path));
    fwrite(doc->source_path, 1, strlen(doc->source_path), f); fputc('\n', f);
    fprintf(f, "SOURCE_KIND %s\n", doc->source_kind);
    fprintf(f, "SOURCE_HASH %s\n", doc->source_hash);
    fprintf(f, "SECTION_COUNT %zu\n", doc->sections.len);
    fprintf(f, "SOURCE_TEXT_LEN %zu\n", strlen(source_text ? source_text : ""));
    fwrite(source_text ? source_text : "", 1, strlen(source_text ? source_text : ""), f); fputc('\n', f);
    for (size_t i = 0; i < doc->sections.len; i++) {
        Section *s = &doc->sections.items[i];
        fprintf(f, "SECTION\n");
        fprintf(f, "TITLE_LEN %zu\n", strlen(s->title ? s->title : ""));
        fwrite(s->title ? s->title : "", 1, strlen(s->title ? s->title : ""), f); fputc('\n', f);
        fprintf(f, "TEXT_LEN %zu\n", strlen(s->text ? s->text : ""));
        fwrite(s->text ? s->text : "", 1, strlen(s->text ? s->text : ""), f); fputc('\n', f);
    }
    fclose(f);
    return true;
}

static bool read_exact_line(FILE *f, char *buf, size_t cap) {
    if (!fgets(buf, (int)cap, f)) return false;
    size_t n = strlen(buf);
    while (n && (buf[n - 1] == '\n' || buf[n - 1] == '\r')) buf[--n] = '\0';
    return true;
}

static char *read_exact_bytes(FILE *f, size_t n) {
    char *buf = malloc(n + 1);
    if (!buf) return NULL;
    size_t got = fread(buf, 1, n, f);
    if (got != n) { free(buf); return NULL; }
    buf[n] = '\0';
    return buf;
}

static bool load_index_cache(const char *cache_file, DocIndex *doc, char **source_text_out) {
    FILE *f = fopen(cache_file, "rb");
    if (!f) return false;

    char line[256];
    if (!read_exact_line(f, line, sizeof(line)) || strcmp(line, "QCAIDX1") != 0) { fclose(f); return false; }

    size_t path_len = 0, section_count = 0, source_text_len = 0;
    char source_kind[64] = {0};
    char source_hash[128] = {0};

    if (!read_exact_line(f, line, sizeof(line)) || sscanf(line, "SOURCE_PATH_LEN %zu", &path_len) != 1) { fclose(f); return false; }
    char *path = read_exact_bytes(f, path_len);
    if (!path) { fclose(f); return false; }
    fgetc(f);

    if (!read_exact_line(f, line, sizeof(line)) || sscanf(line, "SOURCE_KIND %63s", source_kind) != 1) { free(path); fclose(f); return false; }
    if (!read_exact_line(f, line, sizeof(line)) || sscanf(line, "SOURCE_HASH %127s", source_hash) != 1) { free(path); fclose(f); return false; }
    if (!read_exact_line(f, line, sizeof(line)) || sscanf(line, "SECTION_COUNT %zu", &section_count) != 1) { free(path); fclose(f); return false; }
    if (!read_exact_line(f, line, sizeof(line)) || sscanf(line, "SOURCE_TEXT_LEN %zu", &source_text_len) != 1) { free(path); fclose(f); return false; }

    char *source_text = read_exact_bytes(f, source_text_len);
    if (!source_text) { free(path); fclose(f); return false; }
    fgetc(f);

    DocIndex tmp = {0};
    tmp.source_path = path;
    tmp.source_kind = xstrdup(source_kind);
    tmp.source_hash = xstrdup(source_hash);
    tmp.sections.len = 0;

    for (size_t i = 0; i < section_count; i++) {
        if (!read_exact_line(f, line, sizeof(line)) || strcmp(line, "SECTION") != 0) { doc_free(&tmp); free(source_text); fclose(f); return false; }
        size_t title_len = 0, text_len = 0;
        if (!read_exact_line(f, line, sizeof(line)) || sscanf(line, "TITLE_LEN %zu", &title_len) != 1) { doc_free(&tmp); free(source_text); fclose(f); return false; }
        char *title = read_exact_bytes(f, title_len);
        if (!title) { doc_free(&tmp); free(source_text); fclose(f); return false; }
        fgetc(f);
        if (!read_exact_line(f, line, sizeof(line)) || sscanf(line, "TEXT_LEN %zu", &text_len) != 1) { free(title); doc_free(&tmp); free(source_text); fclose(f); return false; }
        char *text = read_exact_bytes(f, text_len);
        if (!text) { free(title); doc_free(&tmp); free(source_text); fclose(f); return false; }
        fgetc(f);

        section_vec_push(&tmp.sections, (Section){ .title = title, .text = text });
    }

    fclose(f);
    *doc = tmp;
    if (source_text_out) *source_text_out = source_text;
    else free(source_text);
    return true;
}

static bool build_or_load_index(const char *source_path, const char *cache_dir, size_t max_section_chars, DocIndex *out_doc, char **source_text_out, bool force_rebuild) {
    char *kind = NULL;
    char *src_text = extract_text_from_source(source_path, cache_dir, &kind);
    if (!src_text) return false;

    uint64_t hash = fnv1a64_bytes((const unsigned char *)src_text, strlen(src_text));
    char hash_hex[32];
    snprintf(hash_hex, sizeof(hash_hex), "%016llx", (unsigned long long)hash);

    char *cache_file = cache_path_for(cache_dir, source_path, hash_hex);
    if (!force_rebuild && load_index_cache(cache_file, out_doc, source_text_out)) {
        free(cache_file);
        free(kind);
        free(src_text);
        return true;
    }

    DocIndex doc = {0};
    doc.source_path = xstrdup(source_path);
    doc.source_kind = kind ? kind : xstrdup("text");
    doc.source_hash = xstrdup(hash_hex);
    split_sections(src_text, &doc.sections, max_section_chars);
    save_index_cache(cache_file, &doc, src_text);

    free(cache_file);
    free(src_text);

    *out_doc = doc;
    if (source_text_out) *source_text_out = xstrdup(""); // unused, but non-NULL
    return true;
}

static bool load_doc_index(const char *source_path, const char *cache_dir, size_t max_section_chars, DocIndex *out_doc, bool force_rebuild) {
    return build_or_load_index(source_path, cache_dir, max_section_chars, out_doc, NULL, force_rebuild);
}

/* -------------------- retrieval/scoring -------------------- */

static int token_overlap_score(const char *a, const char *b) {
    char *ua = to_upper_dup(a ? a : "");
    char *ub = to_upper_dup(b ? b : "");
    int score = 0;
    char *save = NULL;
    for (char *tok = strtok_r(ua, " \t\r\n,.;:()[]{}<>|/\\\"'`!?", &save); tok; tok = strtok_r(NULL, " \t\r\n,.;:()[]{}<>|/\\\"'`!?", &save)) {
        if (strlen(tok) < 3) continue;
        if (strstr(ub, tok)) score++;
    }
    free(ua); free(ub);
    return score;
}

static void append_top_sections(StrBuf *b, const DocIndex *doc, const char *query, int topk, const char *label) {
    if (!doc || doc->sections.len == 0) return;
    if (topk <= 0 || (size_t)topk > doc->sections.len) topk = (int)doc->sections.len;

    int *scores = calloc(doc->sections.len, sizeof(int));
    size_t *idx = calloc(doc->sections.len, sizeof(size_t));
    if (!scores || !idx) { perror("calloc"); exit(1); }
    for (size_t i = 0; i < doc->sections.len; i++) {
        idx[i] = i;
        scores[i] = token_overlap_score(query, doc->sections.items[i].text);
        scores[i] += token_overlap_score(query, doc->sections.items[i].title) * 2;
    }
    for (size_t i = 0; i < doc->sections.len; i++) {
        for (size_t j = i + 1; j < doc->sections.len; j++) {
            if (scores[j] > scores[i]) {
                int ts = scores[i]; scores[i] = scores[j]; scores[j] = ts;
                size_t ti = idx[i]; idx[i] = idx[j]; idx[j] = ti;
            }
        }
    }

    sb_appendf(b, "\n====================\n%s\nSOURCE: %s\nHASH: %s\n--------------------\n", label, doc->source_path, doc->source_hash);
    for (int i = 0; i < topk; i++) {
        Section *s = &doc->sections.items[idx[i]];
        sb_appendf(b, "\n[SECTION] %s\n", s->title ? s->title : "(untitled section)");
        sb_append(b, s->text ? s->text : "");
        sb_append(b, "\n");
    }
    free(scores); free(idx);
}

/* -------------------- runner / prompt -------------------- */

static const char *profile_name(Profile p) {
    switch (p) {
        case PROF_ULTRA_LOW: return "ultra-low";
        case PROF_LOW: return "low";
        case PROF_MEDIUM: return "medium";
        case PROF_HIGH: return "high";
        case PROF_ULTRA: return "ultra";
    }
    return "low";
}

static void profile_defaults(Profile p, size_t *ctx_size, size_t *max_tokens, size_t *section_chars, size_t *summary_chars) {
    switch (p) {
        case PROF_ULTRA_LOW: *ctx_size = 512;  *max_tokens = 128; *section_chars = 900;  *summary_chars = 220; break;
        case PROF_LOW:       *ctx_size = 1024; *max_tokens = 192; *section_chars = 1400; *summary_chars = 320; break;
        case PROF_MEDIUM:    *ctx_size = 2048; *max_tokens = 256; *section_chars = 2200; *summary_chars = 450; break;
        case PROF_HIGH:      *ctx_size = 4096; *max_tokens = 384; *section_chars = 3200; *summary_chars = 700; break;
        case PROF_ULTRA:     *ctx_size = 8192; *max_tokens = 512; *section_chars = 5000; *summary_chars = 900; break;
    }
}

static char *build_prompt(const DocIndex *bill, const char *rolling, const Section *sec) {
    StrBuf b; sb_init(&b);
    sb_append(&b,
        "You are QCAv13, an offline constitutional review engine.\n"
        "Hierarchy rule:\n"
        "1. The Bill of Rights is the controlling authority.\n"
        "2. The Iowa Code is subordinate text that must be checked against it.\n"
        "3. Identify only plausible constitutional issues or burdens.\n"
        "4. Do not assert a court ruling; explain potential conflicts and uncertainties.\n"
        "5. If the section is ordinary and raises no plausible issue, say so explicitly.\n\n"
        "Return JSON only with keys:\n"
        "section_title, possible_amendments, hierarchy_result, explanation, supporting_arguments, challenging_arguments, section_summary.\n\n");

    if (bill && bill->sections.len) {
        sb_appendf(&b, "CONTROLLING REFERENCE: %s\n", bill->source_path);
        sb_appendf(&b, "REFERENCE HASH: %s\n", bill->source_hash);
        for (size_t i = 0; i < bill->sections.len; i++) {
            Section *s = &bill->sections.items[i];
            sb_appendf(&b, "\n[REFERENCE SECTION] %s\n", s->title ? s->title : "(untitled section)");
            sb_append(&b, s->text ? s->text : "");
            sb_append(&b, "\n");
        }
    }

    sb_append(&b, "\nROLLING SUMMARY:\n");
    sb_append(&b, rolling && *rolling ? rolling : "(none)\n");
    sb_append(&b, "\nCURRENT IOWA CODE SECTION TITLE:\n");
    sb_append(&b, sec->title ? sec->title : "(untitled section)");
    sb_append(&b, "\n\nCURRENT IOWA CODE SECTION TEXT:\n");
    sb_append(&b, sec->text ? sec->text : "");
    sb_append(&b, "\n");
    return b.buf;
}

static char *extract_summary(const char *out, size_t limit) {
    if (!out) return xstrdup("");
    const char *key = "\"section_summary\"";
    const char *p = strstr(out, key);
    if (p) {
        const char *colon = strchr(p, ':');
        if (colon) {
            const char *s = colon + 1;
            while (*s && isspace((unsigned char)*s)) s++;
            if (*s == '"') {
                s++;
                StrBuf b; sb_init(&b);
                for (; *s && b.len < limit; s++) {
                    if (*s == '\\' && s[1]) { s++; sb_append_n(&b, s, 1); }
                    else if (*s == '"') break;
                    else sb_append_n(&b, s, 1);
                }
                return b.buf ? b.buf : xstrdup("");
            }
        }
    }
    StrBuf b; sb_init(&b);
    const char *s = out;
    while (*s && isspace((unsigned char)*s)) s++;
    for (; *s && b.len < limit; s++) sb_append_n(&b, s, 1);
    return b.buf ? b.buf : xstrdup("");
}

static char *runner_cmd_from_template(const char *tmpl, const char *prompt_file, const char *prompt_text, size_t max_tokens, size_t ctx_size) {
    char max_buf[32], ctx_buf[32];
    snprintf(max_buf, sizeof(max_buf), "%zu", max_tokens);
    snprintf(ctx_buf, sizeof(ctx_buf), "%zu", ctx_size);

    char *qf = shell_quote(prompt_file);
    char *qp = shell_quote(prompt_text ? prompt_text : "");

    char *a = replace_all(tmpl, "{PROMPT_FILE}", qf);
    char *b = replace_all(a, "{PROMPT}", qp);
    char *c = replace_all(b, "{MAX_TOKENS}", max_buf);
    char *d = replace_all(c, "{CTX_SIZE}", ctx_buf);
    free(qf); free(qp); free(a); free(b); free(c);

    StrBuf out; sb_init(&out);
    sb_append(&out, d);
    if (!strstr(d, "-n ") && !strstr(d, "--n-predict ")) sb_appendf(&out, " -n %zu", max_tokens);
    if (!strstr(d, "--simple-io")) sb_append(&out, " --simple-io");
    if (!strstr(d, "--no-display-prompt")) sb_append(&out, " --no-display-prompt");
    if (!strstr(d, "--skip-chat-parsing")) sb_append(&out, " --skip-chat-parsing");
    if (!strstr(d, "--single-turn")) sb_append(&out, " --single-turn");
    free(d);
    return out.buf;
}

/* -------------------- output helpers -------------------- */

static void csv_escape(FILE *f, const char *s) {
    fputc('"', f);
    for (; s && *s; s++) {
        if (*s == '"') fputc('"', f);
        fputc(*s, f);
    }
    fputc('"', f);
}

static void usage(void) {
    fprintf(stderr,
        "Usage: %s --input FILE --reference FILE [--reference FILE ...] --outdir DIR [options]\n\n"
        "Options:\n"
        "  --runner-template CMD   llama.cpp template using {PROMPT} or {PROMPT_FILE}\n"
        "  --profile NAME          ultra-low | low | medium | high | ultra\n"
        "  --ctx-size N            Override context size\n"
        "  --max-tokens N          Override generation cap per section\n"
        "  --max-section-chars N   Override chunk size before forced split\n"
        "  --summary-chars N       Override rolling summary limit\n"
        "  --interactive           Pause between sections so users can watch the process\n"
        "  --show-prompts          Print prompts before each llama.cpp call\n"
        "  --resume                Resume from checkpoint files in the output directory\n"
        "  --reset                 Ignore any existing checkpoint and start over\n"
        "  --reindex               Rebuild source indexes even if cached versions exist\n"
        "  --pdf                   Try to write report.pdf with pandoc if available\n"
        "  --list-profiles         Print the built-in memory profiles and exit\n\n"
        "Example:\n"
        "  %s --profile ultra --input iowa.pdf --reference bill.pdf --outdir out \\\n"
        "     --runner-template 'llama-cli -m model.gguf --jinja --reasoning on --reasoning-budget -1 -c {CTX_SIZE} -p {PROMPT}'\n",
        APP, APP);
}

static void list_profiles(void) {
    puts("ultra-low  ctx=512  tokens=128  section=900  summary=220");
    puts("low        ctx=1024 tokens=192  section=1400 summary=320");
    puts("medium     ctx=2048 tokens=256  section=2200 summary=450");
    puts("high       ctx=4096 tokens=384  section=3200 summary=700");
    puts("ultra      ctx=8192 tokens=512  section=5000 summary=900");
}

/* -------------------- main -------------------- */

int main(int argc, char **argv) {
    const char *input = NULL;
    const char *outdir = NULL;
    const char *runner_template = NULL;
    bool want_pdf = false, interactive = false, show_prompts = false;
    bool resume = true, reset = false, reindex = false, list_profiles_flag = false;

    Profile profile = PROF_LOW;
    size_t ctx_size = 0, max_tokens = 0, max_section_chars = 0, summary_chars = 0;

    char **refs = NULL;
    size_t nrefs = 0, refs_cap = 0;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--input") == 0 && i + 1 < argc) input = argv[++i];
        else if (strcmp(argv[i], "--reference") == 0 && i + 1 < argc) {
            if (nrefs == refs_cap) {
                size_t nc = refs_cap ? refs_cap * 2 : 8;
                char **p = realloc(refs, nc * sizeof(*p));
                if (!p) { perror("realloc"); return 1; }
                refs = p; refs_cap = nc;
            }
            refs[nrefs++] = argv[++i];
        } else if (strcmp(argv[i], "--outdir") == 0 && i + 1 < argc) outdir = argv[++i];
        else if (strcmp(argv[i], "--runner-template") == 0 && i + 1 < argc) runner_template = argv[++i];
        else if (strcmp(argv[i], "--profile") == 0 && i + 1 < argc) {
            const char *p = argv[++i];
            if (strcmp(p, "ultra-low") == 0) profile = PROF_ULTRA_LOW;
            else if (strcmp(p, "low") == 0) profile = PROF_LOW;
            else if (strcmp(p, "medium") == 0) profile = PROF_MEDIUM;
            else if (strcmp(p, "high") == 0) profile = PROF_HIGH;
            else if (strcmp(p, "ultra") == 0) profile = PROF_ULTRA;
            else { fprintf(stderr, "%s: unknown profile %s\n", APP, p); return 1; }
        } else if (strcmp(argv[i], "--ctx-size") == 0 && i + 1 < argc) ctx_size = (size_t)strtoul(argv[++i], NULL, 10);
        else if (strcmp(argv[i], "--max-tokens") == 0 && i + 1 < argc) max_tokens = (size_t)strtoul(argv[++i], NULL, 10);
        else if (strcmp(argv[i], "--max-section-chars") == 0 && i + 1 < argc) max_section_chars = (size_t)strtoul(argv[++i], NULL, 10);
        else if (strcmp(argv[i], "--summary-chars") == 0 && i + 1 < argc) summary_chars = (size_t)strtoul(argv[++i], NULL, 10);
        else if (strcmp(argv[i], "--pdf") == 0) want_pdf = true;
        else if (strcmp(argv[i], "--interactive") == 0) interactive = true;
        else if (strcmp(argv[i], "--show-prompts") == 0) show_prompts = true;
        else if (strcmp(argv[i], "--resume") == 0) resume = true;
        else if (strcmp(argv[i], "--reset") == 0) reset = true;
        else if (strcmp(argv[i], "--reindex") == 0) reindex = true;
        else if (strcmp(argv[i], "--list-profiles") == 0) list_profiles_flag = true;
        else { usage(); return 1; }
    }

    if (list_profiles_flag) { list_profiles(); return 0; }
    if (!input || !outdir || nrefs == 0) { usage(); return 1; }

    profile_defaults(profile, &ctx_size, &max_tokens, &max_section_chars, &summary_chars);

    if (ctx_size == 0) ctx_size = 1024;
    if (max_tokens == 0) max_tokens = 192;
    if (max_section_chars == 0) max_section_chars = 1400;
    if (summary_chars == 0) summary_chars = 320;

    if (!ensure_dir(outdir)) { fprintf(stderr, "%s: cannot create outdir %s\n", APP, outdir); return 1; }

    char workdir[PATH_MAX], cache_dir[PATH_MAX], state_dir[PATH_MAX];
    snprintf(workdir, sizeof(workdir), "%s/work", outdir);
    snprintf(cache_dir, sizeof(cache_dir), "%s/.qca_cache", outdir);
    snprintf(state_dir, sizeof(state_dir), "%s/.qca_state", outdir);
    if (!ensure_dir(workdir)) { fprintf(stderr, "%s: cannot create workdir %s\n", APP, workdir); return 1; }
    if (!ensure_dir(cache_dir)) { fprintf(stderr, "%s: cannot create cache dir %s\n", APP, cache_dir); return 1; }
    if (!ensure_dir(state_dir)) { fprintf(stderr, "%s: cannot create state dir %s\n", APP, state_dir); return 1; }

    /* build/load reference indexes */
    DocIndex *reference_docs = calloc(nrefs, sizeof(DocIndex));
    if (!reference_docs) { perror("calloc"); return 1; }
    for (size_t i = 0; i < nrefs; i++) {
        if (!build_or_load_index(refs[i], cache_dir, max_section_chars, &reference_docs[i], NULL, reindex)) {
            fprintf(stderr, "%s: could not index reference %s\n", APP, refs[i]);
            return 1;
        }
    }

    /* build/load input index */
    DocIndex input_doc = {0};
    if (!build_or_load_index(input, cache_dir, max_section_chars, &input_doc, NULL, reindex)) {
        fprintf(stderr, "%s: could not index input %s\n", APP, input);
        return 1;
    }

    char report_md[PATH_MAX], report_csv[PATH_MAX], report_json[PATH_MAX];
    snprintf(report_md, sizeof(report_md), "%s/report.md", outdir);
    snprintf(report_csv, sizeof(report_csv), "%s/index.csv", outdir);
    snprintf(report_json, sizeof(report_json), "%s/index.json", outdir);

    char state_next[PATH_MAX], state_sum[PATH_MAX], state_hash[PATH_MAX], state_meta[PATH_MAX];
    snprintf(state_next, sizeof(state_next), "%s/next_section.txt", state_dir);
    snprintf(state_sum, sizeof(state_sum), "%s/rolling_summary.txt", state_dir);
    snprintf(state_hash, sizeof(state_hash), "%s/input_hash.txt", state_dir);
    snprintf(state_meta, sizeof(state_meta), "%s/meta.txt", state_dir);

    uint64_t input_hash = fnv1a64_str(input_doc.source_hash ? input_doc.source_hash : "");
    char input_hash_buf[64];
    snprintf(input_hash_buf, sizeof(input_hash_buf), "%016llx", (unsigned long long)input_hash);

    size_t start_index = 1;
    if (resume && !reset) {
        char *existing_hash = read_file(state_hash);
        if (existing_hash) {
            trim_inplace(existing_hash);
            if (strcmp(existing_hash, input_hash_buf) == 0) {
                char *n = read_file(state_next);
                if (n) {
                    trim_inplace(n);
                    size_t v = (size_t)strtoull(n, NULL, 10);
                    if (v > 0) start_index = v;
                    free(n);
                }
            }
            free(existing_hash);
        }
    }
    if (!resume || reset) {
        write_file(state_hash, input_hash_buf);
        write_file(state_next, "1");
        write_file(state_sum, "");
        write_file(state_meta, "");
    }

    char *rolling_loaded = read_file(state_sum);
    char rolling[8192];
    rolling[0] = '\0';
    if (rolling_loaded && *rolling_loaded) snprintf(rolling, sizeof(rolling), "%s", rolling_loaded);
    free(rolling_loaded);

    FILE *md = fopen(report_md, (resume && !reset && start_index > 1) ? "ab" : "wb");
    FILE *csv = fopen(report_csv, (resume && !reset && start_index > 1) ? "ab" : "wb");
    FILE *js = fopen(report_json, (resume && !reset && start_index > 1) ? "ab" : "wb");
    if (!md || !csv || !js) { perror("open report"); return 1; }

    if (!(resume && !reset && start_index > 1)) {
        fputs("# QCAv13 Report\n\n", md);
        fprintf(md, "- Input: `%s`\n", input);
        fprintf(md, "- Reference count: %zu\n", nrefs);
        fprintf(md, "- Profile: %s\n", profile_name(profile));
        fprintf(md, "- Input index: `%s`\n\n", input_doc.source_hash ? input_doc.source_hash : "(none)");

        fputs("section_index,section_title,raw_output_file,summary\n", csv);
        fputs("{\n  \"sections\": [\n", js);
    }

    size_t json_count = (resume && !reset && start_index > 1) ? (start_index - 1) : 0;

    for (size_t i = start_index - 1; i < input_doc.sections.len; i++) {
        Section *sec = &input_doc.sections.items[i];
        char prompt_path[PATH_MAX], raw_path[PATH_MAX], section_json[PATH_MAX];
        snprintf(prompt_path, sizeof(prompt_path), "%s/section_%04zu.prompt.txt", workdir, i + 1);
        snprintf(raw_path, sizeof(raw_path), "%s/section_%04zu.raw.txt", workdir, i + 1);
        snprintf(section_json, sizeof(section_json), "%s/section_%04zu.json", outdir, i + 1);

        char *prompt = NULL;
        {
            StrBuf p; sb_init(&p);
            sb_append(&p,
                "You are QCAv13, an offline constitutional review engine.\n"
                "Hierarchy rule:\n"
                "1. The Bill of Rights is the controlling authority.\n"
                "2. The Iowa Code is subordinate and must be tested against the Bill of Rights.\n"
                "3. Identify only plausible constitutional issues or burdens.\n"
                "4. Do not claim a court ruling; explain potential conflicts and uncertainties.\n"
                "5. If the section is ordinary and raises no plausible issue, say so explicitly.\n\n"
                "Return JSON only with keys:\n"
                "section_title, possible_amendments, hierarchy_result, explanation, supporting_arguments, challenging_arguments, section_summary.\n\n");
            append_top_sections(&p, &reference_docs[0], sec->text ? sec->text : "", 10, "CONTROLLING REFERENCE: BILL OF RIGHTS");
            for (size_t r = 1; r < nrefs; r++) {
                char label[512];
                snprintf(label, sizeof(label), "REFERENCE %zu", r + 1);
                append_top_sections(&p, &reference_docs[r], sec->text ? sec->text : "", 4, label);
            }
            sb_append(&p, "\nROLLING SUMMARY:\n");
            sb_append(&p, *rolling ? rolling : "(none)\n");
            sb_append(&p, "\nCURRENT IOWA CODE SECTION TITLE:\n");
            sb_append(&p, sec->title ? sec->title : "(untitled section)");
            sb_append(&p, "\n\nCURRENT IOWA CODE SECTION TEXT:\n");
            sb_append(&p, sec->text ? sec->text : "");
            sb_append(&p, "\n");
            prompt = p.buf;
        }

        write_file(prompt_path, prompt);

        if (!runner_template || !*runner_template) {
            fprintf(stderr, "%s: missing --runner-template\n", APP);
            return 1;
        }

        char *cmd = runner_cmd_from_template(runner_template, prompt_path, prompt, max_tokens, ctx_size);
        if (show_prompts) {
            printf("\n===== PROMPT %zu / %zu =====\n%s\n===========================\n", i + 1, input_doc.sections.len, prompt);
        }
        printf("[%zu/%zu] %s\n", i + 1, input_doc.sections.len, sec->title ? sec->title : "(untitled section)");
        fflush(stdout);

        char *raw = run_capture(cmd);
        if (!raw) { fprintf(stderr, "%s: runner failed\n", APP); return 1; }

        write_file(raw_path, raw);
        write_file(section_json, raw);

        char *summary = extract_summary(raw, summary_chars);
        snprintf(rolling, sizeof(rolling), "%s", summary);
        free(summary);

        char secnum[32];
        snprintf(secnum, sizeof(secnum), "%zu", i + 2);
        write_file(state_next, secnum);
        write_file(state_sum, rolling);
        write_file(state_hash, input_hash_buf);
        write_file(state_meta, input_doc.source_hash ? input_doc.source_hash : "");

        fprintf(md, "## %s\n\n", sec->title ? sec->title : "(untitled section)");
        fputs("### Raw output\n\n```text\n", md);
        fputs(raw, md);
        fputs("\n```\n\n", md);

        fprintf(csv, "%zu,", i + 1);
        csv_escape(csv, sec->title ? sec->title : "(untitled section)");
        fputc(',', csv);
        csv_escape(csv, raw_path);
        fputc(',', csv);
        csv_escape(csv, rolling);
        fputc('\n', csv);

        if (json_count++) fputs(",\n", js);
        fputs("    {\n", js);
        fprintf(js, "      \"index\": %zu,\n", i + 1);
        fputs("      \"section_title\": ", js); csv_escape(js, sec->title ? sec->title : "(untitled section)"); fputs(",\n", js);
        fputs("      \"raw_output_file\": ", js); csv_escape(js, raw_path); fputs(",\n", js);
        fputs("      \"summary\": ", js); csv_escape(js, rolling); fputc('\n', js);
        fputs("    }", js);

        free(prompt);
        free(cmd);
        free(raw);

        if (interactive) {
            printf("\n--- press ENTER for next section, or q then ENTER to stop ---\n");
            char line[16];
            if (!fgets(line, sizeof(line), stdin)) break;
            if (line[0] == 'q' || line[0] == 'Q') break;
        }
    }

    fputs("\n  ]\n}\n", js);
    fclose(md); fclose(csv); fclose(js);

    if (want_pdf) {
        char pdf_cmd[PATH_MAX * 2];
        snprintf(pdf_cmd, sizeof(pdf_cmd), "pandoc %s -o %s/report.pdf >/dev/null 2>&1", report_md, outdir);
        system(pdf_cmd);
    }

    printf("Done. Reports written to %s\n", outdir);
    printf("Resume state in %s/.qca_state/\n", outdir);
    printf("Index cache in %s/.qca_cache/\n", outdir);

    for (size_t i = 0; i < reference_docs[0].sections.len; i++) {
        free(reference_docs[0].sections.items[i].title);
        free(reference_docs[0].sections.items[i].text);
    }
    for (size_t r = 0; r < nrefs; r++) {
        doc_free(&reference_docs[r]);
    }
    free(reference_docs);
    doc_free(&input_doc);

    free(refs);
    return 0;
}
