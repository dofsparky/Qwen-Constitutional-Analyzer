# QCAv18-3 patched run

Example:

```bash
./QCAv18-3   --input /home/delta/C/iowa_code_2026.txt   --reference /home/delta/references/bill_of_rights.txt   --outdir /home/delta/iowa/qcav18-3   --runner-template 'sh ./qca_runner_mock.sh -f {PROMPT_FILE}'
```

If your local model returns plain prose instead of JSON, the patched build will still keep the answer in `report.md`.
