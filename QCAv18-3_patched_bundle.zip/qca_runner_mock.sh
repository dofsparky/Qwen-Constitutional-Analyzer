#!/bin/sh
PROMPT_FILE=""
while [ "$#" -gt 0 ]; do
  case "$1" in
    -f|--file|--prompt-file)
      shift
      PROMPT_FILE="$1"
      ;;
    -f*)
      PROMPT_FILE="${1#-f}"
      ;;
  esac
  shift
done

MODE="${QCA_MOCK_MODE:-json}"

printf '%s
' "load_backend: loaded CPU backend"
printf '%s
' "Loading model..."
printf '%s
' "<think>internal</think>"
printf '%s
' "[ Prompt: 19.2 t/s | Generation: 4.7 t/s ]"

case "$MODE" in
  text)
    printf '%s
' "This section requires a license and may burden speech, petitioning, and due process."
    ;;
  json|*)
    printf '%s
' '{"pass":1,"section_title":"CHAPTER 595 / 595.2","answer":"The statute regulates marriage and requires a license before marriage. It may burden speech-related petitioning or due process depending on application.","possible_amendments":["First Amendment","Fifth Amendment","Fourteenth Amendment"],"evidence":["license required","penalty"],"confidence":0.91}'
    ;;
esac
printf '%s
' '<<<QCA_RESPONSE_END>>>'
