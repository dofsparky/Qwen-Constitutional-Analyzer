# QCAv15 lamerized

QCAv15 keeps the cached document-pack workflow and the budgeted retrieval design.

## Architecture

QCAv15 is a local retrieval-first workflow:

1. `--prepare` or `--index-only` extracts and caches the documents.
2. QCA builds compact chunk context and cross-reference summaries.
3. Prompts are trimmed to a configurable budget before Qwen is called.
4. Analysis mode runs automatically when `--questions` is omitted.
5. Question mode runs when `--questions` is present.

## What changed

- prompt-budget trimming is preserved
- cached packs are preserved
- cross-reference context is compact, not full-dump
- analysis mode and question mode are both supported
- `--prepare` and `--index-only` do not require `--runner-template`

## Example

```bash
./QCAv15   --profile ultra   --prompt-budget 6000   --workers auto   --input "/home/delta/iowa/2022-iowa-code.pdf"   --reference "/home/delta/references/bill-of-rights.pdf"   --outdir "iowa-2022"   --runner-template 'llama-cli -m /home/delta/models/Qwen3-4B-Q4_K_M.gguf --jinja --reasoning on --reasoning-budget -1 -c {CTX_SIZE} -n 2048 --temp 0.6 --top-k 40 --top-p 0.95 --min-p 0.05 --repeat-penalty 1.05 -f {PROMPT_FILE}'
```

## Notes

- `--prompt-budget` defaults to about 75% of the chosen context size if omitted.
- If the prompt is still too large, QCA reduces the retrieved context before truncating.
- The same cached packs are reused across later runs.
