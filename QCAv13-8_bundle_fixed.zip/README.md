# QCAv13-8 lamerized

QCAv13-8 adds a dedicated pack-preparation mode and progress bars for QCA-side operations.

## What changed

- The input and reference files are indexed once into reusable packs
- You can run `--prepare` first to build pack caches without invoking Qwen
- Later analysis runs reuse the cached packs instead of re-reading the whole source
- Progress bars are shown for indexing, question loading, caching, and report writing
- Qwen calls stay separate and do not use fake progress bars

## Build

```bash
make
```

## Help

```bash
./QCAv13-8 --help
```

## Prepare mode

This mode extracts the documents, builds the packs, and writes manifests into the output directory.

```bash
./QCAv13-8   --prepare   --profile ultra   --input "/home/delta/iowa/2022-iowa-code.pdf"   --reference "/home/delta/references/bill-of-rights.pdf"   --outdir "iowa-2022"   --runner-template 'llama-cli -m /home/delta/models/Qwen3-4B-Q4_K_M.gguf --jinja --reasoning on --reasoning-budget -1 -c {CTX_SIZE} -p {PROMPT}'
```

After that, you can run the normal analysis command and QCA will reuse the cached packs.

## Analysis mode

If `--questions` is omitted, QCA automatically analyzes the input chunks against the Bill of Rights.

## Question mode

If `--questions questions.txt` is provided, QCA answers the questions using the same cached packs.

## Workers

`--workers auto` is the safest default. It picks a conservative worker count from CPU and RAM.

## Notes

- `--profile ultra` maps to `-c 8192`
- Cached packs live under `.qca_cache/`
- Resume state lives under `.qca_state/`
