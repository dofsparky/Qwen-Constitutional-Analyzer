# QCAv16-1 lamerized

QCAv16-1 keeps the retrieval-first design and adds automatic continuation when a response is cut off.

## What changed

- `--prepare` / `--index-only` still build and cache the documents
- prompts are budgeted before Qwen runs
- the engine keeps room for the answer
- if a response ends early, QCA automatically issues continuation passes
- analysis mode still works when `--questions` is omitted
- question mode still works when `--questions` is provided

## Why this helps

A long legal analysis can exceed the model's generation cap even when the prompt itself fits.

QCAv16-1 handles that by:
1. building and caching the source packs
2. assembling a prompt from the best matches
3. keeping extra room for output
4. continuing the response automatically if the model stops early

## Example

```bash
./QCAv16-1   --profile ultra   --prompt-budget 5000   --workers auto   --input "/home/delta/iowa/2022-iowa-code.pdf"   --reference "/home/delta/references/bill-of-rights.pdf"   --outdir "iowa-2022"   --runner-template 'llama-cli -m /home/delta/models/Qwen3-4B-Q4_K_M.gguf --jinja --reasoning on --reasoning-budget -1 -c {CTX_SIZE} -n 2048 --temp 0.6 --top-k 40 --top-p 0.95 --min-p 0.05 --repeat-penalty 1.05 -f {PROMPT_FILE}'
```

## Notes

- `--prepare` and `--index-only` do not require `--runner-template`
- if a cache already exists, later runs can reuse it
- analysis mode automatically activates when `--questions` is omitted
- `--prompt-budget` defaults to about 55% of the remaining context after reserving room for output
- if the generation still stops early, QCA continues it automatically
