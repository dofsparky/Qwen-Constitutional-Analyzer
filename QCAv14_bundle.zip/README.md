# QCAv14 lamerized

QCAv14 improves cross-document retrieval so Qwen can see a fuller atlas of both documents before answering.

## What changed

- Cached packs still build in `--prepare` / `--index-only`
- Atlas now includes:
  - chunk ids
  - chunk titles
  - chunk sizes
  - extracted keywords
  - nearby chunk context around the strongest matches
- Prompts now provide richer cross-reference guidance
- Analysis mode still works when `--questions` is omitted
- Question mode still works when `--questions` is provided

## Help

Run:

```bash
./QCAv14 --help
```

## Why this is faster

QCAv14 does not ask Qwen to search the whole document from scratch.

Instead it:
1. extracts and caches the source text
2. builds a chunk atlas
3. adds nearby chunk context around the best matches
4. sends the most relevant material to Qwen

That gives Qwen more useful information with less wasted prompt space.

## Example

```bash
./QCAv14   --profile ultra   --workers auto   --input "/home/delta/iowa/2022-iowa-code.pdf"   --reference "/home/delta/references/bill-of-rights.pdf"   --outdir "iowa-2022"   --runner-template 'llama-cli -m /home/delta/models/Qwen3-4B-Q4_K_M.gguf --jinja --reasoning on --reasoning-budget -1 -c {CTX_SIZE} -n 2048 --temp 0.6 --top-k 40 --top-p 0.95 --min-p 0.05 --repeat-penalty 1.05 -f {PROMPT_FILE}'
```

## Notes

- `--prepare` and `--index-only` do not require `--runner-template`
- If a cache already exists, later runs can reuse it
- Analysis mode automatically activates when `--questions` is omitted
