# QCAv16-6 lamerized

QCAv16-6 adds a maximum-throughput preset and shows ETA during analysis.

## What changed

- `--prepare` / `--index-only` still build and cache the documents
- non-statutory material is skipped during chunking
- analysis shows an ETA while processing valid sections
- `--speed max` and `--throughput max` apply the most aggressive throughput settings
- top matches stay compact
- prompt budgeting remains conservative by default
- analysis mode still works when `--questions` is omitted
- question mode still works when `--questions` is provided

## Throughput presets

- `--speed normal` keeps standard behavior
- `--speed fast` reduces context and generation for faster turnaround
- `--speed turbo` is very aggressive
- `--speed max` is the most aggressive speed preset

`--throughput normal|fast|max` is an alias focused on throughput-first runs.

## Example

```bash
./QCAv16-6   --profile ultra   --throughput max   --prompt-budget 3000   --workers auto   --input "/home/delta/C/iowa_code_2026.txt"   --reference "/home/delta/references/bill_of_rights.txt"   --outdir "/home/delta/iowa/iowa-qcav16-6"   --runner-template 'llama-cli -m /home/delta/models/Qwen3-4B-Q4_K_M.gguf --jinja --reasoning on --reasoning-budget -1 -c {CTX_SIZE} -n 768 --temp 0.5 --top-k 20 --top-p 0.90 --min-p 0.10 --repeat-penalty 1.05 -f {PROMPT_FILE}'
```

## Notes

- `--prepare` and `--index-only` do not require `--runner-template`
- if a cache already exists, later runs can reuse it
- analysis mode automatically activates when `--questions` is omitted
- `--prompt-budget` defaults to about 25% of the remaining context if omitted
- ETA is based on the number of valid chunks still to analyze
