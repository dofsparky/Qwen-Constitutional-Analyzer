#!/bin/sh
PROMPT_FILE=""
while [ "$#" -gt 0 ]; do
  case "$1" in
    -f|--file|--prompt-file)
      shift
      PROMPT_FILE="$1"
      ;;
    -f*)
      PROMPT_FILE="${1#-f}"
      ;;
  esac
  shift
done

# Read the prompt file so users can verify the path is valid.
if [ -n "$PROMPT_FILE" ] && [ -f "$PROMPT_FILE" ]; then
  :
fi

printf '%s\n' "load_backend: loaded CPU backend"
printf '%s\n' "Loading model..."
printf '%s\n' "<think>internal</think>"
printf '%s\n' "[ Prompt: 19.2 t/s | Generation: 4.7 t/s ]"
printf '%s\n' '{"pass":1,"section_title":"CHAPTER 595 / 595.2","answer":"The statute regulates marriage and requires a license before marriage. It may burden speech-related petitioning or due process depending on application.","possible_amendments":["First Amendment","Fifth Amendment","Fourteenth Amendment"],"evidence":["license required","penalty"],"confidence":0.91}'
printf '%s\n' '<<<QCA_RESPONSE_END>>>'
