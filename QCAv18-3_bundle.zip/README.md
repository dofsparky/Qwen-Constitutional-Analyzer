# QCAv18-3

Patched release with:
- double-free fix
- front-matter-aware Iowa Code chunking
- 7-pass constitutional review
- output sanitization
- ETA / progress reporting
- resumable analysis hooks
- prompt pipelining

## Run

```bash
./QCAv18-3   --input "/home/delta/C/iowa_code_2026.txt"   --reference "/home/delta/references/bill_of_rights.txt"   --outdir "/home/delta/iowa/qcav18-3"   --runner-template './qca_runner_mock.sh -f {PROMPT_FILE}'
```

For a real model, replace `qca_runner_mock.sh` with your local llama.cpp wrapper.
