# QCAv16-2 lamerized

QCAv16-2 keeps the retrieval-first workflow, but the prompt now uses compact excerpts instead of full section dumps.

## What changed

- `--prepare` / `--index-only` still build and cache the documents
- top matches are now compact excerpts
- the prompt budget is more conservative by default
- malformed chunks are skipped before analysis
- analysis mode still works when `--questions` is omitted
- question mode still works when `--questions` is provided

## Why this is better

Earlier builds could overfeed Qwen with too much context. QCAv16-2 fixes that by:
1. caching the source documents,
2. selecting only the best matches,
3. limiting top-match excerpts,
4. trimming the prompt to fit the budget,
5. skipping malformed chunks before they reach the model.

## Example

```bash
./QCAv16-2   --profile ultra   --prompt-budget 5000   --workers auto   --input "/home/delta/iowa/2022-iowa-code.pdf"   --reference "/home/delta/references/bill-of-rights.pdf"   --outdir "iowa-2022"   --runner-template 'llama-cli -m /home/delta/models/Qwen3-4B-Q4_K_M.gguf --jinja --reasoning on --reasoning-budget -1 -c {CTX_SIZE} -n 2048 --temp 0.6 --top-k 40 --top-p 0.95 --min-p 0.05 --repeat-penalty 1.05 -f {PROMPT_FILE}'
```

## Notes

- `--prepare` and `--index-only` do not require `--runner-template`
- if a cache already exists, later runs can reuse it
- analysis mode automatically activates when `--questions` is omitted
- `--prompt-budget` defaults to about 40% of the remaining context if omitted
