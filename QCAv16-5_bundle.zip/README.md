# QCAv16-5
## Offline Constitutional Analysis Engine

QCAv16-5 is a retrieval-first, fully offline constitutional analysis engine for comparing legal texts against constitutional reference material with llama.cpp and Qwen.

This release is tuned for Iowa Code-style documents: it skips preface pages, tables of contents, indexes, editorial notes, and other front matter before prompting the model. It also keeps chapter context with statutory sections when available, which reduces noise and improves retrieval quality on large legal codes.

## Highlights

- Fully offline
- Written in ANSI C
- Works with llama.cpp
- Optimized for Qwen GGUF models
- Statute-aware chunking for Iowa Code-style texts
- Front matter and TOC filtering
- Compact prompt assembly
- Prompt budgeting
- Resume support
- Multi-threaded preparation
- Markdown / JSON / CSV reports

## Example

```bash
./QCAv16-5   --profile ultra   --speed fast   --prompt-budget 4000   --workers auto   --input "/home/delta/C/iowa_code_2026.txt"   --reference "/home/delta/references/bill_of_rights.txt"   --outdir "/home/delta/iowa/iowa-qcav16-5"   --runner-template 'llama-cli -m /home/delta/models/Qwen3-4B-Q4_K_M.gguf --jinja --reasoning on --reasoning-budget -1 -c {CTX_SIZE} -n 1024 --temp 0.6 --top-k 40 --top-p 0.95 --min-p 0.05 --repeat-penalty 1.05 -f {PROMPT_FILE}'
```

## Notes

- `--prepare` and `--index-only` build caches without running the model.
- `--speed fast` and `--speed turbo` reduce prompt size and generation length for faster runs.
- Analysis mode automatically activates when `--questions` is omitted.
- Question mode is supported when `--questions` is present.
- The prompt budget defaults conservatively so the model has room to finish its answer.

## Why this version helps

Large codebooks often begin with prefatory material, volume headers, and tables of contents before the actual operative sections. QCAv16-5 filters that structure earlier so Qwen can spend more of its context on statutory text and constitutional analysis instead of publication metadata.

## License

See the repository LICENSE file.
