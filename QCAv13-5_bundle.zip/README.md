# QCAv13-5 lamerized

QCAv13-5 is a task-first offline constitutional review engine.

## What it does

- Loads PDF or text input with `--input`
- Loads PDF or text references with `--reference`
- Caches indexed documents under `--outdir/.qca_cache/`
- Resumes from `--outdir/.qca_state/`
- Appends to `report.md`, `index.csv`, and `index.json` as each section completes
- Auto-selects a safe worker count from CPU and RAM unless you override it
- Supports `--profile ultra` for `-c 8192`

## Why this build exists

This version makes the model see the task more clearly:
- the Bill of Rights is the controlling authority,
- the Iowa Code is subordinate text,
- and the model must look for both obvious and subtle constitutional burdens.

## Profiles

- `ultra-low` 512 ctx / 128 tokens
- `low` 1024 ctx / 192 tokens
- `medium` 2048 ctx / 256 tokens
- `high` 4096 ctx / 384 tokens
- `ultra` 8192 ctx / 512 tokens

List them:

```bash
./QCAv13-5 --list-profiles
```

## How `--workers` works

`--workers` controls how many section-analysis jobs QCAv13-5 runs at the same time.

Examples:

```bash
--workers 1
--workers 2
--workers auto
```

### `--workers auto`
This is the safest default. QCAv13-5 checks:
- how many CPU cores are available,
- how much RAM is installed,
- and the current profile's context/token budget.

Then it chooses a conservative worker count automatically.

### When to use more workers
Use more workers when:
- your machine has multiple cores,
- you are running smaller models,
- and you want faster throughput on large documents.

### When to use fewer workers
Use fewer workers when:
- RAM is limited,
- the model context is large,
- or the system becomes slow / swaps heavily.

### Practical guidance
- `--profile ultra-low` or `--profile low`: `--workers auto` is usually safe.
- `--profile medium`: start with `--workers auto`.
- `--profile high` or `--profile ultra`: use `--workers auto` first, then raise workers only if memory stays stable.

### Manual override
If you already know your machine can handle it:

```bash
--workers 4
```

If you want QCAv13-5 to decide for you:

```bash
--workers auto
```

## Prompt placeholders

`{CTX_SIZE}` is replaced with the selected context window before `llama-cli` starts.
`{PROMPT}` is the generated prompt text.
`{PROMPT_FILE}` is the path to the temporary prompt file.

## Example

```bash
./QCAv13-5   --profile ultra   --workers auto   --input "/home/delta/iowa/2022-iowa-code.pdf"   --reference "/home/delta/references/bill-of-rights.pdf"   --outdir "iowa-2022"   --runner-template 'llama-cli -m /home/delta/models/Qwen3-4B-Q4_K_M.gguf --jinja --reasoning on --reasoning-budget -1 -c {CTX_SIZE} -p {PROMPT}'
```

## Resume

Stop the job and rerun the same command. The checkpoint files live in:

```text
iowa-2022/.qca_state/
```

Use `--reset` to start over and `--reindex` to rebuild the cached indexes.

## Output

- `report.md`
- `index.csv`
- `index.json`
- `.qca_cache/`
- `.qca_state/`
- `work/section_XXXX.prompt.txt`
- `work/section_XXXX.raw.txt`
- `work/section_XXXX.json`

## Notes

The worker count is auto-tuned from CPU count and RAM. On low-memory machines it falls back to one worker automatically.
