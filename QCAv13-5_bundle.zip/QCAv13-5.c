
#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <pthread.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <sys/stat.h>
#include <sys/sysinfo.h>
#include <unistd.h>

#define APP "QCAv13-3"

typedef struct { char *title; char *text; } Section;
typedef struct { Section *items; size_t len, cap; } SectionVec;
typedef struct { char *buf; size_t len, cap; } StrBuf;
typedef enum { PROF_ULTRA_LOW, PROF_LOW, PROF_MEDIUM, PROF_HIGH, PROF_ULTRA } Profile;

typedef struct {
    char *path;
    char *kind;
    char *hash;
    SectionVec sections;
} DocIndex;

typedef struct {
    const DocIndex *input_doc;
    const DocIndex *refs;
    size_t nrefs;
    char *rolling_summary;
    size_t summary_limit;
    size_t max_tokens;
    size_t ctx_size;
    int topk_refs;
    const char *runner_template;
    const char *workdir;
    const char *outdir;
    FILE *report_md;
    FILE *report_csv;
    FILE *report_json;
    size_t *report_count;
    pthread_mutex_t *report_lock;
    bool show_prompts;
} JobConfig;

typedef struct {
    const JobConfig *cfg;
    size_t next_idx;
    size_t end_idx;
    size_t *cursor;
    pthread_mutex_t *cursor_lock;
    pthread_mutex_t *io_lock;
    size_t *done;
    int worker_id;
    int failed;
} WorkerArgs;

/* ---------- string helpers ---------- */

static void sb_init(StrBuf *b) { b->buf = NULL; b->len = b->cap = 0; }
static void sb_reserve(StrBuf *b, size_t add) {
    size_t need = b->len + add + 1;
    if (need <= b->cap) return;
    size_t nc = b->cap ? b->cap : 1024;
    while (nc < need) nc *= 2;
    char *p = realloc(b->buf, nc);
    if (!p) { perror("realloc"); exit(1); }
    b->buf = p;
    b->cap = nc;
}
static void sb_append_n(StrBuf *b, const char *s, size_t n) {
    if (!s || !n) return;
    sb_reserve(b, n);
    memcpy(b->buf + b->len, s, n);
    b->len += n;
    b->buf[b->len] = '\0';
}
static void sb_append(StrBuf *b, const char *s) { if (s) sb_append_n(b, s, strlen(s)); }
static void sb_appendf(StrBuf *b, const char *fmt, ...) {
    va_list ap, ap2;
    va_start(ap, fmt);
    va_copy(ap2, ap);
    int n = vsnprintf(NULL, 0, fmt, ap);
    va_end(ap);
    if (n < 0) { va_end(ap2); return; }
    sb_reserve(b, (size_t)n);
    vsnprintf(b->buf + b->len, b->cap - b->len, fmt, ap2);
    va_end(ap2);
    b->len += (size_t)n;
}
static char *xstrdup(const char *s) { if (!s) s=""; size_t n=strlen(s); char *p=malloc(n+1); if(!p){perror("malloc"); exit(1);} memcpy(p,s,n+1); return p; }
static char *trim_inplace(char *s) {
    if (!s) return s;
    char *st = s;
    while (*st && isspace((unsigned char)*st)) st++;
    char *en = st + strlen(st);
    while (en > st && isspace((unsigned char)en[-1])) en--;
    size_t n = (size_t)(en - st);
    if (st != s) memmove(s, st, n);
    s[n] = '\0';
    return s;
}
static char *dup_trim(const char *s) { return trim_inplace(xstrdup(s)); }
static char *toupper_dup(const char *s) {
    size_t n = strlen(s ? s : "");
    char *p = malloc(n+1); if (!p){perror("malloc"); exit(1);}
    for (size_t i=0;i<n;i++) p[i]= (char)toupper((unsigned char)s[i]);
    p[n]='\0'; return p;
}
static bool contains_ci(const char *hay, const char *needle) {
    char *a=toupper_dup(hay), *b=toupper_dup(needle);
    bool ok = strstr(a,b)!=NULL;
    free(a); free(b); return ok;
}
static bool mostly_upper(const char *s) {
    int alpha=0, upper=0;
    for (; *s; s++) if (isalpha((unsigned char)*s)) { alpha++; if (isupper((unsigned char)*s)) upper++; }
    return alpha > 0 && upper*2 >= alpha;
}
static char *shell_quote(const char *s) {
    StrBuf b; sb_init(&b);
    sb_append(&b, "'");
    for (const char *p=s; p && *p; p++) {
        if (*p=='\'') sb_append(&b, "'\\''");
        else sb_append_n(&b, p, 1);
    }
    sb_append(&b, "'");
    return b.buf;
}
static unsigned long long fnv1a64(const char *s) {
    unsigned long long h=1469598103934665603ULL;
    for (; s && *s; s++) { h ^= (unsigned char)*s; h *= 1099511628211ULL; }
    return h;
}

/* ---------- filesystem ---------- */

static bool ensure_parent_dirs(const char *path) {
    char tmp[PATH_MAX];
    snprintf(tmp, sizeof(tmp), "%s", path);
    for (char *p = tmp + 1; *p; p++) {
        if (*p == '/') {
            *p = '\0';
            if (mkdir(tmp, 0755) != 0 && errno != EEXIST) return false;
            *p = '/';
        }
    }
    return true;
}
static bool ensure_dir(const char *path) {
    struct stat st;
    if (stat(path, &st) == 0) return S_ISDIR(st.st_mode);
    return mkdir(path, 0755) == 0;
}
static int write_file(const char *path, const char *data) {
    if (!ensure_parent_dirs(path)) return -1;
    FILE *f = fopen(path, "wb");
    if (!f) return -1;
    size_t n = data ? strlen(data) : 0;
    if (n && fwrite(data, 1, n, f) != n) { fclose(f); return -1; }
    fclose(f);
    return 0;
}
static char *read_file(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    rewind(f);
    if (sz < 0) { fclose(f); return NULL; }
    char *buf = malloc((size_t)sz + 1);
    if (!buf) { fclose(f); return NULL; }
    size_t got = fread(buf, 1, (size_t)sz, f);
    fclose(f);
    buf[got] = '\0';
    return buf;
}

static char *replace_all(const char *src, const char *needle, const char *repl) {
    if (!src) return xstrdup("");
    if (!needle || !*needle) return xstrdup(src);
    size_t src_len = strlen(src), nlen = strlen(needle), rlen = strlen(repl);
    size_t count = 0;
    const char *p = src;
    while ((p = strstr(p, needle))) { count++; p += nlen; }
    char *out = malloc(src_len + count * (rlen - nlen) + 1);
    if (!out) { perror("malloc"); exit(1); }
    char *d = out;
    p = src;
    const char *h;
    while ((h = strstr(p, needle))) {
        size_t n = (size_t)(h - p);
        memcpy(d, p, n); d += n;
        memcpy(d, repl, rlen); d += rlen;
        p = h + nlen;
    }
    strcpy(d, p);
    return out;
}

/* ---------- parsing / indexing ---------- */

static bool looks_like_heading(const char *line) {
    char *t = dup_trim(line);
    if (!t || !*t) { free(t); return false; }
    size_t n = strlen(t);
    if (n > 140) { free(t); return false; }
    bool key = contains_ci(t, "CHAPTER") || contains_ci(t, "ARTICLE") || contains_ci(t, "SECTION") || contains_ci(t, "CODE OF IOWA") || contains_ci(t, "VOLUME ") || contains_ci(t, "TITLE ");
    bool num = isdigit((unsigned char)t[0]) || strncmp(t, "§", 2) == 0 || strncmp(t, "Sec.", 4) == 0 || strncmp(t, "SEC.", 4) == 0;
    bool up = mostly_upper(t) && n < 90 && !strchr(t, '.');
    free(t);
    return key || num || up;
}

static void vec_push(SectionVec *v, Section s) {
    if (v->len == v->cap) {
        size_t nc = v->cap ? v->cap * 2 : 64;
        Section *p = realloc(v->items, nc * sizeof(*p));
        if (!p) { perror("realloc"); exit(1); }
        v->items = p; v->cap = nc;
    }
    v->items[v->len++] = s;
}

static void split_sections(const char *text, SectionVec *out, size_t max_chars) {
    char *copy = xstrdup(text ? text : "");
    char *save = NULL;
    char *line = strtok_r(copy, "\n", &save);
    char *title = xstrdup("(untitled section)");
    StrBuf buf; sb_init(&buf);
    size_t part = 1;
    while (line) {
        char *t = dup_trim(line);
        bool heading = looks_like_heading(t);
        if (heading && buf.len > 0) {
            vec_push(out, (Section){ .title = title, .text = buf.buf });
            title = xstrdup(t);
            sb_init(&buf);
            part = 1;
        } else if (heading && buf.len == 0 && strcmp(title, "(untitled section)") == 0) {
            free(title);
            title = xstrdup(t);
        } else {
            sb_append(&buf, line);
            sb_append(&buf, "\n");
            if (buf.len >= max_chars) {
                char tmp[512];
                snprintf(tmp, sizeof(tmp), "%s%s", title, part == 1 ? "" : " (cont.)");
                vec_push(out, (Section){ .title = xstrdup(tmp), .text = buf.buf });
                sb_init(&buf);
                part++;
            }
        }
        free(t);
        line = strtok_r(NULL, "\n", &save);
    }
    if (buf.len > 0) {
        char tmp[512];
        snprintf(tmp, sizeof(tmp), "%s%s", title, part == 1 ? "" : " (cont.)");
        vec_push(out, (Section){ .title = xstrdup(tmp), .text = buf.buf });
    } else {
        free(buf.buf);
    }
    free(title);
    free(copy);
    if (out->len == 0) vec_push(out, (Section){ .title = xstrdup("(untitled section)"), .text = xstrdup("") });
}

static void doc_free(DocIndex *d) {
    if (!d) return;
    free(d->path); free(d->kind); free(d->hash);
    for (size_t i = 0; i < d->sections.len; i++) {
        free(d->sections.items[i].title);
        free(d->sections.items[i].text);
    }
    free(d->sections.items);
    memset(d, 0, sizeof(*d));
}

static char *extract_text(const char *path, const char *tmpdir, char **kind_out) {
    const char *ext = strrchr(path, '.');
    if (ext && (strcasecmp(ext, ".txt") == 0 || strcasecmp(ext, ".md") == 0 || strcasecmp(ext, ".text") == 0)) {
        if (kind_out) *kind_out = xstrdup("text");
        return read_file(path);
    }
    if (ext && strcasecmp(ext, ".pdf") == 0) {
        if (kind_out) *kind_out = xstrdup("pdf");
        char outpath[PATH_MAX];
        snprintf(outpath, sizeof(outpath), "%s/extract_%ld.txt", tmpdir, (long)getpid());
        char *qin = shell_quote(path);
        char *qout = shell_quote(outpath);
        StrBuf cmd; sb_init(&cmd);
        sb_appendf(&cmd, "pdftotext -layout -nopgbrk %s %s >/dev/null 2>&1", qin, qout);
        int rc = system(cmd.buf);
        free(qin); free(qout); free(cmd.buf);
        if (rc != 0) return NULL;
        char *txt = read_file(outpath);
        unlink(outpath);
        return txt;
    }
    if (kind_out) *kind_out = xstrdup("text");
    return read_file(path);
}

static char *cache_path_for(const char *cache_dir, const char *source_path, const char *hash) {
    const char *b = strrchr(source_path, '/');
    b = b ? b + 1 : source_path;
    StrBuf s; sb_init(&s);
    sb_appendf(&s, "%s/%s-%s.qci", cache_dir, b, hash);
    return s.buf;
}

static bool read_line(FILE *f, char *buf, size_t cap) {
    if (!fgets(buf, (int)cap, f)) return false;
    size_t n = strlen(buf);
    while (n && (buf[n-1] == '\n' || buf[n-1] == '\r')) buf[--n] = '\0';
    return true;
}
static char *read_bytes(FILE *f, size_t n) {
    char *buf = malloc(n + 1);
    if (!buf) return NULL;
    if (fread(buf, 1, n, f) != n) { free(buf); return NULL; }
    buf[n] = '\0';
    return buf;
}

static bool save_index_cache(const char *cache_file, const DocIndex *doc, const char *source_text) {
    if (!ensure_parent_dirs(cache_file)) return false;
    FILE *f = fopen(cache_file, "wb");
    if (!f) return false;
    fprintf(f, "QCAIDX3\n");
    fprintf(f, "SOURCE_PATH_LEN %zu\n", strlen(doc->path));
    fwrite(doc->path, 1, strlen(doc->path), f); fputc('\n', f);
    fprintf(f, "SOURCE_KIND %s\n", doc->kind);
    fprintf(f, "SOURCE_HASH %s\n", doc->hash);
    fprintf(f, "SECTION_COUNT %zu\n", doc->sections.len);
    fprintf(f, "SOURCE_TEXT_LEN %zu\n", strlen(source_text ? source_text : ""));
    fwrite(source_text ? source_text : "", 1, strlen(source_text ? source_text : ""), f); fputc('\n', f);
    for (size_t i = 0; i < doc->sections.len; i++) {
        Section *s = &doc->sections.items[i];
        fprintf(f, "SECTION\nTITLE_LEN %zu\n", strlen(s->title));
        fwrite(s->title, 1, strlen(s->title), f); fputc('\n', f);
        fprintf(f, "TEXT_LEN %zu\n", strlen(s->text));
        fwrite(s->text, 1, strlen(s->text), f); fputc('\n', f);
    }
    fclose(f);
    return true;
}

static bool load_index_cache(const char *cache_file, DocIndex *doc, char **source_text_out) {
    FILE *f = fopen(cache_file, "rb");
    if (!f) return false;
    char line[256];
    if (!read_line(f, line, sizeof(line)) || strcmp(line, "QCAIDX3") != 0) { fclose(f); return false; }

    size_t path_len = 0, section_count = 0, source_text_len = 0;
    char kind[64] = {0}, hash[128] = {0};

    if (!read_line(f, line, sizeof(line)) || sscanf(line, "SOURCE_PATH_LEN %zu", &path_len) != 1) { fclose(f); return false; }
    char *path = read_bytes(f, path_len); if (!path) { fclose(f); return false; } fgetc(f);
    if (!read_line(f, line, sizeof(line)) || sscanf(line, "SOURCE_KIND %63s", kind) != 1) { free(path); fclose(f); return false; }
    if (!read_line(f, line, sizeof(line)) || sscanf(line, "SOURCE_HASH %127s", hash) != 1) { free(path); fclose(f); return false; }
    if (!read_line(f, line, sizeof(line)) || sscanf(line, "SECTION_COUNT %zu", &section_count) != 1) { free(path); fclose(f); return false; }
    if (!read_line(f, line, sizeof(line)) || sscanf(line, "SOURCE_TEXT_LEN %zu", &source_text_len) != 1) { free(path); fclose(f); return false; }

    char *src = read_bytes(f, source_text_len); if (!src) { free(path); fclose(f); return false; } fgetc(f);

    DocIndex tmp = {0};
    tmp.path = path;
    tmp.kind = xstrdup(kind);
    tmp.hash = xstrdup(hash);

    for (size_t i = 0; i < section_count; i++) {
        if (!read_line(f, line, sizeof(line)) || strcmp(line, "SECTION") != 0) { doc_free(&tmp); free(src); fclose(f); return false; }
        size_t tl=0, xl=0;
        if (!read_line(f, line, sizeof(line)) || sscanf(line, "TITLE_LEN %zu", &tl) != 1) { doc_free(&tmp); free(src); fclose(f); return false; }
        char *title = read_bytes(f, tl); if (!title) { doc_free(&tmp); free(src); fclose(f); return false; } fgetc(f);
        if (!read_line(f, line, sizeof(line)) || sscanf(line, "TEXT_LEN %zu", &xl) != 1) { free(title); doc_free(&tmp); free(src); fclose(f); return false; }
        char *text = read_bytes(f, xl); if (!text) { free(title); doc_free(&tmp); free(src); fclose(f); return false; } fgetc(f);
        vec_push(&tmp.sections, (Section){ .title = title, .text = text });
    }

    fclose(f);
    *doc = tmp;
    if (source_text_out) *source_text_out = src; else free(src);
    return true;
}

static bool build_or_load_index(const char *source_path, const char *cache_dir, size_t max_section_chars, DocIndex *doc, bool rebuild) {
    char *kind = NULL;
    char *text = extract_text(source_path, cache_dir, &kind);
    if (!text) return false;

    unsigned long long h = fnv1a64(text);
    char hash[32];
    snprintf(hash, sizeof(hash), "%016llx", h);

    char *cache_file = cache_path_for(cache_dir, source_path, hash);
    if (!rebuild && load_index_cache(cache_file, doc, NULL)) {
        free(cache_file); free(kind); free(text);
        return true;
    }

    DocIndex tmp = {0};
    tmp.path = xstrdup(source_path);
    tmp.kind = kind ? kind : xstrdup("text");
    tmp.hash = xstrdup(hash);
    split_sections(text, &tmp.sections, max_section_chars);
    save_index_cache(cache_file, &tmp, text);

    free(cache_file); free(kind); free(text);
    *doc = tmp;
    return true;
}

/* ---------- scoring / prompt ---------- */

static int score_text(const char *query, const char *text) {
    char *a = toupper_dup(query ? query : "");
    char *b = toupper_dup(text ? text : "");
    int score = 0;
    char *save = NULL;
    for (char *tok = strtok_r(a, " \t\r\n,.;:()[]{}<>|/\\\"'`!?", &save); tok; tok = strtok_r(NULL, " \t\r\n,.;:()[]{}<>|/\\\"'`!?", &save)) {
        if (strlen(tok) < 3) continue;
        if (strstr(b, tok)) score++;
    }
    free(a); free(b);
    return score;
}

static void append_top_sections(StrBuf *p, const DocIndex *doc, const char *query, int topk, const char *label) {
    if (!doc || doc->sections.len == 0) return;
    size_t n = doc->sections.len;
    int *score = calloc(n, sizeof(int));
    size_t *ord = calloc(n, sizeof(size_t));
    if (!score || !ord) { perror("calloc"); exit(1); }
    for (size_t i=0;i<n;i++) {
        ord[i]=i;
        score[i] = score_text(query, doc->sections.items[i].title) * 2 + score_text(query, doc->sections.items[i].text);
    }
    for (size_t i=0;i<n;i++) for (size_t j=i+1;j<n;j++) if (score[j] > score[i]) {
        int ts = score[i]; score[i]=score[j]; score[j]=ts;
        size_t to=ord[i]; ord[i]=ord[j]; ord[j]=to;
    }
    sb_appendf(p, "\n====================\n%s\nSOURCE: %s\nHASH: %s\n--------------------\n", label, doc->path, doc->hash);
    for (int i=0; i<topk && (size_t)i<n; i++) {
        Section *s = &doc->sections.items[ord[i]];
        sb_appendf(p, "\n[SECTION] %s\n", s->title);
        sb_append(p, s->text);
        sb_append(p, "\n");
    }
    free(score); free(ord);
}

static char *build_prompt(const JobConfig *cfg, const Section *sec) {
    StrBuf p; sb_init(&p);
    sb_append(&p,
        "You are QCAv13-5, an offline constitutional review engine.\n"
        "TASK OBJECTIVE:\n"
        "Analyze each Iowa Code section as subordinate text and determine whether it may burden, chill, condition, compel, search, seize, disclose, or otherwise conflict with rights protected by the Bill of Rights.\n"
        "The goal is to catch both obvious and subtle conflicts, then explain why the text matters.\n\n"
        "HIERARCHY RULE:\n"
        "1. The Bill of Rights is the controlling authority.\n"
        "2. The Iowa Code is subordinate and must be tested against it.\n"
        "3. Do not treat the Iowa Code as the root document.\n"
        "4. Do not declare a legal violation as fact; identify possible constitutional issues and explain them.\n"
        "5. If the section is ordinary and no plausible conflict appears, say so explicitly.\n\n"
        "ANALYSIS CHECKLIST:\n"
        "- fees, permits, licenses, approvals\n"
        "- compelled speech, disclosure, or association\n"
        "- warrantless searches, seizures, inspections\n"
        "- vague standards, broad discretion, penalties\n"
        "- burdens on expression, religion, press, assembly, petition\n"
        "- burdens on privacy, due process, counsel, self-incrimination, jury rights\n\n"
        "Return JSON only with keys:\n"
        "section_title, possible_amendments, hierarchy_result, explanation, supporting_arguments, challenging_arguments, section_summary.\n");

    if (cfg->nrefs > 0) {
        append_top_sections(&p, &cfg->refs[0], sec->text ? sec->text : "", cfg->topk_refs, "CONTROLLING REFERENCE: BILL OF RIGHTS");
        for (size_t r=1; r<cfg->nrefs; r++) {
            char label[256];
            snprintf(label, sizeof(label), "REFERENCE %zu", r + 1);
            append_top_sections(&p, &cfg->refs[r], sec->text ? sec->text : "", cfg->topk_refs / 2 + 1, label);
        }
    }
    sb_append(&p, "\nROLLING SUMMARY:\n");
    sb_append(&p, cfg->rolling_summary && *cfg->rolling_summary ? cfg->rolling_summary : "(none)\n");
    sb_append(&p, "\nCURRENT IOWA CODE SECTION TITLE:\n");
    sb_append(&p, sec->title ? sec->title : "(untitled section)");
    sb_append(&p, "\n\nCURRENT IOWA CODE SECTION TEXT:\n");
    sb_append(&p, sec->text ? sec->text : "");
    sb_append(&p, "\n");
    return p.buf;
}


static char *extract_summary(const char *out, size_t limit) {
    if (!out) return xstrdup("");
    const char *key = "\"section_summary\"";
    const char *p = strstr(out, key);
    if (p) {
        const char *colon = strchr(p, ':');
        if (colon) {
            const char *s = colon + 1;
            while (*s && isspace((unsigned char)*s)) s++;
            if (*s == '"') {
                s++;
                StrBuf b; sb_init(&b);
                for (; *s && b.len < limit; s++) {
                    if (*s == '\\' && s[1]) { s++; sb_append_n(&b, s, 1); }
                    else if (*s == '"') break;
                    else sb_append_n(&b, s, 1);
                }
                return b.buf ? b.buf : xstrdup("");
            }
        }
    }
    StrBuf b; sb_init(&b);
    const char *s = out;
    while (*s && isspace((unsigned char)*s)) s++;
    for (; *s && b.len < limit; s++) sb_append_n(&b, s, 1);
    return b.buf ? b.buf : xstrdup("");
}


static void csv_escape(FILE *f, const char *s);

static void append_section_report(const JobConfig *cfg, size_t idx, const Section *sec, const char *raw_path, const char *raw_text, const char *summary) {
    if (!cfg->report_md || !cfg->report_csv || !cfg->report_json || !cfg->report_count || !cfg->report_lock) return;
    pthread_mutex_lock(cfg->report_lock);

    fprintf(cfg->report_md, "## %s\n\n### Raw output\n\n```text\n%s\n```\n\n",
            sec->title ? sec->title : "(untitled section)", raw_text ? raw_text : "");

    fprintf(cfg->report_csv, "%zu,", idx + 1);
    csv_escape(cfg->report_csv, sec->title ? sec->title : "(untitled section)");
    fputc(',', cfg->report_csv);
    csv_escape(cfg->report_csv, raw_path);
    fputc(',', cfg->report_csv);
    csv_escape(cfg->report_csv, summary ? summary : "");
    fputc('\n', cfg->report_csv);

    if (*(cfg->report_count) > 0) fputs(",\n", cfg->report_json);
    fputs("    {\n", cfg->report_json);
    fprintf(cfg->report_json, "      \"index\": %zu,\n", idx + 1);
    fputs("      \"section_title\": ", cfg->report_json); csv_escape(cfg->report_json, sec->title ? sec->title : "(untitled section)"); fputs(",\n", cfg->report_json);
    fputs("      \"raw_output_file\": ", cfg->report_json); csv_escape(cfg->report_json, raw_path); fputs(",\n", cfg->report_json);
    fputs("      \"summary\": ", cfg->report_json); csv_escape(cfg->report_json, summary ? summary : ""); fputc('\n', cfg->report_json);
    fputs("    }", cfg->report_json);

    fflush(cfg->report_md);
    fflush(cfg->report_csv);
    fflush(cfg->report_json);
    *(cfg->report_count) += 1;

    pthread_mutex_unlock(cfg->report_lock);
}

static char *runner_cmd_from_template(const char *tmpl, const char *prompt_file, const char *prompt_text, size_t max_tokens, size_t ctx_size) {
    char max_buf[32], ctx_buf[32];
    snprintf(max_buf, sizeof(max_buf), "%zu", max_tokens);
    snprintf(ctx_buf, sizeof(ctx_buf), "%zu", ctx_size);
    char *qf = shell_quote(prompt_file);
    char *qp = shell_quote(prompt_text ? prompt_text : "");
    char *a = replace_all(tmpl, "{PROMPT_FILE}", qf);
    char *b = replace_all(a, "{PROMPT}", qp);
    char *c = replace_all(b, "{MAX_TOKENS}", max_buf);
    char *d = replace_all(c, "{CTX_SIZE}", ctx_buf);
    free(qf); free(qp); free(a); free(b); free(c);
    StrBuf out; sb_init(&out);
    sb_append(&out, d);
    if (!strstr(d, "-n ") && !strstr(d, "--n-predict ")) sb_appendf(&out, " -n %zu", max_tokens);
    if (!strstr(d, "--simple-io")) sb_append(&out, " --simple-io");
    if (!strstr(d, "--no-display-prompt")) sb_append(&out, " --no-display-prompt");
    if (!strstr(d, "--skip-chat-parsing")) sb_append(&out, " --skip-chat-parsing");
    if (!strstr(d, "--single-turn")) sb_append(&out, " --single-turn");
    free(d);
    return out.buf;
}

static char *run_capture(const char *cmd) {
    StrBuf out; sb_init(&out);
    char *full = malloc(strlen(cmd) + 8);
    if (!full) { perror("malloc"); exit(1); }
    sprintf(full, "%s 2>&1", cmd);
    FILE *fp = popen(full, "r");
    free(full);
    if (!fp) return NULL;
    char buf[4096];
    while (fgets(buf, sizeof(buf), fp)) sb_append(&out, buf);
    pclose(fp);
    return out.buf;
}

static const char *profile_name(Profile p) {
    switch (p) {
        case PROF_ULTRA_LOW: return "ultra-low";
        case PROF_LOW: return "low";
        case PROF_MEDIUM: return "medium";
        case PROF_HIGH: return "high";
        case PROF_ULTRA: return "ultra";
    }
    return "low";
}

static void profile_defaults(Profile p, size_t *ctx, size_t *max_tokens, size_t *sec_chars, size_t *sum_chars, int *workers, int *topk) {
    switch (p) {
        case PROF_ULTRA_LOW: *ctx=512; *max_tokens=128; *sec_chars=900; *sum_chars=220; *workers=1; *topk=4; break;
        case PROF_LOW: *ctx=1024; *max_tokens=192; *sec_chars=1400; *sum_chars=320; *workers=1; *topk=6; break;
        case PROF_MEDIUM: *ctx=2048; *max_tokens=256; *sec_chars=2200; *sum_chars=450; *workers=2; *topk=8; break;
        case PROF_HIGH: *ctx=4096; *max_tokens=384; *sec_chars=3200; *sum_chars=700; *workers=3; *topk=10; break;
        case PROF_ULTRA: *ctx=8192; *max_tokens=512; *sec_chars=5000; *sum_chars=900; *workers=4; *topk=12; break;
    }
}

static long total_mem_mb(void) {
    struct sysinfo si;
    if (sysinfo(&si) != 0) return 0;
    unsigned long long total = (unsigned long long)si.totalram * si.mem_unit;
    return (long)(total / (1024ULL * 1024ULL));
}
static int cpu_count(void) {
    long n = sysconf(_SC_NPROCESSORS_ONLN);
    return n > 0 ? (int)n : 1;
}
static int auto_workers(size_t ctx_size, size_t max_tokens) {
    int cpus = cpu_count();
    long mem = total_mem_mb();
    int w = cpus > 1 ? cpus - 1 : 1;
    if (mem > 0 && mem < 6144) w = 1;
    else if (mem < 12288 && w > 2) w = 2;
    if (ctx_size >= 8192 || max_tokens >= 512) w = w > 2 ? 2 : w;
    if (w < 1) w = 1;
    return w;
}

/* ---------- output helpers ---------- */

static void csv_escape(FILE *f, const char *s) {
    fputc('"', f);
    for (; s && *s; s++) {
        if (*s == '"') fputc('"', f);
        fputc(*s, f);
    }
    fputc('"', f);
}

static void usage(void) {
    fprintf(stderr,
        "Usage: %s --input FILE --reference FILE [--reference FILE ...] --outdir DIR [options]\n"
        "Options:\n"
        "  --runner-template CMD   llama.cpp template using {PROMPT} or {PROMPT_FILE}\n"
        "  --profile NAME          ultra-low | low | medium | high | ultra\n"
        "  --ctx-size N            Override context size\n"
        "  --max-tokens N          Override generation cap per section\n"
        "  --max-section-chars N   Override chunk size before forced split\n"
        "  --summary-chars N       Override rolling summary limit\n"
        "  --workers N|auto        Override worker count (default auto)\n"
        "  --interactive           Pause between sections (single-worker mode only)\n"
        "  --show-prompts          Print prompts before each llama.cpp call\n"
        "  --resume                Resume from checkpoint files in the output directory\n"
        "  --reset                 Ignore any existing checkpoint and start over\n"
        "  --reindex               Rebuild source indexes even if cached versions exist\n"
        "  --pdf                   Try to write report.pdf with pandoc if available\n"
        "  --list-profiles         Print the built-in memory profiles and exit\n",
        APP);
}

static void list_profiles(void) {
    puts("ultra-low  ctx=512  tokens=128  section=900  summary=220");
    puts("low        ctx=1024 tokens=192  section=1400 summary=320");
    puts("medium     ctx=2048 tokens=256  section=2200 summary=450");
    puts("high       ctx=4096 tokens=384  section=3200 summary=700");
    puts("ultra      ctx=8192 tokens=512  section=5000 summary=900");
}

static char *rolling_next(const char *old, const char *section_out, size_t limit) {
    char *sum = extract_summary(section_out, limit);
    if (!old || !*old) return sum;
    StrBuf b; sb_init(&b);
    sb_append(&b, sum);
    if (b.len + strlen(old) + 1 < limit) {
        sb_append(&b, "\n");
        sb_append(&b, old);
    }
    free(sum);
    return b.buf ? b.buf : xstrdup("");
}

static void save_state(const char *state_dir, size_t next_idx, const char *rolling, const char *hash) {
    char p[PATH_MAX];
    snprintf(p, sizeof(p), "%s/next_section.txt", state_dir); write_file(p, (char[64]){0}); char tmp[64]; snprintf(tmp, sizeof(tmp), "%zu", next_idx); write_file(p, tmp);
    snprintf(p, sizeof(p), "%s/rolling_summary.txt", state_dir); write_file(p, rolling ? rolling : "");
    snprintf(p, sizeof(p), "%s/input_hash.txt", state_dir); write_file(p, hash ? hash : "");
}

static int parse_workers_arg(const char *s, int auto_val) {
    if (!s || strcmp(s, "auto") == 0) return auto_val;
    return (int)strtol(s, NULL, 10);
}

/* ---------- worker loop ---------- */

static void *worker_loop(void *arg) {
    WorkerArgs *w = (WorkerArgs *)arg;
    for (;;) {
        pthread_mutex_lock(w->cursor_lock);
        size_t idx = *w->cursor;
        if (idx >= w->end_idx) {
            pthread_mutex_unlock(w->cursor_lock);
            break;
        }
        (*w->cursor)++;
        pthread_mutex_unlock(w->cursor_lock);

        const Section *sec = &w->cfg->input_doc->sections.items[idx];
        char prompt_path[PATH_MAX], raw_path[PATH_MAX], sec_json[PATH_MAX];
        snprintf(prompt_path, sizeof(prompt_path), "%s/section_%04zu.prompt.txt", w->cfg->workdir, idx + 1);
        snprintf(raw_path, sizeof(raw_path), "%s/section_%04zu.raw.txt", w->cfg->workdir, idx + 1);
        snprintf(sec_json, sizeof(sec_json), "%s/section_%04zu.json", w->cfg->outdir, idx + 1);

        char *prompt = build_prompt(w->cfg, sec);
        write_file(prompt_path, prompt);
        char *cmd = runner_cmd_from_template(w->cfg->runner_template, prompt_path, prompt, w->cfg->max_tokens, w->cfg->ctx_size);

        pthread_mutex_lock(w->io_lock);
        printf("[%d|%zu/%zu] %s\n", w->worker_id, idx + 1, w->cfg->input_doc->sections.len, sec->title ? sec->title : "(untitled section)");
        if (w->cfg->show_prompts) {
            printf("----- PROMPT -----\n%s\n------------------\n", prompt);
        }
        pthread_mutex_unlock(w->io_lock);

        char *raw = run_capture(cmd);
        if (!raw) {
            w->failed = 1;
            free(prompt); free(cmd);
            break;
        }

        write_file(raw_path, raw);
        write_file(sec_json, raw);

        pthread_mutex_lock(w->io_lock);
        char *newsum = rolling_next(w->cfg->rolling_summary, raw, w->cfg->summary_limit);
        free(((JobConfig *)w->cfg)->rolling_summary);
        ((JobConfig *)w->cfg)->rolling_summary = newsum;
        save_state(w->cfg->outdir, idx + 2, w->cfg->rolling_summary, w->cfg->input_doc->hash);
        pthread_mutex_unlock(w->io_lock);

        append_section_report(w->cfg, idx, sec, raw_path, raw, w->cfg->rolling_summary);

        pthread_mutex_lock(w->io_lock);
        *w->done += 1;
        pthread_mutex_unlock(w->io_lock);

        free(prompt);
        free(cmd);
        free(raw);
    }
    return NULL;
}

/* ---------- main ---------- */

int main(int argc, char **argv) {
    const char *input = NULL, *outdir = NULL, *runner_template = NULL;
    bool want_pdf = false, interactive = false, show_prompts = false, resume = true, reset = false, reindex = false, list_profiles_flag = false;
    int workers_override = -1;

    Profile profile = PROF_LOW;
    size_t ctx_size = 0, max_tokens = 0, max_section_chars = 0, summary_chars = 0;
    int workers_default = 1, topk_refs = 6;

    char **ref_paths = NULL;
    size_t nrefs_in = 0, ref_cap = 0;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--input") == 0 && i + 1 < argc) input = argv[++i];
        else if (strcmp(argv[i], "--reference") == 0 && i + 1 < argc) {
            if (nrefs_in == ref_cap) {
                size_t nc = ref_cap ? ref_cap * 2 : 8;
                char **p = realloc(ref_paths, nc * sizeof(*p));
                if (!p) { perror("realloc"); return 1; }
                ref_paths = p; ref_cap = nc;
            }
            ref_paths[nrefs_in++] = argv[++i];
        } else if (strcmp(argv[i], "--outdir") == 0 && i + 1 < argc) outdir = argv[++i];
        else if (strcmp(argv[i], "--runner-template") == 0 && i + 1 < argc) runner_template = argv[++i];
        else if (strcmp(argv[i], "--profile") == 0 && i + 1 < argc) {
            const char *p = argv[++i];
            if (strcmp(p, "ultra-low") == 0) profile = PROF_ULTRA_LOW;
            else if (strcmp(p, "low") == 0) profile = PROF_LOW;
            else if (strcmp(p, "medium") == 0) profile = PROF_MEDIUM;
            else if (strcmp(p, "high") == 0) profile = PROF_HIGH;
            else if (strcmp(p, "ultra") == 0) profile = PROF_ULTRA;
            else { fprintf(stderr, "%s: unknown profile %s\n", APP, p); return 1; }
        } else if (strcmp(argv[i], "--ctx-size") == 0 && i + 1 < argc) ctx_size = (size_t)strtoul(argv[++i], NULL, 10);
        else if (strcmp(argv[i], "--max-tokens") == 0 && i + 1 < argc) max_tokens = (size_t)strtoul(argv[++i], NULL, 10);
        else if (strcmp(argv[i], "--max-section-chars") == 0 && i + 1 < argc) max_section_chars = (size_t)strtoul(argv[++i], NULL, 10);
        else if (strcmp(argv[i], "--summary-chars") == 0 && i + 1 < argc) summary_chars = (size_t)strtoul(argv[++i], NULL, 10);
        else if (strcmp(argv[i], "--workers") == 0 && i + 1 < argc) workers_override = parse_workers_arg(argv[++i], -1);
        else if (strcmp(argv[i], "--pdf") == 0) want_pdf = true;
        else if (strcmp(argv[i], "--interactive") == 0) interactive = true;
        else if (strcmp(argv[i], "--show-prompts") == 0) show_prompts = true;
        else if (strcmp(argv[i], "--resume") == 0) resume = true;
        else if (strcmp(argv[i], "--reset") == 0) reset = true;
        else if (strcmp(argv[i], "--reindex") == 0) reindex = true;
        else if (strcmp(argv[i], "--list-profiles") == 0) list_profiles_flag = true;
        else { usage(); return 1; }
    }

    if (list_profiles_flag) { list_profiles(); return 0; }
    if (!input || !outdir || nrefs_in == 0) { usage(); return 1; }

    profile_defaults(profile, &ctx_size, &max_tokens, &max_section_chars, &summary_chars, &workers_default, &topk_refs);
    if (ctx_size == 0) ctx_size = 1024;
    if (max_tokens == 0) max_tokens = 192;
    if (max_section_chars == 0) max_section_chars = 1400;
    if (summary_chars == 0) summary_chars = 320;

    int workers = workers_override < 0 ? auto_workers(ctx_size, max_tokens) : workers_override;
    if (workers < 1) workers = 1;
    int cpus = cpu_count();
    if (workers > cpus) workers = cpus;
    long mem = total_mem_mb();
    if (mem > 0 && mem < 6144) workers = 1;

    if (!ensure_dir(outdir)) { fprintf(stderr, "%s: cannot create outdir %s\n", APP, outdir); return 1; }

    char workdir[PATH_MAX], cache_dir[PATH_MAX], state_dir[PATH_MAX];
    snprintf(workdir, sizeof(workdir), "%s/work", outdir);
    snprintf(cache_dir, sizeof(cache_dir), "%s/.qca_cache", outdir);
    snprintf(state_dir, sizeof(state_dir), "%s/.qca_state", outdir);
    if (!ensure_dir(workdir) || !ensure_dir(cache_dir) || !ensure_dir(state_dir)) {
        fprintf(stderr, "%s: unable to create output subdirectories\n", APP);
        return 1;
    }

    /* index input and references */
    DocIndex input_doc = {0};
    if (!build_or_load_index(input, cache_dir, max_section_chars, &input_doc, reindex)) {
        fprintf(stderr, "%s: failed to index input %s\n", APP, input);
        return 1;
    }
    DocIndex *refs = calloc(nrefs_in, sizeof(DocIndex));
    if (!refs) { perror("calloc"); return 1; }
    for (size_t i = 0; i < nrefs_in; i++) {
        if (!build_or_load_index(ref_paths[i], cache_dir, max_section_chars, &refs[i], reindex)) {
            fprintf(stderr, "%s: failed to index reference %s\n", APP, ref_paths[i]);
            return 1;
        }
    }

    char report_md[PATH_MAX], report_csv[PATH_MAX], report_json[PATH_MAX];
    snprintf(report_md, sizeof(report_md), "%s/report.md", outdir);
    snprintf(report_csv, sizeof(report_csv), "%s/index.csv", outdir);
    snprintf(report_json, sizeof(report_json), "%s/index.json", outdir);

    char state_next[PATH_MAX], state_sum[PATH_MAX], state_hash[PATH_MAX];
    snprintf(state_next, sizeof(state_next), "%s/next_section.txt", state_dir);
    snprintf(state_sum, sizeof(state_sum), "%s/rolling_summary.txt", state_dir);
    snprintf(state_hash, sizeof(state_hash), "%s/input_hash.txt", state_dir);

    unsigned long long ih = fnv1a64(input_doc.hash ? input_doc.hash : "");
    char input_hash_hex[64];
    snprintf(input_hash_hex, sizeof(input_hash_hex), "%016llx", ih);

    size_t start_idx = 1;
    if (resume && !reset) {
        char *oldh = read_file(state_hash);
        if (oldh) {
            trim_inplace(oldh);
            if (strcmp(oldh, input_hash_hex) == 0) {
                char *n = read_file(state_next);
                if (n) {
                    trim_inplace(n);
                    size_t v = (size_t)strtoull(n, NULL, 10);
                    if (v > 0) start_idx = v;
                    free(n);
                }
            }
            free(oldh);
        }
    }
    if (!resume || reset) {
        write_file(state_hash, input_hash_hex);
        write_file(state_next, "1");
        write_file(state_sum, "");
    }

    char *rolling_prev = read_file(state_sum);
    if (!rolling_prev) rolling_prev = xstrdup("");

    FILE *md = fopen(report_md, (resume && !reset && start_idx > 1) ? "ab" : "wb");
    FILE *csv = fopen(report_csv, (resume && !reset && start_idx > 1) ? "ab" : "wb");
    FILE *js = fopen(report_json, (resume && !reset && start_idx > 1) ? "ab" : "wb");
    if (!md || !csv || !js) { perror("open report"); return 1; }

    if (!(resume && !reset && start_idx > 1)) {
        fputs("# QCAv13-5 Report\n\n", md);
        fprintf(md, "- Input: `%s`\n", input);
        fprintf(md, "- Reference count: %zu\n", nrefs_in);
        fprintf(md, "- Profile: %s\n", profile_name(profile));
        fprintf(md, "- Workers: %d\n\n", workers);
        fputs("section_index,section_title,raw_output_file,summary\n", csv);
        fputs("{\n  \"sections\": [\n", js);
    }

    size_t report_count = 0;
    pthread_mutex_t report_lock = PTHREAD_MUTEX_INITIALIZER;

    JobConfig cfg = {
        .input_doc = &input_doc,
        .refs = refs,
        .nrefs = nrefs_in,
        .rolling_summary = rolling_prev,
        .summary_limit = summary_chars,
        .max_tokens = max_tokens,
        .ctx_size = ctx_size,
        .topk_refs = topk_refs,
        .runner_template = runner_template,
        .workdir = workdir,
        .outdir = outdir,
        .report_md = md,
        .report_csv = csv,
        .report_json = js,
        .report_count = &report_count,
        .report_lock = &report_lock,
        .show_prompts = show_prompts
    };

    size_t done = 0;

    if (workers <= 1) {
        for (size_t i = start_idx - 1; i < input_doc.sections.len; i++) {
            const Section *sec = &input_doc.sections.items[i];
            char prompt_path[PATH_MAX], raw_path[PATH_MAX], sec_json[PATH_MAX];
            snprintf(prompt_path, sizeof(prompt_path), "%s/section_%04zu.prompt.txt", workdir, i + 1);
            snprintf(raw_path, sizeof(raw_path), "%s/section_%04zu.raw.txt", workdir, i + 1);
            snprintf(sec_json, sizeof(sec_json), "%s/section_%04zu.json", outdir, i + 1);

            char *prompt = build_prompt(&cfg, sec);
            write_file(prompt_path, prompt);
            char *cmd = runner_cmd_from_template(runner_template, prompt_path, prompt, max_tokens, ctx_size);

            if (show_prompts) {
                printf("\n===== PROMPT %zu / %zu =====\n%s\n===========================\n", i + 1, input_doc.sections.len, prompt);
            }
            printf("[%zu/%zu] %s\n", i + 1, input_doc.sections.len, sec->title ? sec->title : "(untitled section)");
            fflush(stdout);

            char *raw = run_capture(cmd);
            if (!raw) { fprintf(stderr, "%s: runner failed\n", APP); return 1; }

            write_file(raw_path, raw);
            write_file(sec_json, raw);

            char *newsum = rolling_next(cfg.rolling_summary, raw, summary_chars);
            free(cfg.rolling_summary);
            cfg.rolling_summary = newsum;

            save_state(state_dir, i + 2, cfg.rolling_summary, input_hash_hex);
            write_file(state_hash, input_hash_hex);

            fprintf(md, "## %s\n\n### Raw output\n\n```text\n%s\n```\n\n", sec->title ? sec->title : "(untitled section)", raw);
            fprintf(csv, "%zu,", i + 1); csv_escape(csv, sec->title ? sec->title : "(untitled section)"); fputc(',', csv); csv_escape(csv, raw_path); fputc(',', csv); csv_escape(csv, cfg.rolling_summary); fputc('\n', csv);

            if (done++) fputs(",\n", js);
            fputs("    {\n", js);
            fprintf(js, "      \"index\": %zu,\n", i + 1);
            fputs("      \"section_title\": ", js); csv_escape(js, sec->title ? sec->title : "(untitled section)"); fputs(",\n", js);
            fputs("      \"raw_output_file\": ", js); csv_escape(js, raw_path); fputs(",\n", js);
            fputs("      \"summary\": ", js); csv_escape(js, cfg.rolling_summary); fputc('\n', js);
            fputs("    }", js);

            free(prompt); free(cmd); free(raw);

            if (interactive) {
                printf("\n--- press ENTER for next section, or q then ENTER to stop ---\n");
                char line[16];
                if (!fgets(line, sizeof(line), stdin)) break;
                if (line[0] == 'q' || line[0] == 'Q') break;
            }
        }
    } else {
        pthread_mutex_t io_lock = PTHREAD_MUTEX_INITIALIZER;
        pthread_mutex_t cursor_lock = PTHREAD_MUTEX_INITIALIZER;
        size_t cursor = start_idx - 1;
        WorkerArgs *wa = calloc((size_t)workers, sizeof(WorkerArgs));
        pthread_t *ths = calloc((size_t)workers, sizeof(pthread_t));
        if (!wa || !ths) { perror("calloc"); return 1; }

        for (int i = 0; i < workers; i++) {
            wa[i].cfg = &cfg;
            wa[i].next_idx = start_idx - 1;
            wa[i].end_idx = input_doc.sections.len;
            wa[i].cursor = &cursor;
            wa[i].cursor_lock = &cursor_lock;
            wa[i].io_lock = &io_lock;
            wa[i].done = &done;
            wa[i].worker_id = i + 1;
            if (pthread_create(&ths[i], NULL, worker_loop, &wa[i]) != 0) {
                perror("pthread_create");
                return 1;
            }
        }
        for (int i = 0; i < workers; i++) pthread_join(ths[i], NULL);
        free(wa);
        free(ths);

        save_state(state_dir, input_doc.sections.len + 1, cfg.rolling_summary, input_hash_hex);
        write_file(state_hash, input_hash_hex);
    }

    fputs("\n  ]\n}\n", js);
    fflush(md); fflush(csv); fflush(js);
    fclose(md); fclose(csv); fclose(js);

    if (want_pdf) {
        char pdf_cmd[PATH_MAX * 2];
        snprintf(pdf_cmd, sizeof(pdf_cmd), "pandoc %s -o %s/report.pdf >/dev/null 2>&1", report_md, outdir);
        system(pdf_cmd);
    }

    printf("Done. Reports written to %s\n", outdir);
    printf("Workers used: %d\n", workers);
    printf("Index cache: %s/.qca_cache/\n", outdir);
    printf("Resume state: %s/.qca_state/\n", outdir);

    free(cfg.rolling_summary);
    doc_free(&input_doc);
    for (size_t i = 0; i < nrefs_in; i++) doc_free(&refs[i]);
    free(refs);
    free(ref_paths);

    return 0;
}
