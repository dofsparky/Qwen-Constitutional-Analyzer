#!/usr/bin/env python3 -u
import sys, pathlib, re, json
pf=None
for i,a in enumerate(sys.argv[1:]):
    if a in ("-f","--file","--prompt-file") and i+1 < len(sys.argv[1:]):
        pf=sys.argv[1:][i+1]; break
    if a.startswith("-f") and len(a)>2:
        pf=a[2:]; break
text=pathlib.Path(pf).read_text(encoding="utf-8", errors="ignore") if pf else ""
m=re.search(r"PASS (\d)/7", text)
stage=int(m.group(1)) if m else 0
# intentionally short output
print(json.dumps({"pass":stage,"section_title":"CHAPTER 123","answer":"ok","possible_amendments":["First Amendment"],"evidence":["license"],"confidence":0.9}))
