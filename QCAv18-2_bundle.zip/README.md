# QCAv18-2

QCAv18-2 adds a seven-pass constitutional analysis engine:

1. What does this statute do?
2. What powers does it grant the government?
3. What burdens does it impose on citizens?
4. Which constitutional amendments could be implicated?
5. What arguments support constitutionality?
6. What arguments challenge constitutionality?
7. Write the final constitutional review.

It keeps resume state, prompt pipelining, offline reference retrieval, and PDF/text input support.

## Run

```bash
./QCAv18-2   --input /path/to/iowa_code_2026.txt   --reference /path/to/bill_of_rights.txt   --outdir /path/to/out   --runner-template 'python3 -u qca_runner_mock.py -f {PROMPT_FILE}'
```

Replace the runner template with your real local model wrapper for actual analysis.
