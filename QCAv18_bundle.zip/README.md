# QCAv18 lamerized

QCAv18 strips runner noise before saving or continuing and prints structured progress with chunk, chapter, statute, rate, ETA, and model throughput.

## Use

```bash
./QCAv18   --profile ultra   --throughput max   --workers auto   --prompt-budget 3000   --input "/home/delta/C/iowa_code_2026.txt"   --reference "/home/delta/references/bill_of_rights.txt"   --outdir "/home/delta/iowa/iowa-qca-v18"   --runner-template 'python3 -u /home/delta/QCAv18/qca_runner_wrapper.py -f {PROMPT_FILE}'
```

## Notes

- The included wrapper emits noisy model-like output so sanitization can be verified.
- For a real backend, point the wrapper at your local persistent server or long-lived process.
