#!/usr/bin/env python3 -u
import sys, json, pathlib
prompt = pathlib.Path(sys.argv[sys.argv.index("-f")+1]).read_text(encoding="utf-8", errors="ignore") if "-f" in sys.argv else sys.stdin.read()
q = prompt.lower()
if "search" in q or "warrant" in q:
    obj = {"section_title":"Chapter 456","answer":"Possible Fourth Amendment issue because the section authorizes searches and may allow exceptions that need close scrutiny.","possible_amendments":["Fourth Amendment"],"evidence":["search authority","warrant exception"],"confidence":0.91}
elif "petition" in q or "fee" in q:
    obj = {"section_title":"Chapter 789","answer":"Possible First Amendment burden because fees or restrictions may chill petitioning and related speech.","possible_amendments":["First Amendment"],"evidence":["petition restriction","publication fee"],"confidence":0.89}
else:
    obj = {"section_title":"Chapter 123","answer":"Possible First Amendment and due-process concerns because the section requires a license and imposes a penalty.","possible_amendments":["First Amendment","Fifth Amendment"],"evidence":["license required","penalty for violation"],"confidence":0.93}
print("load_backend: loaded CPU backend from /usr/lib/x86_64-linux-gnu/ggml/backends0/libggml-cpu-icelake.so")
print("Loading model...")
print("<think>")
print("internal reasoning that should be removed")
print("</think>")
print("[ Prompt: 20.1 t/s | Generation: 34.8 t/s ]")
print("llama_memory_breakdown_print: | memory breakdown [MiB] | total   free    self   model   context   compute    unaccounted |")
print(json.dumps(obj))
print("<<<QCA_RESPONSE_END>>>")
