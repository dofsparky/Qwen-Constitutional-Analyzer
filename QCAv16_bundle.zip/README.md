# QCAv16 lamerized

QCAv16 keeps the retrieval-first design and tightens the default prompt budget so more room is left for the answer.

## What changed

- `--prepare` / `--index-only` still build and cache the documents
- prompts are budgeted before Qwen runs
- default prompt budget is more conservative
- only the most relevant matches and compact cross-reference context are sent
- analysis mode still works when `--questions` is omitted
- question mode still works when `--questions` is provided

## Why this is the better approach

QCAv16 treats the cache as the retrieval engine and the model as the reasoner.

1. Build packs and cache them.
2. Score chunks locally.
3. Select only the best matches.
4. Fit the prompt to budget.
5. Call the model with the smallest useful context.

That keeps the workflow fast and keeps the prompt away from context overflow.

## Example

```bash
./QCAv16   --profile ultra   --prompt-budget 5000   --workers auto   --input "/home/delta/iowa/2022-iowa-code.pdf"   --reference "/home/delta/references/bill-of-rights.pdf"   --outdir "iowa-2022"   --runner-template 'llama-cli -m /home/delta/models/Qwen3-4B-Q4_K_M.gguf --jinja --reasoning on --reasoning-budget -1 -c {CTX_SIZE} -n 2048 --temp 0.6 --top-k 40 --top-p 0.95 --min-p 0.05 --repeat-penalty 1.05 -f {PROMPT_FILE}'
```

## Notes

- `--prepare` and `--index-only` do not require `--runner-template`
- if a cache already exists, later runs can reuse it
- analysis mode automatically activates when `--questions` is omitted
- `--prompt-budget` defaults to about 60% of the chosen context size if omitted
