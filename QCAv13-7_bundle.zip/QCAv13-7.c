
#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <sys/stat.h>
#include <sys/sysinfo.h>
#include <unistd.h>

#define APP "QCAv13-7"

typedef struct { char *title; char *text; } Section;
typedef struct { Section *items; size_t len, cap; } SectionVec;
typedef struct { char *buf; size_t len, cap; } StrBuf;
typedef enum { PROF_LOW, PROF_MEDIUM, PROF_HIGH, PROF_ULTRA } Profile;

typedef struct {
    char *path;
    char *kind;   /* pdf/text */
    char *hash;
    char *full_text;
    SectionVec chunks;
} Pack;

/* ---------- string helpers ---------- */

static void sb_init(StrBuf *b) { b->buf = NULL; b->len = b->cap = 0; }
static void sb_reserve(StrBuf *b, size_t add) {
    size_t need = b->len + add + 1;
    if (need <= b->cap) return;
    size_t nc = b->cap ? b->cap : 1024;
    while (nc < need) nc *= 2;
    char *p = realloc(b->buf, nc);
    if (!p) { perror("realloc"); exit(1); }
    b->buf = p; b->cap = nc;
}
static void sb_append_n(StrBuf *b, const char *s, size_t n) {
    if (!s || !n) return;
    sb_reserve(b, n);
    memcpy(b->buf + b->len, s, n);
    b->len += n;
    b->buf[b->len] = '\0';
}
static void sb_append(StrBuf *b, const char *s) { if (s) sb_append_n(b, s, strlen(s)); }
static void sb_appendf(StrBuf *b, const char *fmt, ...) {
    va_list ap, ap2;
    va_start(ap, fmt);
    va_copy(ap2, ap);
    int n = vsnprintf(NULL, 0, fmt, ap);
    va_end(ap);
    if (n < 0) { va_end(ap2); return; }
    sb_reserve(b, (size_t)n);
    vsnprintf(b->buf + b->len, b->cap - b->len, fmt, ap2);
    va_end(ap2);
    b->len += (size_t)n;
}
static char *xstrdup(const char *s) {
    if (!s) s = "";
    size_t n = strlen(s);
    char *p = malloc(n + 1);
    if (!p) { perror("malloc"); exit(1); }
    memcpy(p, s, n + 1);
    return p;
}
static char *trim_inplace(char *s) {
    if (!s) return s;
    char *st = s;
    while (*st && isspace((unsigned char)*st)) st++;
    char *en = st + strlen(st);
    while (en > st && isspace((unsigned char)en[-1])) en--;
    size_t n = (size_t)(en - st);
    if (st != s) memmove(s, st, n);
    s[n] = '\0';
    return s;
}
static char *dup_trim(const char *s) { return trim_inplace(xstrdup(s)); }
static char *toupper_dup(const char *s) {
    size_t n = strlen(s ? s : "");
    char *p = malloc(n + 1);
    if (!p) { perror("malloc"); exit(1); }
    for (size_t i = 0; i < n; i++) p[i] = (char)toupper((unsigned char)s[i]);
    p[n] = '\0';
    return p;
}
static bool contains_ci(const char *hay, const char *needle) {
    char *a = toupper_dup(hay ? hay : "");
    char *b = toupper_dup(needle ? needle : "");
    bool ok = strstr(a, b) != NULL;
    free(a); free(b);
    return ok;
}
static bool mostly_upper(const char *s) {
    int alpha = 0, up = 0;
    for (; *s; s++) if (isalpha((unsigned char)*s)) { alpha++; if (isupper((unsigned char)*s)) up++; }
    return alpha > 0 && up * 2 >= alpha;
}
static char *replace_all(const char *src, const char *needle, const char *repl) {
    if (!src) return xstrdup("");
    if (!needle || !*needle) return xstrdup(src);
    size_t src_len = strlen(src), nlen = strlen(needle), rlen = strlen(repl);
    size_t count = 0;
    const char *p = src;
    while ((p = strstr(p, needle))) { count++; p += nlen; }
    char *out = malloc(src_len + count * (rlen - nlen) + 1);
    if (!out) { perror("malloc"); exit(1); }
    char *d = out;
    p = src;
    const char *h;
    while ((h = strstr(p, needle))) {
        size_t n = (size_t)(h - p);
        memcpy(d, p, n); d += n;
        memcpy(d, repl, rlen); d += rlen;
        p = h + nlen;
    }
    strcpy(d, p);
    return out;
}
static char *shell_quote(const char *s) {
    StrBuf b; sb_init(&b);
    sb_append(&b, "'");
    for (const char *p = s; p && *p; p++) {
        if (*p == '\'') sb_append(&b, "'\\''");
        else sb_append_n(&b, p, 1);
    }
    sb_append(&b, "'");
    return b.buf;
}
static uint64_t hash_bytes(const unsigned char *buf, size_t len) {
    uint64_t h = 1469598103934665603ULL;
    for (size_t i = 0; i < len; i++) { h ^= buf[i]; h *= 1099511628211ULL; }
    return h;
}
static uint64_t hash_str(const char *s) {
    return hash_bytes((const unsigned char *)(s ? s : ""), strlen(s ? s : ""));
}

/* ---------- fs helpers ---------- */

static bool ensure_parent_dirs(const char *path) {
    char tmp[PATH_MAX];
    snprintf(tmp, sizeof(tmp), "%s", path);
    for (char *p = tmp + 1; *p; p++) {
        if (*p == '/') {
            *p = '\0';
            if (mkdir(tmp, 0755) != 0 && errno != EEXIST) return false;
            *p = '/';
        }
    }
    return true;
}
static bool ensure_dir(const char *path) {
    struct stat st;
    if (stat(path, &st) == 0) return S_ISDIR(st.st_mode);
    return mkdir(path, 0755) == 0;
}
static int write_file(const char *path, const char *data) {
    if (!ensure_parent_dirs(path)) return -1;
    FILE *f = fopen(path, "wb");
    if (!f) return -1;
    size_t n = data ? strlen(data) : 0;
    if (n && fwrite(data, 1, n, f) != n) { fclose(f); return -1; }
    fclose(f);
    return 0;
}
static char *read_file(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    rewind(f);
    if (sz < 0) { fclose(f); return NULL; }
    char *buf = malloc((size_t)sz + 1);
    if (!buf) { fclose(f); return NULL; }
    size_t got = fread(buf, 1, (size_t)sz, f);
    fclose(f);
    buf[got] = '\0';
    return buf;
}

/* ---------- extraction ---------- */

static char *extract_text(const char *path, const char *tmpdir, char **kind_out) {
    const char *ext = strrchr(path, '.');
    if (ext && (strcasecmp(ext, ".txt") == 0 || strcasecmp(ext, ".md") == 0 || strcasecmp(ext, ".text") == 0)) {
        if (kind_out) *kind_out = xstrdup("text");
        return read_file(path);
    }
    if (ext && strcasecmp(ext, ".pdf") == 0) {
        if (kind_out) *kind_out = xstrdup("pdf");
        char outpath[PATH_MAX];
        snprintf(outpath, sizeof(outpath), "%s/extract_%ld.txt", tmpdir, (long)getpid());
        char *qin = shell_quote(path);
        char *qout = shell_quote(outpath);
        StrBuf cmd; sb_init(&cmd);
        sb_appendf(&cmd, "pdftotext -layout -nopgbrk %s %s >/dev/null 2>&1", qin, qout);
        int rc = system(cmd.buf);
        free(qin); free(qout); free(cmd.buf);
        if (rc != 0) return NULL;
        char *txt = read_file(outpath);
        unlink(outpath);
        return txt;
    }
    if (kind_out) *kind_out = xstrdup("text");
    return read_file(path);
}

/* ---------- pack / chunking ---------- */

static bool looks_like_heading(const char *line) {
    char *t = dup_trim(line);
    if (!t || !*t) { free(t); return false; }
    size_t n = strlen(t);
    if (n > 140) { free(t); return false; }
    bool key = contains_ci(t, "CHAPTER") || contains_ci(t, "ARTICLE") || contains_ci(t, "SECTION") || contains_ci(t, "CODE OF IOWA") || contains_ci(t, "TITLE ") || contains_ci(t, "VOLUME ");
    bool num = isdigit((unsigned char)t[0]) || strncmp(t, "§", 2) == 0 || strncmp(t, "Sec.", 4) == 0 || strncmp(t, "SEC.", 4) == 0;
    bool up = mostly_upper(t) && n < 90 && !strchr(t, '.');
    free(t);
    return key || num || up;
}
static void vec_push(SectionVec *v, Section s) {
    if (v->len == v->cap) {
        size_t nc = v->cap ? v->cap * 2 : 64;
        Section *p = realloc(v->items, nc * sizeof(*p));
        if (!p) { perror("realloc"); exit(1); }
        v->items = p; v->cap = nc;
    }
    v->items[v->len++] = s;
}
static void split_chunks(const char *text, SectionVec *out, size_t max_chars) {
    char *copy = xstrdup(text ? text : "");
    char *save = NULL;
    char *line = strtok_r(copy, "\n", &save);
    char *title = xstrdup("(pack)");
    StrBuf buf; sb_init(&buf);
    size_t part = 1;
    while (line) {
        char *t = dup_trim(line);
        bool heading = looks_like_heading(t);
        if (heading && buf.len > 0) {
            vec_push(out, (Section){ .title = title, .text = buf.buf });
            title = xstrdup(t);
            sb_init(&buf);
            part = 1;
        } else {
            sb_append(&buf, line);
            sb_append(&buf, "\n");
            if (buf.len >= max_chars) {
                char tmp[512];
                snprintf(tmp, sizeof(tmp), "%s%s", title, part == 1 ? "" : " (cont.)");
                vec_push(out, (Section){ .title = xstrdup(tmp), .text = buf.buf });
                sb_init(&buf);
                part++;
            }
        }
        free(t);
        line = strtok_r(NULL, "\n", &save);
    }
    if (buf.len > 0) {
        char tmp[512];
        snprintf(tmp, sizeof(tmp), "%s%s", title, part == 1 ? "" : " (cont.)");
        vec_push(out, (Section){ .title = xstrdup(tmp), .text = buf.buf });
    } else {
        free(buf.buf);
    }
    free(title);
    free(copy);
    if (out->len == 0) vec_push(out, (Section){ .title = xstrdup("(pack)"), .text = xstrdup("") });
}
static void pack_free(Pack *p) {
    if (!p) return;
    free(p->path); free(p->kind); free(p->hash); free(p->full_text);
    for (size_t i = 0; i < p->chunks.len; i++) { free(p->chunks.items[i].title); free(p->chunks.items[i].text); }
    free(p->chunks.items);
    memset(p, 0, sizeof(*p));
}

static char *cache_path_for(const char *cache_dir, const char *source_path, const char *hash) {
    const char *b = strrchr(source_path, '/');
    b = b ? b + 1 : source_path;
    StrBuf s; sb_init(&s);
    sb_appendf(&s, "%s/%s-%s.qcp", cache_dir, b, hash);
    return s.buf;
}

static bool read_line(FILE *f, char *buf, size_t cap) {
    if (!fgets(buf, (int)cap, f)) return false;
    size_t n = strlen(buf);
    while (n && (buf[n-1] == '\n' || buf[n-1] == '\r')) buf[--n] = '\0';
    return true;
}
static char *read_bytes(FILE *f, size_t n) {
    char *buf = malloc(n + 1);
    if (!buf) return NULL;
    if (fread(buf, 1, n, f) != n) { free(buf); return NULL; }
    buf[n] = '\0';
    return buf;
}

static bool save_pack_cache(const char *path, const Pack *p) {
    if (!ensure_parent_dirs(path)) return false;
    FILE *f = fopen(path, "wb");
    if (!f) return false;
    fprintf(f, "QCP1\n");
    fprintf(f, "PATHLEN %zu\n", strlen(p->path));
    fwrite(p->path, 1, strlen(p->path), f); fputc('\n', f);
    fprintf(f, "KIND %s\n", p->kind);
    fprintf(f, "HASH %s\n", p->hash);
    fprintf(f, "FULLLEN %zu\n", strlen(p->full_text ? p->full_text : ""));
    fwrite(p->full_text ? p->full_text : "", 1, strlen(p->full_text ? p->full_text : ""), f); fputc('\n', f);
    fprintf(f, "CHUNKS %zu\n", p->chunks.len);
    for (size_t i = 0; i < p->chunks.len; i++) {
        Section *s = &p->chunks.items[i];
        fprintf(f, "SECTION\nTITLELEN %zu\n", strlen(s->title));
        fwrite(s->title, 1, strlen(s->title), f); fputc('\n', f);
        fprintf(f, "TEXTLEN %zu\n", strlen(s->text));
        fwrite(s->text, 1, strlen(s->text), f); fputc('\n', f);
    }
    fclose(f);
    return true;
}

static bool load_pack_cache(const char *path, Pack *p) {
    FILE *f = fopen(path, "rb");
    if (!f) return false;
    char line[256];
    if (!read_line(f, line, sizeof(line)) || strcmp(line, "QCP1") != 0) { fclose(f); return false; }

    size_t pathlen = 0, full_len = 0, chunk_count = 0;
    char kind[64] = {0}, hash[128] = {0};

    if (!read_line(f, line, sizeof(line)) || sscanf(line, "PATHLEN %zu", &pathlen) != 1) { fclose(f); return false; }
    char *pathstr = read_bytes(f, pathlen); if (!pathstr) { fclose(f); return false; } fgetc(f);
    if (!read_line(f, line, sizeof(line)) || sscanf(line, "KIND %63s", kind) != 1) { free(pathstr); fclose(f); return false; }
    if (!read_line(f, line, sizeof(line)) || sscanf(line, "HASH %127s", hash) != 1) { free(pathstr); fclose(f); return false; }
    if (!read_line(f, line, sizeof(line)) || sscanf(line, "FULLLEN %zu", &full_len) != 1) { free(pathstr); fclose(f); return false; }
    char *full = read_bytes(f, full_len); if (!full) { free(pathstr); fclose(f); return false; } fgetc(f);
    if (!read_line(f, line, sizeof(line)) || sscanf(line, "CHUNKS %zu", &chunk_count) != 1) { free(pathstr); free(full); fclose(f); return false; }

    Pack tmp = {0};
    tmp.path = pathstr;
    tmp.kind = xstrdup(kind);
    tmp.hash = xstrdup(hash);
    tmp.full_text = full;

    for (size_t i = 0; i < chunk_count; i++) {
        if (!read_line(f, line, sizeof(line)) || strcmp(line, "SECTION") != 0) { pack_free(&tmp); fclose(f); return false; }
        size_t tl = 0, xl = 0;
        if (!read_line(f, line, sizeof(line)) || sscanf(line, "TITLELEN %zu", &tl) != 1) { pack_free(&tmp); fclose(f); return false; }
        char *title = read_bytes(f, tl); if (!title) { pack_free(&tmp); fclose(f); return false; } fgetc(f);
        if (!read_line(f, line, sizeof(line)) || sscanf(line, "TEXTLEN %zu", &xl) != 1) { free(title); pack_free(&tmp); fclose(f); return false; }
        char *text = read_bytes(f, xl); if (!text) { free(title); pack_free(&tmp); fclose(f); return false; } fgetc(f);
        vec_push(&tmp.chunks, (Section){ .title = title, .text = text });
    }

    fclose(f);
    *p = tmp;
    return true;
}

static bool build_pack(const char *source_path, const char *cache_dir, size_t max_chars, Pack *out, bool rebuild) {
    char *kind = NULL;
    char *text = extract_text(source_path, cache_dir, &kind);
    if (!text) return false;

    uint64_t h = hash_bytes((const unsigned char *)text, strlen(text));
    char hash[32];
    snprintf(hash, sizeof(hash), "%016llx", (unsigned long long)h);
    char *cache = cache_path_for(cache_dir, source_path, hash);

    if (!rebuild && load_pack_cache(cache, out)) {
        free(cache); free(kind); free(text);
        return true;
    }

    Pack p = {0};
    p.path = xstrdup(source_path);
    p.kind = kind ? kind : xstrdup("text");
    p.hash = xstrdup(hash);
    p.full_text = xstrdup(text);
    split_chunks(text, &p.chunks, max_chars);
    save_pack_cache(cache, &p);

    free(cache); free(kind); free(text);
    *out = p;
    return true;
}

/* ---------- scoring ---------- */

static int score_text(const char *query, const char *text) {
    char *a = toupper_dup(query ? query : "");
    char *b = toupper_dup(text ? text : "");
    int score = 0;
    char *save = NULL;
    for (char *tok = strtok_r(a, " \t\r\n,.;:()[]{}<>|/\\\"'`!?", &save); tok; tok = strtok_r(NULL, " \t\r\n,.;:()[]{}<>|/\\\"'`!?", &save)) {
        if (strlen(tok) < 3) continue;
        if (strstr(b, tok)) score++;
    }
    free(a); free(b);
    return score;
}
static void append_top_sections(StrBuf *p, const Pack *pack, const char *query, int topk, const char *label) {
    if (!pack || pack->chunks.len == 0) return;
    size_t n = pack->chunks.len;
    int *score = calloc(n, sizeof(int));
    size_t *ord = calloc(n, sizeof(size_t));
    if (!score || !ord) { perror("calloc"); exit(1); }
    for (size_t i = 0; i < n; i++) {
        ord[i] = i;
        score[i] = score_text(query, pack->chunks.items[i].title) * 2 + score_text(query, pack->chunks.items[i].text);
    }
    for (size_t i = 0; i < n; i++) for (size_t j = i + 1; j < n; j++) if (score[j] > score[i]) {
        int ts = score[i]; score[i] = score[j]; score[j] = ts;
        size_t to = ord[i]; ord[i] = ord[j]; ord[j] = to;
    }
    sb_appendf(p, "\n====================\n%s\nSOURCE: %s\nHASH: %s\n--------------------\n", label, pack->path, pack->hash);
    for (int i = 0; i < topk && (size_t)i < n; i++) {
        Section *s = &pack->chunks.items[ord[i]];
        sb_appendf(p, "\n[CHUNK] %s\n", s->title);
        sb_append(p, s->text);
        sb_append(p, "\n");
    }
    free(score); free(ord);
}

/* ---------- runner ---------- */

static char *build_prompt(const Pack *input, const Pack *refs, size_t nrefs, const char *question, size_t topk) {
    StrBuf p; sb_init(&p);
    sb_append(&p,
        "You are QCAv13-7, an offline constitutional review engine.\n"
        "TASK OBJECTIVE:\n"
        "Use the cached document packs to answer the question about whether the Iowa Code may conflict with the Bill of Rights.\n"
        "The Bill of Rights is the controlling authority; the Iowa Code is subordinate.\n"
        "Look for both direct and subtle burdens: permits, fees, compelled speech, disclosures, searches, seizures, discretion, vagueness, penalties, and chilling effects.\n"
        "Do not state a legal violation as fact; identify possible constitutional issues and explain the reasoning.\n"
        "Return concise JSON only with keys: question, answer, possible_amendments, evidence, confidence.\n");

    append_top_sections(&p, input, question, (int)topk, "INPUT PACK");
    for (size_t r = 0; r < nrefs; r++) {
        char label[256];
        snprintf(label, sizeof(label), "REFERENCE %zu", r + 1);
        append_top_sections(&p, &refs[r], question, (int)(topk / 2 + 1), label);
    }
    sb_append(&p, "\nQUESTION:\n");
    sb_append(&p, question ? question : "");
    sb_append(&p, "\n");
    return p.buf;
}



static char *build_analysis_prompt(const Pack *input, const Pack *refs, size_t nrefs, const Section *chunk, size_t topk) {
    StrBuf p; sb_init(&p);
    sb_append(&p,
        "You are QCAv13-7, an offline constitutional review engine.\n"
        "TASK OBJECTIVE:\n"
        "Analyze the current Iowa Code chunk against the Bill of Rights and identify possible constitutional issues, including subtle burdens.\n"
        "The Bill of Rights is the controlling authority; the Iowa Code is subordinate.\n"
        "Look for permits, fees, compelled speech, disclosures, searches, seizures, discretion, vagueness, penalties, and chilling effects.\n"
        "Do not state a legal violation as fact; identify possible constitutional issues and explain the reasoning.\n"
        "Return concise JSON only with keys: section_title, answer, possible_amendments, evidence, confidence.\n");

    sb_append(&p, "\nCURRENT INPUT PACK (for retrieval):\n");
    append_top_sections(&p, input, chunk ? chunk->text : "", (int)topk, "INPUT PACK");
    for (size_t r = 0; r < nrefs; r++) {
        char label[256];
        snprintf(label, sizeof(label), "REFERENCE %zu", r + 1);
        append_top_sections(&p, &refs[r], chunk ? chunk->text : "", (int)(topk / 2 + 1), label);
    }
    sb_append(&p, "\nCURRENT CHUNK TITLE:\n");
    sb_append(&p, chunk && chunk->title ? chunk->title : "(untitled chunk)");
    sb_append(&p, "\n\nCURRENT CHUNK TEXT:\n");
    sb_append(&p, chunk && chunk->text ? chunk->text : "");
    sb_append(&p, "\n");
    return p.buf;
}
static char *runner_cmd(const char *tmpl, const char *prompt_file, const char *prompt_text, size_t ctx_size, size_t max_tokens) {
    char ctx[32], tok[32];
    snprintf(ctx, sizeof(ctx), "%zu", ctx_size);
    snprintf(tok, sizeof(tok), "%zu", max_tokens);
    char *qf = shell_quote(prompt_file);
    char *qp = shell_quote(prompt_text ? prompt_text : "");
    char *a = replace_all(tmpl, "{PROMPT_FILE}", qf);
    char *b = replace_all(a, "{PROMPT}", qp);
    char *c = replace_all(b, "{CTX_SIZE}", ctx);
    char *d = replace_all(c, "{MAX_TOKENS}", tok);
    free(qf); free(qp); free(a); free(b); free(c);
    StrBuf out; sb_init(&out);
    sb_append(&out, d);
    if (!strstr(d, "-n ") && !strstr(d, "--n-predict ")) sb_appendf(&out, " -n %zu", max_tokens);
    if (!strstr(d, "--simple-io")) sb_append(&out, " --simple-io");
    if (!strstr(d, "--no-display-prompt")) sb_append(&out, " --no-display-prompt");
    if (!strstr(d, "--skip-chat-parsing")) sb_append(&out, " --skip-chat-parsing");
    if (!strstr(d, "--single-turn")) sb_append(&out, " --single-turn");
    free(d);
    return out.buf;
}

static char *run_capture(const char *cmd) {
    StrBuf out; sb_init(&out);
    char *full = malloc(strlen(cmd) + 8);
    if (!full) { perror("malloc"); exit(1); }
    sprintf(full, "%s 2>&1", cmd);
    FILE *fp = popen(full, "r");
    free(full);
    if (!fp) return NULL;
    char buf[4096];
    while (fgets(buf, sizeof(buf), fp)) sb_append(&out, buf);
    pclose(fp);
    return out.buf;
}

static char *extract_json_text(const char *out, size_t limit) {
    if (!out) return xstrdup("");
    const char *keys[] = {"\"answer\"", "\"summary\"", "\"section_summary\""};
    for (size_t k = 0; k < 3; k++) {
        const char *p = strstr(out, keys[k]);
        if (p) {
            const char *colon = strchr(p, ':');
            if (colon) {
                const char *s = colon + 1;
                while (*s && isspace((unsigned char)*s)) s++;
                if (*s == '"') {
                    s++;
                    StrBuf b; sb_init(&b);
                    for (; *s && b.len < limit; s++) {
                        if (*s == '\\' && s[1]) { s++; sb_append_n(&b, s, 1); }
                        else if (*s == '"') break;
                        else sb_append_n(&b, s, 1);
                    }
                    return b.buf ? b.buf : xstrdup("");
                }
            }
        }
    }
    StrBuf b; sb_init(&b);
    const char *s = out;
    while (*s && isspace((unsigned char)*s)) s++;
    for (; *s && b.len < limit; s++) sb_append_n(&b, s, 1);
    return b.buf ? b.buf : xstrdup("");
}

/* ---------- output ---------- */

static void csv_escape(FILE *f, const char *s) {
    fputc('"', f);
    for (; s && *s; s++) {
        if (*s == '"') fputc('"', f);
        fputc(*s, f);
    }
    fputc('"', f);
}

static void usage(void) {
    fprintf(stderr,
        "QCAv13-7 offline constitutional review engine\n"
        "\n"
        "Usage:\n"
        "  %s --input FILE --reference FILE [--reference FILE ...] --outdir DIR [options]\n"
        "  %s --input FILE --reference FILE [--reference FILE ...] --questions FILE --outdir DIR [options]\n"
        "\n"
        "Modes:\n"
        "  Analysis mode (default when --questions is omitted)\n"
        "    - Splits the input document into chunks\n"
        "    - Builds a cached pack for the input and each reference\n"
        "    - Asks Qwen to analyze each chunk against the controlling reference pack\n"
        "\n"
        "  Question mode (enabled when --questions FILE is provided)\n"
        "    - Loads one question per line from the file\n"
        "    - Answers each question using the cached packs\n"
        "    - Use --batch to send all questions in one model call\n"
        "\n"
        "Core options:\n"
        "  --runner-template CMD   llama.cpp template using {PROMPT}, {PROMPT_FILE}, {CTX_SIZE}, and {MAX_TOKENS}\n"
        "  --profile low|medium|high|ultra\n"
        "  --ctx-size N            Override context size\n"
        "  --max-tokens N          Override generation cap\n"
        "  --topk N                Number of top chunks to inject into the prompt\n"
        "  --workers N|auto        Worker count (currently auto-tuned in question mode)\n"
        "  --reindex               Rebuild cached packs even if they already exist\n"
        "  --resume                Resume from the last unfinished question/chunk\n"
        "  --reset                 Ignore checkpoint state and start over\n"
        "  --show-prompt           Print the generated prompt before calling llama.cpp\n"
        "  --batch                 Question mode only: ask all questions in one model call\n"
        "  --list-profiles         Print profiles and exit\n"
        "  --help                  Show this full help text and exit\n"
        "\n"
        "Reference handling:\n"
        "  - Both PDF and text input are accepted for --input and --reference.\n"
        "  - Each source is extracted once and cached under .qca_cache/.\n"
        "  - If the same document is used again, the cached pack is reused.\n"
        "\n"
        "Analysis behavior when --questions is omitted:\n"
        "  - Each input chunk becomes one analysis target.\n"
        "  - The Bill of Rights remains the controlling authority.\n"
        "  - The Iowa Code remains subordinate text.\n"
        "  - The output is written incrementally to report.md, index.csv, and index.json.\n"
        "\n"
        "Examples:\n"
        "  %s --profile ultra --input iowa.pdf --reference bill.pdf --outdir out \\\n"
        "     --runner-template 'llama-cli -m model.gguf --jinja --reasoning on --reasoning-budget -1 -c {CTX_SIZE} -p {PROMPT}'\n"
        "\n"
        "  %s --profile ultra --input iowa.pdf --reference bill.pdf --questions questions.txt --outdir out \\\n"
        "     --runner-template 'llama-cli -m model.gguf --jinja --reasoning on --reasoning-budget -1 -c {CTX_SIZE} -p {PROMPT}'\n",
        APP, APP, APP, APP, APP);
}

static void list_profiles(void) {

    puts("low     ctx=1024 tokens=192  max_chunk=1400 topk=6");
    puts("medium  ctx=2048 tokens=256  max_chunk=2200 topk=8");
    puts("high    ctx=4096 tokens=384  max_chunk=3200 topk=10");
    puts("ultra   ctx=8192 tokens=512  max_chunk=5000 topk=12");
}

static int parse_workers(const char *s, int auto_v) {
    if (!s || strcmp(s, "auto") == 0) return auto_v;
    return (int)strtol(s, NULL, 10);
}

static void save_checkpoint(const char *state_dir, size_t next_q, const char *hash) {
    char p[PATH_MAX], tmp[64];
    snprintf(p, sizeof(p), "%s/next_question.txt", state_dir);
    snprintf(tmp, sizeof(tmp), "%zu", next_q);
    write_file(p, tmp);
    snprintf(p, sizeof(p), "%s/input_hash.txt", state_dir);
    write_file(p, hash ? hash : "");
}

static bool read_questions(const char *path, char ***questions_out, size_t *nq_out) {
    char *txt = read_file(path);
    if (!txt) return false;
    char *copy = xstrdup(txt);
    free(txt);
    char *save = NULL;
    char **qs = NULL;
    size_t n = 0, cap = 0;
    for (char *line = strtok_r(copy, "\n", &save); line; line = strtok_r(NULL, "\n", &save)) {
        char *t = dup_trim(line);
        if (!t || !*t) { free(t); continue; }
        if (n == cap) {
            size_t nc = cap ? cap * 2 : 16;
            char **p = realloc(qs, nc * sizeof(*p));
            if (!p) { perror("realloc"); free(copy); return false; }
            qs = p; cap = nc;
        }
        qs[n++] = t;
    }
    free(copy);
    *questions_out = qs;
    *nq_out = n;
    return n > 0;
}

static void append_report(FILE *md, FILE *csv, FILE *js, size_t *count, const char *question, const char *raw_path, const char *answer) {
    fprintf(md, "## Question %zu\n\n%s\n\n### Answer\n\n```text\n%s\n```\n\n", *count + 1, question ? question : "", answer ? answer : "");
    fprintf(csv, "%zu,", *count + 1);
    csv_escape(csv, question ? question : "");
    fputc(',', csv);
    csv_escape(csv, raw_path ? raw_path : "");
    fputc(',', csv);
    csv_escape(csv, answer ? answer : "");
    fputc('\n', csv);

    if (*count > 0) fputs(",\n", js);
    fputs("    {\n", js);
    fprintf(js, "      \"index\": %zu,\n", *count + 1);
    fputs("      \"question\": ", js); csv_escape(js, question ? question : ""); fputs(",\n", js);
    fputs("      \"raw_output_file\": ", js); csv_escape(js, raw_path ? raw_path : ""); fputs(",\n", js);
    fputs("      \"answer\": ", js); csv_escape(js, answer ? answer : ""); fputc('\n', js);
    fputs("    }", js);
    fflush(md); fflush(csv); fflush(js);
    (*count)++;
}

/* ---------- main ---------- */

int main(int argc, char **argv) {
    const char *input = NULL, *outdir = NULL, *questions_file = NULL, *runner_template = NULL;
    bool batch = false, resume = true, reset = false, reindex = false, show_prompt = false, list_profiles_flag = false, help_flag = false;
    Profile profile = PROF_LOW;
    size_t ctx_size = 0, max_tokens = 0, max_chunk = 0, topk = 0;
    int workers_opt = -1;

    char **refs_in = NULL;
    size_t nrefs_in = 0, refs_cap = 0;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--input") == 0 && i + 1 < argc) input = argv[++i];
        else if (strcmp(argv[i], "--reference") == 0 && i + 1 < argc) {
            if (nrefs_in == refs_cap) {
                size_t nc = refs_cap ? refs_cap * 2 : 8;
                char **p = realloc(refs_in, nc * sizeof(*p));
                if (!p) { perror("realloc"); return 1; }
                refs_in = p; refs_cap = nc;
            }
            refs_in[nrefs_in++] = argv[++i];
        } else if (strcmp(argv[i], "--questions") == 0 && i + 1 < argc) questions_file = argv[++i];
        else if (strcmp(argv[i], "--outdir") == 0 && i + 1 < argc) outdir = argv[++i];
        else if (strcmp(argv[i], "--runner-template") == 0 && i + 1 < argc) runner_template = argv[++i];
        else if (strcmp(argv[i], "--profile") == 0 && i + 1 < argc) {
            const char *p = argv[++i];
            if (strcmp(p, "low") == 0) profile = PROF_LOW;
            else if (strcmp(p, "medium") == 0) profile = PROF_MEDIUM;
            else if (strcmp(p, "high") == 0) profile = PROF_HIGH;
            else if (strcmp(p, "ultra") == 0) profile = PROF_ULTRA;
            else { fprintf(stderr, "%s: unknown profile %s\n", APP, p); return 1; }
        } else if (strcmp(argv[i], "--ctx-size") == 0 && i + 1 < argc) ctx_size = (size_t)strtoul(argv[++i], NULL, 10);
        else if (strcmp(argv[i], "--max-tokens") == 0 && i + 1 < argc) max_tokens = (size_t)strtoul(argv[++i], NULL, 10);
        else if (strcmp(argv[i], "--topk") == 0 && i + 1 < argc) topk = (size_t)strtoul(argv[++i], NULL, 10);
        else if (strcmp(argv[i], "--workers") == 0 && i + 1 < argc) workers_opt = parse_workers(argv[++i], -1);
        else if (strcmp(argv[i], "--batch") == 0) batch = true;
        else if (strcmp(argv[i], "--resume") == 0) resume = true;
        else if (strcmp(argv[i], "--reset") == 0) reset = true;
        else if (strcmp(argv[i], "--reindex") == 0) reindex = true;
        else if (strcmp(argv[i], "--show-prompt") == 0) show_prompt = true;
        else if (strcmp(argv[i], "--list-profiles") == 0) list_profiles_flag = true;
        else if (strcmp(argv[i], "--help") == 0 || strcmp(argv[i], "-h") == 0) help_flag = true;
        else { usage(); return 1; }
    }

    if (help_flag) { usage(); return 0; }
    if (list_profiles_flag) { list_profiles(); return 0; }
    if (!input || !outdir || !runner_template || nrefs_in == 0) { usage(); return 1; }

    switch (profile) {
        case PROF_LOW: ctx_size = ctx_size ? ctx_size : 1024; max_tokens = max_tokens ? max_tokens : 192; max_chunk = 1400; topk = topk ? topk : 6; break;
        case PROF_MEDIUM: ctx_size = ctx_size ? ctx_size : 2048; max_tokens = max_tokens ? max_tokens : 256; max_chunk = 2200; topk = topk ? topk : 8; break;
        case PROF_HIGH: ctx_size = ctx_size ? ctx_size : 4096; max_tokens = max_tokens ? max_tokens : 384; max_chunk = 3200; topk = topk ? topk : 10; break;
        case PROF_ULTRA: ctx_size = ctx_size ? ctx_size : 8192; max_tokens = max_tokens ? max_tokens : 512; max_chunk = 5000; topk = topk ? topk : 12; break;
    }
    if (ctx_size == 0) ctx_size = 1024;
    if (max_tokens == 0) max_tokens = 192;
    if (max_chunk == 0) max_chunk = 1400;
    if (topk == 0) topk = 6;

    int auto_workers = 1;
    if (workers_opt < 0) {
        long mem = 0;
        struct sysinfo si;
        if (sysinfo(&si) == 0) mem = (long)((unsigned long long)si.totalram * si.mem_unit / (1024ULL * 1024ULL));
        int cpus = (int)sysconf(_SC_NPROCESSORS_ONLN);
        if (cpus < 1) cpus = 1;
        auto_workers = cpus > 1 ? cpus - 1 : 1;
        if (mem > 0 && mem < 6144) auto_workers = 1;
        else if (mem < 12288 && auto_workers > 2) auto_workers = 2;
        if (ctx_size >= 8192 || max_tokens >= 512) auto_workers = auto_workers > 2 ? 2 : auto_workers;
    } else {
        auto_workers = workers_opt;
    }
    if (auto_workers < 1) auto_workers = 1;

    if (!ensure_dir(outdir)) { fprintf(stderr, "%s: cannot create outdir %s\n", APP, outdir); return 1; }

    char workdir[PATH_MAX], cache_dir[PATH_MAX], state_dir[PATH_MAX];
    snprintf(workdir, sizeof(workdir), "%s/work", outdir);
    snprintf(cache_dir, sizeof(cache_dir), "%s/.qca_cache", outdir);
    snprintf(state_dir, sizeof(state_dir), "%s/.qca_state", outdir);
    if (!ensure_dir(workdir) || !ensure_dir(cache_dir) || !ensure_dir(state_dir)) {
        fprintf(stderr, "%s: cannot create subdirs in %s\n", APP, outdir); return 1;
    }

    Pack input_pack = {0};
    if (!build_pack(input, cache_dir, max_chunk, &input_pack, reindex)) {
        fprintf(stderr, "%s: failed to build input pack\n", APP); return 1;
    }
    Pack *refs = calloc(nrefs_in, sizeof(Pack));
    if (!refs) { perror("calloc"); return 1; }
    for (size_t i = 0; i < nrefs_in; i++) {
        if (!build_pack(refs_in[i], cache_dir, max_chunk, &refs[i], reindex)) {
            fprintf(stderr, "%s: failed to build reference pack %s\n", APP, refs_in[i]); return 1;
        }
    }


    bool analysis_mode = (questions_file == NULL);

    char report_md[PATH_MAX], report_csv[PATH_MAX], report_json[PATH_MAX];
    snprintf(report_md, sizeof(report_md), "%s/report.md", outdir);
    snprintf(report_csv, sizeof(report_csv), "%s/index.csv", outdir);
    snprintf(report_json, sizeof(report_json), "%s/index.json", outdir);

    char state_hash_path[PATH_MAX], state_next_path[PATH_MAX], state_summary_path[PATH_MAX];
    snprintf(state_hash_path, sizeof(state_hash_path), "%s/input_hash.txt", state_dir);
    snprintf(state_next_path, sizeof(state_next_path), "%s/next_question.txt", state_dir);
    snprintf(state_summary_path, sizeof(state_summary_path), "%s/rolling_summary.txt", state_dir);

    char input_hash_hex[64];
    snprintf(input_hash_hex, sizeof(input_hash_hex), "%016llx", (unsigned long long)hash_str(input_pack.hash ? input_pack.hash : ""));

    size_t start_item = 1;
    if (resume && !reset) {
        char *oldh = read_file(state_hash_path);
        if (oldh) {
            trim_inplace(oldh);
            if (strcmp(oldh, input_hash_hex) == 0) {
                char *n = read_file(state_next_path);
                if (n) {
                    trim_inplace(n);
                    size_t v = (size_t)strtoull(n, NULL, 10);
                    if (v > 0) start_item = v;
                    free(n);
                }
            }
            free(oldh);
        }
    }
    if (!resume || reset) {
        write_file(state_hash_path, input_hash_hex);
        write_file(state_next_path, "1");
        write_file(state_summary_path, "");
    }

    char *rolling = read_file(state_summary_path);
    if (!rolling) rolling = xstrdup("");

    FILE *md = fopen(report_md, (resume && !reset && start_item > 1) ? "ab" : "wb");
    FILE *csv = fopen(report_csv, (resume && !reset && start_item > 1) ? "ab" : "wb");
    FILE *js = fopen(report_json, (resume && !reset && start_item > 1) ? "ab" : "wb");
    if (!md || !csv || !js) { perror("open report"); return 1; }

    if (!(resume && !reset && start_item > 1)) {
        fprintf(md, "# QCAv13-7 Report\n\n- Input: `%s`\n- References: %zu\n- Profile: %s\n- Workers: %d\n- Mode: %s\n\n",
                input, nrefs_in,
                profile == PROF_ULTRA ? "ultra" : profile == PROF_HIGH ? "high" : profile == PROF_MEDIUM ? "medium" : "low",
                auto_workers, analysis_mode ? "analysis" : (batch ? "batch" : "question"));
        fputs("question_index,question,raw_output_file,answer\n", csv);
        fputs("{\n  \"answers\": [\n", js);
        fflush(md); fflush(csv); fflush(js);
    }

    size_t count = 0;

    char **questions = NULL;
    size_t nq = 0;
    if (!analysis_mode) {
        char *questions_txt = read_file(questions_file);
        if (!questions_txt) { fprintf(stderr, "%s: could not read questions file\n", APP); return 1; }
        char *qcopy = xstrdup(questions_txt);
        free(questions_txt);
        char *saveq = NULL;
        size_t qcap = 0;
        for (char *line = strtok_r(qcopy, "\n", &saveq); line; line = strtok_r(NULL, "\n", &saveq)) {
            char *t = dup_trim(line);
            if (!t || !*t) { free(t); continue; }
            if (nq == qcap) {
                size_t nc = qcap ? qcap * 2 : 16;
                char **p = realloc(questions, nc * sizeof(*p));
                if (!p) { perror("realloc"); return 1; }
                questions = p; qcap = nc;
            }
            questions[nq++] = t;
        }
        free(qcopy);
        if (nq == 0) { fprintf(stderr, "%s: no questions found\n", APP); return 1; }
    }

    if (analysis_mode) {
        size_t target_count = input_pack.chunks.len;
        if (start_item > target_count) start_item = target_count + 1;

        for (size_t i = start_item - 1; i < target_count; i++) {
            const Section *chunk = &input_pack.chunks.items[i];
            char *prompt_text = build_analysis_prompt(&input_pack, refs, nrefs_in, chunk, topk);

            char prompt_path[PATH_MAX], raw_path[PATH_MAX];
            snprintf(prompt_path, sizeof(prompt_path), "%s/analysis_%04zu.prompt.txt", workdir, i + 1);
            snprintf(raw_path, sizeof(raw_path), "%s/analysis_%04zu.raw.txt", workdir, i + 1);
            write_file(prompt_path, prompt_text);

            char *cmd = runner_cmd(runner_template, prompt_path, prompt_text, ctx_size, max_tokens);
            if (show_prompt) printf("\n===== PROMPT %zu =====\n%s\n=====================\n", i + 1, prompt_text);
            printf("[%zu/%zu] %s\n", i + 1, target_count, chunk->title ? chunk->title : "(analysis chunk)");
            fflush(stdout);

            char *raw = run_capture(cmd);
            if (!raw) { fprintf(stderr, "%s: runner failed\n", APP); return 1; }
            write_file(raw_path, raw);

            char *answer = extract_json_text(raw, 9000);
            append_report(md, csv, js, &count, chunk->title ? chunk->title : "(analysis chunk)", raw_path, answer);

            free(rolling);
            rolling = xstrdup(raw);
            write_file(state_summary_path, rolling);
            char nextbuf[64];
            snprintf(nextbuf, sizeof(nextbuf), "%zu", i + 2);
            write_file(state_next_path, nextbuf);
            write_file(state_hash_path, input_hash_hex);

            free(prompt_text);
            free(cmd);
            free(raw);
            free(answer);
        }
    } else if (batch) {
        StrBuf prompt; sb_init(&prompt);
        sb_append(&prompt,
            "You are QCAv13-7, an offline constitutional review engine.\n"
            "TASK OBJECTIVE:\n"
            "Use the cached document packs to answer all user questions about whether the Iowa Code may conflict with the Bill of Rights.\n"
            "The Bill of Rights is controlling authority; the Iowa Code is subordinate.\n"
            "Look for direct and subtle burdens: permits, fees, compelled speech, disclosures, searches, seizures, discretion, vagueness, penalties, and chilling effects.\n"
            "Do not state a legal violation as fact; identify possible constitutional issues and explain the reasoning.\n"
            "Return JSON only. For each question provide question, answer, possible_amendments, evidence, confidence.\n");
        append_top_sections(&prompt, &input_pack, "Iowa Code", (int)topk, "INPUT PACK");
        for (size_t r = 0; r < nrefs_in; r++) {
            char label[256];
            snprintf(label, sizeof(label), "REFERENCE %zu", r + 1);
            append_top_sections(&prompt, &refs[r], "Bill of Rights", (int)(topk / 2 + 1), label);
        }
        sb_append(&prompt, "\nQUESTIONS:\n");
        for (size_t i = 0; i < nq; i++) sb_appendf(&prompt, "%zu. %s\n", i + 1, questions[i]);

        char prompt_path[PATH_MAX];
        snprintf(prompt_path, sizeof(prompt_path), "%s/batch.prompt.txt", workdir);
        write_file(prompt_path, prompt.buf);
        char *cmd = runner_cmd(runner_template, prompt_path, prompt.buf, ctx_size, max_tokens);
        if (show_prompt) printf("\n%s\n", prompt.buf);
        char *raw = run_capture(cmd);
        if (!raw) { fprintf(stderr, "%s: runner failed\n", APP); return 1; }
        char raw_path[PATH_MAX];
        snprintf(raw_path, sizeof(raw_path), "%s/batch.raw.txt", workdir);
        write_file(raw_path, raw);
        write_file(state_next_path, "2");
        write_file(state_summary_path, raw);
        write_file(state_hash_path, input_hash_hex);

        fprintf(md, "## Batch answer\n\n```text\n%s\n```\n", raw);
        fprintf(csv, "1,");
        csv_escape(csv, "BATCH");
        fputc(',', csv);
        csv_escape(csv, raw_path);
        fputc(',', csv);
        csv_escape(csv, raw);
        fputc('\n', csv);
        fputs("    {\n", js);
        fputs("      \"index\": 1,\n", js);
        fputs("      \"question\": ", js); csv_escape(js, "BATCH"); fputs(",\n", js);
        fputs("      \"raw_output_file\": ", js); csv_escape(js, raw_path); fputs(",\n", js);
        fputs("      \"answer\": ", js); csv_escape(js, raw); fputc('\n', js);
        fputs("    }", js);
        count = 1;
        free(prompt.buf); free(cmd); free(raw);
    } else {
        for (size_t qi = start_item - 1; qi < nq; qi++) {
            char *prompt_text = build_prompt(&input_pack, refs, nrefs_in, questions[qi], topk);
            char prompt_path[PATH_MAX], raw_path[PATH_MAX];
            snprintf(prompt_path, sizeof(prompt_path), "%s/question_%04zu.prompt.txt", workdir, qi + 1);
            snprintf(raw_path, sizeof(raw_path), "%s/question_%04zu.raw.txt", workdir, qi + 1);
            write_file(prompt_path, prompt_text);

            char *cmd = runner_cmd(runner_template, prompt_path, prompt_text, ctx_size, max_tokens);
            if (show_prompt) printf("\n===== PROMPT %zu =====\n%s\n=====================\n", qi + 1, prompt_text);
            printf("[%zu/%zu] %s\n", qi + 1, nq, questions[qi]);
            fflush(stdout);

            char *raw = run_capture(cmd);
            if (!raw) { fprintf(stderr, "%s: runner failed\n", APP); return 1; }
            write_file(raw_path, raw);

            char *answer = extract_json_text(raw, 9000);
            append_report(md, csv, js, &count, questions[qi], raw_path, answer);

            free(rolling);
            rolling = xstrdup(raw);
            write_file(state_summary_path, rolling);
            char nextbuf[64];
            snprintf(nextbuf, sizeof(nextbuf), "%zu", qi + 2);
            write_file(state_next_path, nextbuf);
            write_file(state_hash_path, input_hash_hex);

            free(prompt_text);
            free(cmd);
            free(raw);
            free(answer);
        }
    }

    fputs("\n  ]\n}\n", js);
    fflush(md); fflush(csv); fflush(js);
    fclose(md); fclose(csv); fclose(js);

    printf("Done. Reports written to %s\n", outdir);
    printf("Pack cache: %s/.qca_cache/\n", outdir);
    printf("Resume state: %s/.qca_state/\n", outdir);

    free(rolling);
    pack_free(&input_pack);
    for (size_t i = 0; i < nrefs_in; i++) pack_free(&refs[i]);
    free(refs);
    for (size_t i = 0; i < nq; i++) free(questions[i]);
    free(questions);
    free(refs_in);
    return 0;
}
