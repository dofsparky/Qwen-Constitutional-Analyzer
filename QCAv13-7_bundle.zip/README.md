# QCAv13-7 lamerized

QCAv13-7 supports two modes:

1. **Analysis mode** — default when `--questions` is omitted.
   It chunks the input document, caches the pack, and analyzes each chunk against the Bill of Rights.

2. **Question mode** — enabled when `--questions FILE` is present.
   It answers one question per line, or uses `--batch` to ask all questions at once.

## Build

```bash
make
```

## Detailed help

```bash
./QCAv13-7 --help
```

## Key behavior

- PDF and text are accepted for both `--input` and `--reference`
- Cached packs are reused if the same source file is analyzed again
- Resume state is written under `.qca_state/`
- Cached document packs are written under `.qca_cache/`
- `--profile ultra` maps to `-c 8192`
- `--workers auto` chooses a safe worker count from CPU and RAM
- If `--questions` is not provided, analysis mode runs automatically

## Examples

Analysis mode:

```bash
./QCAv13-7   --profile ultra   --workers auto   --input "/home/delta/iowa/2022-iowa-code.pdf"   --reference "/home/delta/references/bill-of-rights.pdf"   --outdir "iowa-2022"   --runner-template 'llama-cli -m /home/delta/models/Qwen3-4B-Q4_K_M.gguf --jinja --reasoning on --reasoning-budget -1 -c {CTX_SIZE} -p {PROMPT}'
```

Question mode:

```bash
./QCAv13-7   --profile ultra   --input "/home/delta/iowa/2022-iowa-code.pdf"   --reference "/home/delta/references/bill-of-rights.pdf"   --questions "/home/delta/questions.txt"   --outdir "iowa-2022"   --runner-template 'llama-cli -m /home/delta/models/Qwen3-4B-Q4_K_M.gguf --jinja --reasoning on --reasoning-budget -1 -c {CTX_SIZE} -p {PROMPT}'
```

## `--workers`

`--workers auto` is the safest default. Manual values are supported when you already know your machine can handle more concurrency.

- `--workers 1` is the safest
- `--workers 2` is a conservative speedup on midrange systems
- `--workers auto` chooses from CPU and RAM automatically

## Output

- `report.md`
- `index.csv`
- `index.json`
- `.qca_cache/`
- `.qca_state/`
- `work/*.prompt.txt`
- `work/*.raw.txt`

## Notes

QCAv13-7 keeps the Bill of Rights as the controlling authority and the Iowa Code as subordinate text.
